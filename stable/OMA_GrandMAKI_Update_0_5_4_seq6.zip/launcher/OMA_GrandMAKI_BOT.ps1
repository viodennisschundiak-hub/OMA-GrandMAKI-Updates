﻿#requires -Version 5.1
<#
  OMA GrandMAKI-BOT Launcher 1.2.5
  Sichere lokale Startoberflaeche fuer den bestehenden grandMA2 MCP/Tunnel-Aufbau.
  Keine Geheimnisse sind in dieser Datei enthalten.
#>

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Security

$script:AppVersion = '1.2.5'
$script:PackagedBridgeBuildSha256 = '395df919ddfd3e4e4f3ac51f0cc0fca5ab3bae231fea5dda25df60e95d4ef648'
$script:AppName = 'OMA GrandMAKI-BOT'
$script:OwnedTunnelProcess = $null
$script:ExternalTunnel = $false
$script:IsBusy = $false
$script:Closing = $false
$script:StatusTimer = $null
$script:ScanTimer = $null
$script:AutoUpdateTimer = $null
$script:AutoUpdateProcess = $null
$script:AutoUpdateStdoutTask = $null
$script:AutoUpdateStderrTask = $null
$script:AutoUpdateStarted = $false
$script:ActiveSessionId = $null
$script:UpdateCandidate = $null
$script:LogLines = New-Object System.Collections.Generic.List[string]
$script:StageControls = @{}

$script:AppDataDir = Join-Path $env:LOCALAPPDATA 'OMA_GrandMAKI_BOT'
$script:ConfigPath = Join-Path $script:AppDataDir 'config.json'
$script:SecretPath = Join-Path $script:AppDataDir 'secrets.dpapi.json'
$script:LogPath = Join-Path $script:AppDataDir 'oma.log'
$script:LastProbeDiagnosticPath = Join-Path $script:AppDataDir 'last_probe_diagnostic.txt'
$script:BasementRoot = $script:AppDataDir
$script:BasementCodeRoot = Join-Path $script:BasementRoot 'bootstrap\phase5-0.5.0'
$script:UpdateStagingDir = Join-Path $script:AppDataDir 'launcher_updates'
$script:DpapiEntropy = [Text.Encoding]::UTF8.GetBytes('OMA GrandMAKI-BOT|DPAPI|v1')

if (-not (Test-Path -LiteralPath $script:AppDataDir)) {
    New-Item -ItemType Directory -Path $script:AppDataDir -Force | Out-Null
}

function Get-ProvisionedUpdateChannel {
    $provisionPath = Join-Path $PSScriptRoot 'update_channel.json'
    if (-not (Test-Path -LiteralPath $provisionPath -PathType Leaf)) { return $null }
    try {
        $provision = Get-Content -LiteralPath $provisionPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $value = [string]$provision.channel_url
        if ([string]::IsNullOrWhiteSpace($value)) { return $null }
        return $value
    } catch { return $null }
}

function Get-DefaultConfig {
    $bridge = Join-Path $env:USERPROFILE 'MA2_AI_BRIDGE'
    $tunnel = Join-Path $env:USERPROFILE 'TunnelClient'
    [pscustomobject]@{
        BridgePath = $bridge
        RuntimePythonPath = (Join-Path $bridge '.venv\Scripts\python.exe')
        TunnelPath = $tunnel
        SoundEnabled = $true
        AutoOpenChatGPT = $false
        ProbeTimeoutSeconds = 35
        ReadyTimeoutSeconds = 45
        ModeSelection = 'full_admin'
        SetupSelection = 'without_console'
        ConsoleHost = ''
        UpdateChannel = (Get-ProvisionedUpdateChannel)
        TrustedKeysPath = (Join-Path $PSScriptRoot 'trusted_update_keys.json')
        AutoCheckUpdates = $true
    }
}

function Save-Config {
    param([Parameter(Mandatory=$true)]$Config)
    $temporary = "$($script:ConfigPath).$PID.$([Guid]::NewGuid().ToString('N')).tmp"
    $backup = "$($script:ConfigPath).$PID.$([Guid]::NewGuid().ToString('N')).bak"
    $replaced = $false
    try {
        $Config | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $temporary -Encoding UTF8
        if (Test-Path -LiteralPath $script:ConfigPath -PathType Leaf) {
            [IO.File]::Replace($temporary, $script:ConfigPath, $backup, $true)
            $replaced = $true
            if (Test-Path -LiteralPath $backup -PathType Leaf) {
                Remove-Item -LiteralPath $backup -Force
            }
        } else {
            Move-Item -LiteralPath $temporary -Destination $script:ConfigPath
        }
    } finally {
        if (Test-Path -LiteralPath $temporary -PathType Leaf) { Remove-Item -LiteralPath $temporary -Force }
        if ($replaced -and (Test-Path -LiteralPath $backup -PathType Leaf)) { Remove-Item -LiteralPath $backup -Force }
    }
}

function Load-Config {
    $defaults = Get-DefaultConfig
    if (-not (Test-Path -LiteralPath $script:ConfigPath)) {
        Save-Config $defaults
        return $defaults
    }
    try {
        $loaded = Get-Content -LiteralPath $script:ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($name in @('BridgePath','RuntimePythonPath','TunnelPath','SoundEnabled','AutoOpenChatGPT','ProbeTimeoutSeconds','ReadyTimeoutSeconds','ModeSelection','SetupSelection','ConsoleHost','UpdateChannel','TrustedKeysPath','AutoCheckUpdates')) {
            if ($null -eq $loaded.PSObject.Properties[$name]) {
                $loaded | Add-Member -NotePropertyName $name -NotePropertyValue $defaults.$name
            }
        }
        return $loaded
    } catch {
        $backup = "$($script:ConfigPath).defekt_$(Get-Date -Format yyyyMMdd_HHmmss)"
        Move-Item -LiteralPath $script:ConfigPath -Destination $backup -Force
        Save-Config $defaults
        return $defaults
    }
}

function Resolve-ManagedBridgeRelease {
    $releaseRoot = Join-Path $script:BasementRoot 'releases'
    if (-not (Test-Path -LiteralPath $releaseRoot -PathType Container)) {
        throw [IO.DirectoryNotFoundException]::new('MANAGED_RELEASE_BINDING: Der lokale A/B-Releaseordner fehlt. OMA bleibt OFFLINE.')
    }

    $currentPath = Join-Path $script:BasementRoot 'current.json'
    if (-not (Test-Path -LiteralPath $currentPath -PathType Leaf)) {
        throw [Security.SecurityException]::new('MANAGED_RELEASE_BINDING: Der aktive A/B-Releasezeiger current.json fehlt. OMA bleibt OFFLINE.')
    }
    try {
        $current = Get-Content -LiteralPath $currentPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        throw [Security.SecurityException]::new('MANAGED_RELEASE_BINDING: current.json ist ungültig. OMA bleibt OFFLINE.')
    }
    $slot = [string]$current.slot
    if (@('release-A','release-B') -notcontains $slot) {
        throw [Security.SecurityException]::new('MANAGED_RELEASE_BINDING: current.json enthält keinen zulässigen A/B-Slot. OMA bleibt OFFLINE.')
    }
    $pointerBuild = ([string]$current.build_sha256).Trim().ToLowerInvariant()
    if ($pointerBuild -ne $script:PackagedBridgeBuildSha256) {
        throw [Security.SecurityException]::new("MANAGED_RELEASE_BINDING: Aktiver Build $pointerBuild passt nicht zum Launcher-Build $($script:PackagedBridgeBuildSha256). OMA bleibt OFFLINE.")
    }

    $candidate = [IO.Path]::GetFullPath((Join-Path $releaseRoot $slot)).TrimEnd('\')
    $manifestPath = Join-Path $candidate 'OMA_RELEASE_MANIFEST.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        throw [Security.SecurityException]::new('MANAGED_RELEASE_BINDING: Das Manifest des aktiven A/B-Slots fehlt. OMA bleibt OFFLINE.')
    }
    try {
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        throw [Security.SecurityException]::new('MANAGED_RELEASE_BINDING: Das Manifest des aktiven A/B-Slots ist ungültig. OMA bleibt OFFLINE.')
    }
    $manifestPathValue = [IO.Path]::GetFullPath([string]$manifest.path).TrimEnd('\')
    if (
        [string]$manifest.slot -ne $slot -or
        ([string]$manifest.build_sha256).Trim().ToLowerInvariant() -ne $pointerBuild -or
        [string]$manifest.release_id -ne [string]$current.release_id -or
        [string]$manifest.status -ne 'verified' -or
        [string]$manifest.source -ne 'signed_update_bundle' -or
        -not [string]::Equals($manifestPathValue, $candidate, [StringComparison]::OrdinalIgnoreCase)
    ) {
        throw [Security.SecurityException]::new('MANAGED_RELEASE_BINDING: Releasezeiger und signiertes A/B-Manifest stimmen nicht überein. OMA bleibt OFFLINE.')
    }

    $markerPath = Join-Path $candidate 'OMA_EXPECTED_BUILD_SHA256.txt'
    $required = @($markerPath, (Join-Path $candidate 'run_mcp.py'), (Join-Path $candidate 'src\server.py'))
    if (@($required | Where-Object { -not (Test-Path -LiteralPath $_ -PathType Leaf) }).Count -ne 0) {
        throw [Security.SecurityException]::new('MANAGED_RELEASE_BINDING: Der aktive A/B-Quellslot ist unvollständig. OMA bleibt OFFLINE.')
    }
    $markerBuild = (Get-Content -LiteralPath $markerPath -Raw -Encoding UTF8).Trim().ToLowerInvariant()
    if ($markerBuild -ne $pointerBuild) {
        throw [Security.SecurityException]::new('MANAGED_RELEASE_BINDING: Build-Marker und A/B-Manifest stimmen nicht überein. OMA bleibt OFFLINE.')
    }
    return $candidate
}

function Resolve-OmaPythonRuntime {
    param([Parameter(Mandatory=$true)]$Config)
    $candidates = New-Object System.Collections.Generic.List[string]
    if ($null -ne $Config.PSObject.Properties['RuntimePythonPath']) {
        $candidates.Add([string]$Config.RuntimePythonPath)
    }
    if ($null -ne $Config.PSObject.Properties['BridgePath'] -and -not [string]::IsNullOrWhiteSpace([string]$Config.BridgePath)) {
        $candidates.Add((Join-Path ([string]$Config.BridgePath) '.venv\Scripts\python.exe'))
    }
    $candidates.Add((Join-Path $env:USERPROFILE 'MA2_AI_BRIDGE\.venv\Scripts\python.exe'))
    foreach ($candidate in @($candidates | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return [IO.Path]::GetFullPath($candidate)
        }
    }
    $python = Get-Command 'python.exe' -ErrorAction SilentlyContinue
    if ($python -and (Test-Path -LiteralPath $python.Source -PathType Leaf)) { return [IO.Path]::GetFullPath($python.Source) }
    throw [IO.FileNotFoundException]::new('OMA_RUNTIME_BINDING: Keine lokale Python-Laufzeit gefunden. Der signierte A/B-Quellslot bleibt unverändert; OMA bleibt OFFLINE.')
}

function Sync-ManagedBridgeBinding {
    param([Parameter(Mandatory=$true)]$Config)
    # Die Laufzeit muss vor der Quellslot-Umbindung erhalten bleiben. Signierte
    # A/B-Releases enthalten absichtlich keine lokale .venv.
    $runtimePython = Resolve-OmaPythonRuntime -Config $Config
    $managedBridge = Resolve-ManagedBridgeRelease
    $configuredBridge = [IO.Path]::GetFullPath([string]$Config.BridgePath).TrimEnd('\')
    $resolvedBridge = [IO.Path]::GetFullPath($managedBridge).TrimEnd('\')
    $configuredRuntime = [string]$Config.RuntimePythonPath
    if (
        -not [string]::Equals($configuredBridge, $resolvedBridge, [StringComparison]::OrdinalIgnoreCase) -or
        -not [string]::Equals($configuredRuntime, $runtimePython, [StringComparison]::OrdinalIgnoreCase)
    ) {
        $Config.BridgePath = $resolvedBridge
        $Config.RuntimePythonPath = $runtimePython
        Save-Config $Config
    }
    return $Config
}

try {
    $script:Config = Sync-ManagedBridgeBinding -Config (Load-Config)
} catch {
    [Windows.MessageBox]::Show($_.Exception.Message, $script:AppName, 'OK', 'Error') | Out-Null
    throw
}

function Sync-ConfigFromDisk {
    param([switch]$RefreshUi)
    $fresh = Sync-ManagedBridgeBinding -Config (Load-Config)
    $changed = $false
    if (@('observer','programming','full_admin') -notcontains [string]$fresh.ModeSelection) {
        $fresh.ModeSelection = 'observer'
        $changed = $true
    }
    if (@('without_console','with_console') -notcontains [string]$fresh.SetupSelection) {
        $fresh.SetupSelection = 'without_console'
        $changed = $true
    }
    $currentTrustedKeys = Join-Path $PSScriptRoot 'trusted_update_keys.json'
    if ([string]$fresh.TrustedKeysPath -ne $currentTrustedKeys) {
        $fresh.TrustedKeysPath = $currentTrustedKeys
        $changed = $true
    }
    $provisionedChannel = Get-ProvisionedUpdateChannel
    if (-not [string]::IsNullOrWhiteSpace($provisionedChannel) -and [string]::IsNullOrWhiteSpace([string]$fresh.UpdateChannel)) {
        $fresh.UpdateChannel = $provisionedChannel
        $changed = $true
    }
    if ($changed) { Save-Config $fresh }
    $script:Config = $fresh
    if ($RefreshUi) { Update-PathLabels }
    return $fresh
}

function Protect-Text {
    param([Parameter(Mandatory=$true)][string]$Text)
    $plain = [Text.Encoding]::UTF8.GetBytes($Text)
    try {
        $cipher = [Security.Cryptography.ProtectedData]::Protect(
            $plain,
            $script:DpapiEntropy,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        return [Convert]::ToBase64String($cipher)
    } finally {
        if ($plain) { [Array]::Clear($plain, 0, $plain.Length) }
    }
}

function Unprotect-Text {
    param([Parameter(Mandatory=$true)][string]$CipherText)
    $cipher = [Convert]::FromBase64String($CipherText)
    $plain = $null
    try {
        $plain = [Security.Cryptography.ProtectedData]::Unprotect(
            $cipher,
            $script:DpapiEntropy,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        return [Text.Encoding]::UTF8.GetString($plain)
    } finally {
        if ($cipher) { [Array]::Clear($cipher, 0, $cipher.Length) }
        if ($plain) { [Array]::Clear($plain, 0, $plain.Length) }
    }
}

function Save-Secrets {
    param(
        [Parameter(Mandatory=$true)][string]$RuntimeKey,
        [Parameter(Mandatory=$true)][string]$TunnelId
    )
    $payload = [ordered]@{
        version = 1
        protection = 'Windows DPAPI CurrentUser'
        runtimeKey = Protect-Text $RuntimeKey
        tunnelId = Protect-Text $TunnelId
    }
    $payload | ConvertTo-Json | Set-Content -LiteralPath $script:SecretPath -Encoding UTF8
}

function Get-Secrets {
    if (-not (Test-Path -LiteralPath $script:SecretPath)) { return $null }
    try {
        $payload = Get-Content -LiteralPath $script:SecretPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($payload.version -ne 1 -or -not $payload.runtimeKey -or -not $payload.tunnelId) { return $null }
        return [pscustomobject]@{
            RuntimeKey = Unprotect-Text ([string]$payload.runtimeKey)
            TunnelId = Unprotect-Text ([string]$payload.tunnelId)
        }
    } catch {
        Write-SafeLog 'Secrets' 'DPAPI-Daten konnten in diesem Windows-Konto nicht entschluesselt werden.' 'ERROR'
        return $null
    }
}

function Redact-Text {
    param([string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return $Text }
    $safe = $Text -replace 'sk-[A-Za-z0-9_\-]{8,}', '[REDACTED_KEY]'
    $safe = $safe -replace 'tunnel_[A-Za-z0-9_\-]{8,}', '[REDACTED_TUNNEL]'
    $safe = $safe -replace '(CONTROL_PLANE_API_KEY|CONTROL_PLANE_TUNNEL_ID)\s*[=:]\s*\S+', '$1=[REDACTED]'
    $safe = $safe -replace '(GMA_PASSWORD|GMA_USER|Authorization|Bearer)\s*[=:]\s*\S+', '$1=[REDACTED]'
    return $safe
}

function Write-SafeLog {
    param(
        [string]$Area,
        [string]$Message,
        [ValidateSet('INFO','PASS','WARN','ERROR')][string]$Level = 'INFO'
    )
    $safeMessage = Redact-Text $Message
    $line = '{0} [{1}] [{2}] {3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Area, $safeMessage
    try {
        if ((Test-Path -LiteralPath $script:LogPath) -and (Get-Item -LiteralPath $script:LogPath).Length -gt 1048576) {
            Move-Item -LiteralPath $script:LogPath -Destination "$($script:LogPath).1" -Force
        }
        Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
    } catch { }

    $uiLine = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $safeMessage
    $script:LogLines.Add($uiLine)
    while ($script:LogLines.Count -gt 120) { $script:LogLines.RemoveAt(0) }
    if ($script:LogBox) {
        $script:LogBox.Text = ($script:LogLines -join [Environment]::NewLine)
        $script:LogBox.ScrollToEnd()
    }
}

function Test-TcpPort {
    param([string]$HostName = '127.0.0.1', [int]$Port = 30000, [int]$TimeoutMs = 1800)
    $client = New-Object Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($HostName, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) { return $false }
        $client.EndConnect($async)
        return $client.Connected
    } catch { return $false }
    finally { $client.Close() }
}

function Test-HttpReady {
    param([string]$Uri)
    try {
        $response = Invoke-WebRequest -Uri $Uri -UseBasicParsing -TimeoutSec 2
        return ($response.StatusCode -ge 200 -and $response.StatusCode -lt 300)
    } catch { return $false }
}

function Test-ValidGmaHost {
    param([string]$HostName)
    if ([string]::IsNullOrWhiteSpace($HostName)) { return $false }
    $trimmed = $HostName.Trim()
    if ($trimmed.Length -gt 253) { return $false }
    return ($trimmed -match '^[A-Za-z0-9](?:[A-Za-z0-9.\-]{0,251}[A-Za-z0-9])?$')
}

function Get-BridgeHostFromEnv {
    param([Parameter(Mandatory=$true)][string]$BridgeRoot)
    $envPath = Join-Path $BridgeRoot '.env'
    if (-not (Test-Path -LiteralPath $envPath -PathType Leaf)) { return $null }
    try {
        foreach ($line in Get-Content -LiteralPath $envPath -Encoding UTF8) {
            if ($line -match '^\s*GMA_HOST\s*=\s*["'']?([^#"'']+?)["'']?\s*$') {
                $candidate = [string]$Matches[1].Trim()
                if ((Test-ValidGmaHost $candidate) -and $candidate -notin @('127.0.0.1','localhost','::1')) {
                    return $candidate
                }
            }
        }
    } catch { }
    return $null
}

function Get-ConnectionProfile {
    param([Parameter(Mandatory=$true)][string]$Setup)
    if ($Setup -eq 'without_console') {
        return [pscustomobject]@{ Name='onpc_local'; Host='127.0.0.1'; Port=30000; Label='NUR ONPC' }
    }
    if ($Setup -ne 'with_console') { throw "Unbekannter MA2-Aufbau: $Setup" }
    $hostName = [string]$script:Config.ConsoleHost
    if ([string]::IsNullOrWhiteSpace($hostName)) {
        $hostName = [string](Get-BridgeHostFromEnv -BridgeRoot ([string]$script:Config.BridgePath))
    }
    $hostName = $hostName.Trim()
    if (-not (Test-ValidGmaHost $hostName) -or $hostName -in @('127.0.0.1','localhost','::1')) {
        throw [InvalidOperationException]::new('CONSOLE_HOST: Für MIT LICHTPULT fehlt eine gültige Pult-IP. OMA stoppen und die Pult-IP unter Einstellungen eintragen.')
    }
    return [pscustomobject]@{ Name='console_session'; Host=$hostName; Port=30000; Label='MIT LICHTPULT' }
}

function Get-ExpectedBridgeBuild {
    param([Parameter(Mandatory=$true)][string]$BridgeRoot)
    $marker = Join-Path $BridgeRoot 'OMA_EXPECTED_BUILD_SHA256.txt'
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) {
        throw [IO.FileNotFoundException]::new('RUNTIME_SOURCE_MISMATCH: Die Bridge-Attestierung OMA_EXPECTED_BUILD_SHA256.txt fehlt.')
    }
    $value = (Get-Content -LiteralPath $marker -Raw -Encoding UTF8).Trim().ToLowerInvariant()
    if ($value -notmatch '^[0-9a-f]{64}$') {
        throw [Security.SecurityException]::new('RUNTIME_SOURCE_MISMATCH: Die Bridge-Attestierung ist ungültig.')
    }
    return $value
}

function ConvertTo-SafeProcessOutput {
    param([string]$Text, [int]$MaximumLength = 2048)
    if ([string]::IsNullOrWhiteSpace($Text)) { return '' }
    $safe = (Redact-Text $Text).Trim()
    if ($safe.Length -gt $MaximumLength) { $safe = $safe.Substring(0, $MaximumLength) + ' …[GEKÜRZT]' }
    return $safe
}

function Save-LastProbeDiagnostic {
    param([string]$Stage, [string]$Target, $Result)
    try {
        @(
            'secrets_included=false'
            'grandma_commands_executed=0'
            ('timestamp=' + (Get-Date).ToString('o'))
            ('stage=' + (Redact-Text $Stage))
            ('target=' + (Redact-Text $Target))
            ('exit_code=' + [string]$Result.ExitCode)
            ('timed_out=' + [string]$Result.TimedOut)
            'safe_output_begin'
            (ConvertTo-SafeProcessOutput ([string]$Result.SafeOutput))
            'safe_output_end'
        ) | Set-Content -LiteralPath $script:LastProbeDiagnosticPath -Encoding UTF8
    } catch { }
}

function Test-OmaSessionRunning {
    if ($script:OwnedTunnelProcess -and -not $script:OwnedTunnelProcess.HasExited) { return $true }
    try {
        if (@(Get-Process -Name 'tunnel-client' -ErrorAction SilentlyContinue).Count -gt 0) { return $true }
    } catch { }
    return (Test-TcpPort -HostName '127.0.0.1' -Port 8080 -TimeoutMs 180)
}

function Assert-OmaStopped {
    if (Test-OmaSessionRunning) {
        throw [InvalidOperationException]::new('OMA_SESSION_ACTIVE: Zuerst OMA STOPPEN. Modus, Aufbau, Einstellungen und Updates sind während einer laufenden Session gesperrt.')
    }
}

function Get-ModeProfile {
    param([Parameter(Mandatory=$true)][string]$Mode)
    switch ($Mode) {
        'observer' { return @{ Scope='tier:0'; OmaMode='observer'; Label='OBSERVER' } }
        'programming' { return @{ Scope='tier:4'; OmaMode='normal'; Label='PROGRAMMING' } }
        'full_admin' { return @{ Scope='tier:5'; OmaMode='full_admin'; Label='FULL ADMIN' } }
        default { throw "Unbekannter OMA-Modus: $Mode" }
    }
}

function Resolve-BasementPython {
    return (Resolve-OmaPythonRuntime -Config $script:Config)
}

function Invoke-BasementJson {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)
    if (-not (Test-Path -LiteralPath (Join-Path $script:BasementCodeRoot 'oma_basement') -PathType Container)) {
        throw "OMA Basement 0.5.0 fehlt. Einmal das neue Phase-5-Paket installieren: $($script:BasementCodeRoot)"
    }
    $pythonExe = Resolve-BasementPython
    $previousPythonPath = $env:PYTHONPATH
    try {
        $env:PYTHONPATH = $script:BasementCodeRoot
        $output = @(& $pythonExe -m oma_basement @Arguments 2>&1)
        $exitCode = $LASTEXITCODE
        $plain = (($output | ForEach-Object { [string]$_ }) -join [Environment]::NewLine).Trim()
        if ($exitCode -ne 0) {
            $safe = Redact-Text $plain
            throw "Basement-Steuerung wurde gestoppt (Exit $exitCode): $safe"
        }
        if ([string]::IsNullOrWhiteSpace($plain)) { return $null }
        return ($plain | ConvertFrom-Json)
    } finally {
        $env:PYTHONPATH = $previousPythonPath
    }
}

function Prepare-OmaSession {
    Assert-OmaStopped
    $payload = Invoke-BasementJson -Arguments @('launcher-session-prepare','--root',$script:BasementRoot,'--mode',([string]$script:Config.ModeSelection),'--setup',([string]$script:Config.SetupSelection))
    $script:ActiveSessionId = [string]$payload.session_id
    if ([string]::IsNullOrWhiteSpace($script:ActiveSessionId)) { throw 'Basement lieferte keine Session-ID.' }
    return $payload
}

function Activate-OmaSession {
    if ([string]::IsNullOrWhiteSpace($script:ActiveSessionId)) { throw 'Vorbereitete Session-ID fehlt.' }
    $null = Invoke-BasementJson -Arguments @('launcher-session-activate','--root',$script:BasementRoot,'--session-id',$script:ActiveSessionId)
}

function Release-OmaSession {
    if (Test-OmaSessionRunning) { throw 'OMA läuft noch; Session-Sperre bleibt aktiv.' }
    $arguments = @('launcher-session-stop','--root',$script:BasementRoot)
    if (-not [string]::IsNullOrWhiteSpace($script:ActiveSessionId)) { $arguments += @('--session-id',$script:ActiveSessionId) }
    $null = Invoke-BasementJson -Arguments $arguments
    $script:ActiveSessionId = $null
}

function Set-UpdateUi {
    param([string]$Text, [int]$Percent = 0, [ValidateSet('idle','running','ready','error')][string]$State = 'idle')
    if ($script:UpdateStatusText) { $script:UpdateStatusText.Text = $Text }
    if ($script:UpdateProgress) { $script:UpdateProgress.Value = [Math]::Max(0, [Math]::Min(100, $Percent)) }
    if ($script:UpdateStatusText) {
        $color = switch ($State) { 'running' {'#FF00F5FF'} 'ready' {'#FF58FF9A'} 'error' {'#FFFF3B78'} default {'#FF9BAABD'} }
        $script:UpdateStatusText.Foreground = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($color))
    }
}

function Start-AutoUpdateCheck {
    if ($script:AutoUpdateStarted -or -not [bool]$script:Config.AutoCheckUpdates) { return }
    $script:AutoUpdateStarted = $true
    if (Test-OmaSessionRunning) { Set-UpdateUi 'Updateprüfung nach OMA STOPPEN' 0 'idle'; return }
    $channel = [string]$script:Config.UpdateChannel
    $trustedKeys = [string]$script:Config.TrustedKeysPath
    if ([string]::IsNullOrWhiteSpace($channel)) {
        Set-UpdateUi 'Sicherer Online-Kanal noch nicht aktiviert' 0 'idle'
        return
    }
    if ($channel.IndexOfAny([char[]]@('"', "`r", "`n")) -ge 0) {
        Set-UpdateUi 'Updatekanal enthält unzulässige Zeichen' 0 'error'
        return
    }
    if (-not (Test-Path -LiteralPath $trustedKeys -PathType Leaf)) {
        Set-UpdateUi 'Öffentlicher Update-Schlüssel fehlt' 0 'error'
        return
    }
    try {
        $pythonExe = Resolve-BasementPython
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = $pythonExe
        $startInfo.Arguments = '-m oma_basement update-check --root "' + $script:BasementRoot + '" --channel-url "' + $channel + '" --trusted-keys "' + $trustedKeys + '"'
        $startInfo.WorkingDirectory = $script:BasementCodeRoot
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        $startInfo.EnvironmentVariables['PYTHONPATH'] = $script:BasementCodeRoot
        $script:AutoUpdateProcess = New-Object System.Diagnostics.Process
        $script:AutoUpdateProcess.StartInfo = $startInfo
        if (-not $script:AutoUpdateProcess.Start()) { throw 'Hintergrundprüfung konnte nicht gestartet werden.' }
        $script:AutoUpdateStdoutTask = $script:AutoUpdateProcess.StandardOutput.ReadToEndAsync()
        $script:AutoUpdateStderrTask = $script:AutoUpdateProcess.StandardError.ReadToEndAsync()
        Set-UpdateUi 'Updatekanal wird im Hintergrund geprüft …' 12 'running'
        $script:AutoUpdateTimer = New-Object Windows.Threading.DispatcherTimer
        $script:AutoUpdateTimer.Interval = [TimeSpan]::FromMilliseconds(350)
        $script:AutoUpdateTimer.Add_Tick({
            if ($null -eq $script:AutoUpdateProcess -or -not $script:AutoUpdateProcess.HasExited) { return }
            if (-not $script:AutoUpdateStdoutTask.IsCompleted -or -not $script:AutoUpdateStderrTask.IsCompleted) { return }
            $script:AutoUpdateTimer.Stop()
            $stdout = ([string]$script:AutoUpdateStdoutTask.Result).Trim()
            $stderr = ([string]$script:AutoUpdateStderrTask.Result).Trim()
            $exitCode = $script:AutoUpdateProcess.ExitCode
            $script:AutoUpdateProcess.Dispose()
            $script:AutoUpdateProcess = $null
            $script:AutoUpdateStdoutTask = $null
            $script:AutoUpdateStderrTask = $null
            if ($exitCode -ne 0) {
                Set-UpdateUi ('Updateprüfung fehlgeschlagen: ' + (Redact-Text $stderr)) 0 'error'
                return
            }
            try {
                $checked = $stdout | ConvertFrom-Json
                if ([bool]$checked.update_available) {
                    $script:UpdateCandidate = $checked.channel.release
                    Set-UpdateUi ("Update {0} verfügbar · UPDATES PRÜFEN" -f $checked.channel.release.version) 18 'ready'
                } else {
                    Set-UpdateUi ("Aktuell · Kanalversion {0}" -f $checked.channel.release.version) 100 'ready'
                }
            } catch {
                Set-UpdateUi 'Updateantwort war ungültig' 0 'error'
            }
        })
        $script:AutoUpdateTimer.Start()
    } catch {
        Set-UpdateUi ('Updateprüfung nicht gestartet: ' + $_.Exception.Message) 0 'error'
    }
}

function Set-OmaLauncherShortcutForVersion {
    param([Parameter(Mandatory=$true)][string]$LauncherRoot, [Parameter(Mandatory=$true)][string]$Version)
    $bootstrap = Join-Path $LauncherRoot 'OMA_Launcher_Bootstrap.ps1'
    $markerPath = Join-Path $LauncherRoot 'installed_launcher.json'
    if (-not (Test-Path -LiteralPath $bootstrap -PathType Leaf)) { throw 'Der signierte neue Launcher-Bootstrap fehlt.' }
    if (-not (Test-Path -LiteralPath $markerPath -PathType Leaf)) { throw 'Die verifizierte Launcher-Installationsmarke fehlt.' }
    $marker = Get-Content -LiteralPath $markerPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]$marker.launcher_version -ne $Version) { throw 'Launcher-Version und Installationsmarke stimmen nicht überein.' }
    $sourceProperty = $marker.PSObject.Properties['source']
    if ($null -eq $sourceProperty -or [string]$sourceProperty.Value -ne 'signed_update_bundle') {
        throw 'Launcher-Installationsmarke besitzt keine gültige signierte Update-Herkunft.'
    }

    $powerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powerShellExe -PathType Leaf)) {
        $powerShellExe = (Get-Command powershell.exe -ErrorAction Stop).Source
    }
    $shortcutArguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "' + $bootstrap + '"'
    $desktop = [Environment]::GetFolderPath('Desktop')
    $shortcutPath = Join-Path $desktop 'OMA GrandMAKI-BOT.lnk'
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $powerShellExe
    $shortcut.Arguments = $shortcutArguments
    $shortcut.WorkingDirectory = $LauncherRoot
    $shortcut.Description = "OMA GrandMAKI-BOT Launcher $Version"
    $iconPath = Join-Path $LauncherRoot 'assets\OMA.ico'
    if (Test-Path -LiteralPath $iconPath -PathType Leaf) { $shortcut.IconLocation = $iconPath }
    $shortcut.Save()

    $verified = $shell.CreateShortcut($shortcutPath)
    if (-not [string]::Equals([string]$verified.TargetPath, [string]$powerShellExe, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Desktop-Verknüpfung verweist nach dem Update nicht auf Windows PowerShell.'
    }
    if ([string]$verified.Arguments -ne $shortcutArguments) { throw 'Desktop-Verknüpfung enthält nach dem Update einen falschen Bootstrap-Aufruf.' }
    if (-not [string]::Equals([string]$verified.WorkingDirectory, [string]$LauncherRoot, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Desktop-Verknüpfung enthält nach dem Update ein falsches Arbeitsverzeichnis.'
    }
    return $bootstrap
}

function Restart-OmaIntoSignedLauncher {
    param([Parameter(Mandatory=$true)][string]$LauncherRoot)
    $restartScript = Join-Path $LauncherRoot 'OMA_Launcher_Restart.ps1'
    if (-not (Test-Path -LiteralPath $restartScript -PathType Leaf)) { throw 'Der signierte Launcher-Neustarthelfer fehlt.' }
    $powerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powerShellExe -PathType Leaf)) {
        $powerShellExe = (Get-Command powershell.exe -ErrorAction Stop).Source
    }
    $arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $restartScript + '" -OldLauncherProcessId ' + $PID
    Start-Process -FilePath $powerShellExe -ArgumentList $arguments -WorkingDirectory $LauncherRoot -WindowStyle Hidden | Out-Null
    $script:Window.Close()
}

function Invoke-LauncherUpdate {
    if ($script:IsBusy) { return }
    try {
        Assert-OmaStopped
        $null = Sync-ConfigFromDisk -RefreshUi
        Set-ControlsBusy $true
        Set-UpdateUi 'Signierten Updatekanal prüfen …' 8 'running'
        $channel = [string]$script:Config.UpdateChannel
        $trustedKeys = [string]$script:Config.TrustedKeysPath
        if ([string]::IsNullOrWhiteSpace($channel)) {
            throw 'UPDATE_CHANNEL_NOT_PROVISIONED: Der sichere Launcher-Updater ist bereit, aber es wurde noch kein produktiver HTTPS-Kanal mit öffentlichem Signaturschlüssel provisioniert.'
        }
        if ($channel.IndexOfAny([char[]]@('"', "`r", "`n")) -ge 0) { throw 'Updatekanal enthält unzulässige Zeichen.' }
        if (-not (Test-Path -LiteralPath $trustedKeys -PathType Leaf)) { throw 'Die Datei mit vertrauenswürdigen Update-Schlüsseln fehlt.' }
        $checked = Invoke-BasementJson -Arguments @('update-check','--root',$script:BasementRoot,'--channel-url',$channel,'--trusted-keys',$trustedKeys)
        $release = $checked.channel.release
        if (-not [bool]$checked.update_available) {
            Set-UpdateUi ("Aktuell · Kanalversion {0}" -f $release.version) 100 'ready'
            return
        }
        Set-UpdateUi ("Update {0} verifiziert" -f $release.version) 22 'running'
        $answer = [Windows.MessageBox]::Show(
            ("OMA Update {0} wurde kryptografisch verifiziert. Jetzt herunterladen, prüfen und im gestoppten Zustand installieren?" -f $release.version),
            $script:AppName,
            'YesNo',
            'Question'
        )
        if ($answer -ne 'Yes') { Set-UpdateUi 'Update wurde nicht installiert.' 0 'idle'; return }
        New-Item -ItemType Directory -Path $script:UpdateStagingDir -Force | Out-Null
        $bundle = Join-Path $script:UpdateStagingDir ("oma-update-{0}.zip" -f $release.version)
        Set-UpdateUi 'Download über HTTPS …' 35 'running'
        Invoke-WebRequest -Uri ([string]$release.bundle_url) -OutFile $bundle -UseBasicParsing -TimeoutSec 120
        Set-UpdateUi 'SHA-256 und Ed25519 prüfen …' 58 'running'
        $actualHash = (Get-FileHash -LiteralPath $bundle -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne ([string]$release.bundle_sha256).ToLowerInvariant()) { throw 'Download-Hash stimmt nicht mit dem signierten Kanal überein.' }
        $staged = Invoke-BasementJson -Arguments @('update-stage','--root',$script:BasementRoot,'--bundle',$bundle,'--trusted-keys',$trustedKeys)
        if ([string]$staged.state -ne 'staged') { throw "Update wurde nicht vollständig gestagt: $($staged.state)" }
        Set-UpdateUi 'A/B-Aktivierung und Rollback-Sicherung …' 82 'running'
        $activated = Invoke-BasementJson -Arguments @('update-apply','--root',$script:BasementRoot,'--update-id',([string]$staged.update_id))
        if ([bool]$activated.rolled_back) { throw 'Healthprüfung schlug fehl; das Update wurde automatisch zurückgerollt.' }
        $launcherManifest = $null
        if ([int]$staged.manifest.schema_version -eq 2) { $launcherManifest = $staged.manifest.launcher }
        if ($null -ne $launcherManifest) {
            $newLauncherRoot = Join-Path (Join-Path $script:BasementRoot 'launcher') ([string]$launcherManifest.version)
            try {
                $null = Set-OmaLauncherShortcutForVersion -LauncherRoot $newLauncherRoot -Version ([string]$launcherManifest.version)
            } catch {
                $null = Invoke-BasementJson -Arguments @('update-rollback','--root',$script:BasementRoot,'--update-id',([string]$staged.update_id))
                throw ('Launcher-Umschaltung fehlgeschlagen; Bridge wurde zurückgerollt: ' + $_.Exception.Message)
            }
            Set-UpdateUi ("Update {0} installiert · Launcher startet neu" -f $release.version) 100 'ready'
            Write-SafeLog 'Update' "Signiertes Suite-Update $($release.version) wurde aktiviert; Launcher $($launcherManifest.version) übernimmt." 'PASS'
            [Windows.MessageBox]::Show('Update vollständig geprüft und installiert. Der OMA Launcher startet jetzt automatisch neu.', $script:AppName, 'OK', 'Information') | Out-Null
            Restart-OmaIntoSignedLauncher -LauncherRoot $newLauncherRoot
            return
        }
        Set-UpdateUi ("Bridge-Update {0} installiert" -f $release.version) 100 'ready'
        Write-SafeLog 'Update' "Signiertes Bridge-Update $($release.version) wurde aktiviert." 'PASS'
    } catch {
        $message = $_.Exception.Message
        Set-UpdateUi $message 0 'error'
        Write-SafeLog 'Update' $message 'ERROR'
        [Windows.MessageBox]::Show($message, $script:AppName, 'OK', 'Information') | Out-Null
    } finally {
        Set-ControlsBusy $false
    }
}

function Invoke-UiPump {
    if (-not $script:Window) { return }
    try {
        $null = [Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke(
            [Windows.Threading.DispatcherPriority]::Background,
            [Action]{}
        )
    } catch { }
}

function Invoke-ProcessCheck {
    param(
        [Parameter(Mandatory=$true)][string]$FileName,
        [Parameter(Mandatory=$true)][string]$Arguments,
        [Parameter(Mandatory=$true)][string]$WorkingDirectory,
        [Parameter(Mandatory=$true)][hashtable]$Environment,
        [int]$TimeoutSeconds = 35
    )
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $FileName
    $psi.Arguments = $Arguments
    $psi.WorkingDirectory = $WorkingDirectory
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    foreach ($key in $Environment.Keys) { $psi.EnvironmentVariables[$key] = [string]$Environment[$key] }
    $null = $psi.EnvironmentVariables.Remove('GMA_AUTH_BYPASS')

    $process = New-Object Diagnostics.Process
    $process.StartInfo = $psi
    if (-not $process.Start()) { return [pscustomobject]@{ Success=$false; ExitCode=-1; TimedOut=$false; SafeOutput='' } }
    $outTask = $process.StandardOutput.ReadToEndAsync()
    $errTask = $process.StandardError.ReadToEndAsync()
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while (-not $process.HasExited -and (Get-Date) -lt $deadline) {
        if ($script:Closing) {
            try { & taskkill.exe /PID $process.Id /T /F 2>$null | Out-Null } catch { try { $process.Kill() } catch {} }
            return [pscustomobject]@{ Success=$false; ExitCode=-3; TimedOut=$false; SafeOutput='' }
        }
        Start-Sleep -Milliseconds 120
        Invoke-UiPump
    }
    if (-not $process.HasExited) {
        try { & taskkill.exe /PID $process.Id /T /F 2>$null | Out-Null } catch { try { $process.Kill() } catch {} }
        return [pscustomobject]@{ Success=$false; ExitCode=-2; TimedOut=$true; SafeOutput='' }
    }
    $outTask.Wait(3000) | Out-Null
    $errTask.Wait(3000) | Out-Null
    $stdout = if ($outTask.IsCompleted) { [string]$outTask.Result } else { '' }
    $stderr = if ($errTask.IsCompleted) { [string]$errTask.Result } else { '' }
    $safeOutput = ConvertTo-SafeProcessOutput (($stdout + [Environment]::NewLine + $stderr).Trim())
    return [pscustomobject]@{ Success=($process.ExitCode -eq 0); ExitCode=$process.ExitCode; TimedOut=$false; SafeOutput=$safeOutput }
}

function New-TunnelProcess {
    param(
        [Parameter(Mandatory=$true)][string]$RuntimeKey,
        [Parameter(Mandatory=$true)][string]$TunnelId,
        [Parameter(Mandatory=$true)][string]$McpCommand,
        [Parameter(Mandatory=$true)][string]$TunnelExe,
        [Parameter(Mandatory=$true)][string]$TunnelDirectory,
        [Parameter(Mandatory=$true)][string]$Scope,
        [Parameter(Mandatory=$true)][string]$OmaMode,
        [Parameter(Mandatory=$true)][string]$GmaHost,
        [Parameter(Mandatory=$true)][int]$GmaPort
    )
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $TunnelExe
    $psi.Arguments = 'run --log.level=warn --log.format=struct-text'
    $psi.WorkingDirectory = $TunnelDirectory
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.EnvironmentVariables['CONTROL_PLANE_API_KEY'] = $RuntimeKey
    $psi.EnvironmentVariables['CONTROL_PLANE_TUNNEL_ID'] = $TunnelId
    $psi.EnvironmentVariables['MCP_COMMAND'] = $McpCommand
    $psi.EnvironmentVariables['GMA_SCOPE'] = $Scope
    $psi.EnvironmentVariables['OMA_MODE'] = $OmaMode
    $psi.EnvironmentVariables['OMA_OBSERVER_AUTOSTART'] = $(if ($OmaMode -eq 'observer') { '1' } else { '0' })
    $psi.EnvironmentVariables['GMA_HOST'] = $GmaHost
    $psi.EnvironmentVariables['GMA_PORT'] = [string]$GmaPort
    $null = $psi.EnvironmentVariables.Remove('GMA_AUTH_BYPASS')

    $process = New-Object Diagnostics.Process
    $process.StartInfo = $psi
    $process.EnableRaisingEvents = $true
    $null = $process.Start()
    $process.BeginOutputReadLine()
    $process.BeginErrorReadLine()
    return $process
}

function Stop-OwnedTunnel {
    if ($script:OwnedTunnelProcess -and -not $script:OwnedTunnelProcess.HasExited) {
        $pidToStop = $script:OwnedTunnelProcess.Id
        Write-SafeLog 'Tunnel' "Eigene Prozesskette PID $pidToStop wird beendet."
        try {
            $killer = Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\taskkill.exe') -ArgumentList @('/PID',[string]$pidToStop,'/T','/F') -PassThru -WindowStyle Hidden
            $deadline = (Get-Date).AddSeconds(5)
            while (-not $killer.HasExited -and (Get-Date) -lt $deadline) {
                Start-Sleep -Milliseconds 80
                Invoke-UiPump
            }
            while (-not $script:OwnedTunnelProcess.HasExited -and (Get-Date) -lt $deadline) {
                Start-Sleep -Milliseconds 80
                Invoke-UiPump
            }
        } catch {
            try { $script:OwnedTunnelProcess.Kill() } catch { }
        }
    }
    $script:OwnedTunnelProcess = $null
    $script:ExternalTunnel = $false
}

function Play-OmaSound {
    param([ValidateSet('Start','Success','Error','Stop')][string]$Kind)
    if (-not [bool]$script:Config.SoundEnabled) { return }
    try {
        switch ($Kind) {
            'Start' { [Media.SystemSounds]::Asterisk.Play() }
            'Success' { [Media.SystemSounds]::Exclamation.Play() }
            'Error' { [Media.SystemSounds]::Hand.Play() }
            'Stop' { [Media.SystemSounds]::Beep.Play() }
        }
    } catch { }
}

function Get-StageBrush {
    param([ValidateSet('idle','running','pass','warn','error')][string]$State)
    switch ($State) {
        'running' { return '#FF00F5FF' }
        'pass' { return '#FF58FF9A' }
        'warn' { return '#FFFFC857' }
        'error' { return '#FFFF3B78' }
        default { return '#FF354052' }
    }
}

function Set-Stage {
    param([int]$Number, [string]$State, [string]$Detail)
    $entry = $script:StageControls[$Number]
    if (-not $entry) { return }
    $brush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString((Get-StageBrush $State)))
    $entry.Dot.Fill = $brush
    $entry.Detail.Text = $Detail
    $entry.Detail.Foreground = $brush
}

function Reset-Stages {
    for ($i=1; $i -le 7; $i++) { Set-Stage $i 'idle' 'WARTET' }
}

function Set-GlobalStatus {
    param([ValidateSet('idle','running','ready','warn','error')][string]$State, [string]$Text, [string]$SubText)
    $script:MainStatus.Text = $Text
    $script:MainSubStatus.Text = $SubText
    switch ($State) {
        'ready' { $color='#FF58FF9A'; $pill='#192BFF9A' }
        'running' { $color='#FF00F5FF'; $pill='#1900F5FF' }
        'warn' { $color='#FFFFC857'; $pill='#19FFC857' }
        'error' { $color='#FFFF3B78'; $pill='#19FF3B78' }
        default { $color='#FF8391A7'; $pill='#191F2A3A' }
    }
    $script:MainStatus.Foreground = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($color))
    $script:StatusPill.Background = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($pill))
    $script:StatusPillText.Text = $Text
    $script:StatusPillText.Foreground = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($color))
}

function Show-CredentialsDialog {
    $dialogXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="OMA - Sichere Zugangsdaten" Width="620" Height="470" WindowStartupLocation="CenterOwner" ResizeMode="NoResize" Background="#090E18" Foreground="#E7F7FF">
  <Window.Resources>
    <Style TargetType="TextBlock"><Setter Property="FontFamily" Value="Segoe UI"/></Style>
    <Style TargetType="PasswordBox"><Setter Property="Background" Value="#0E1726"/><Setter Property="Foreground" Value="#E7F7FF"/><Setter Property="BorderBrush" Value="#33445C"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="12"/><Setter Property="FontSize" Value="14"/></Style>
    <Style TargetType="Button"><Setter Property="Foreground" Value="#071019"/><Setter Property="Background" Value="#00F5FF"/><Setter Property="BorderThickness" Value="0"/><Setter Property="Padding" Value="18,10"/><Setter Property="FontWeight" Value="Bold"/><Setter Property="Cursor" Value="Hand"/></Style>
  </Window.Resources>
  <Border BorderBrush="#00F5FF" BorderThickness="1" Margin="12" Padding="26">
    <Grid>
      <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
      <TextBlock Text="SICHERE OMA-AKTIVIERUNG" FontSize="25" FontWeight="Bold" Foreground="#00F5FF"/>
      <TextBlock Grid.Row="1" Margin="0,8,0,20" TextWrapping="Wrap" Foreground="#9AAAC0" Text="Nur beim ersten Start: Die Werte werden mit Windows DPAPI verschlüsselt und sind ausschließlich in deinem Windows-Benutzerkonto verwendbar."/>
      <TextBlock Grid.Row="2" Text="OPENAI RUNTIME API KEY" FontWeight="SemiBold" Foreground="#FF4FD8" Margin="0,0,0,6"/>
      <PasswordBox Grid.Row="3" Name="KeyBox" ToolTip="Der Runtime-Key wird niemals angezeigt oder protokolliert."/>
      <StackPanel Grid.Row="4" Margin="0,18,0,0">
        <TextBlock Text="TUNNEL-ID" FontWeight="SemiBold" Foreground="#FF4FD8" Margin="0,0,0,6"/>
        <PasswordBox Name="TunnelBox" ToolTip="Die Tunnel-ID wird ebenfalls DPAPI-verschlüsselt."/>
        <TextBlock Name="ErrorText" Foreground="#FF3B78" Margin="0,10,0,0" TextWrapping="Wrap"/>
      </StackPanel>
      <StackPanel Grid.Row="6" Orientation="Horizontal" HorizontalAlignment="Right">
        <Button Name="CancelButton" Content="ABBRECHEN" Margin="0,0,10,0" Background="#253247" Foreground="#B7C4D6"/>
        <Button Name="SaveButton" Content="VERSCHLÜSSELT SPEICHERN"/>
      </StackPanel>
    </Grid>
  </Border>
</Window>
'@
    $reader = New-Object Xml.XmlNodeReader ([xml]$dialogXaml)
    $dialog = [Windows.Markup.XamlReader]::Load($reader)
    $dialog.Owner = $script:Window
    $keyBox = $dialog.FindName('KeyBox')
    $tunnelBox = $dialog.FindName('TunnelBox')
    $errorText = $dialog.FindName('ErrorText')
    $result = $false
    $dialog.FindName('SaveButton').Add_Click({
        $key = $keyBox.Password.Trim()
        $tunnel = $tunnelBox.Password.Trim()
        if ($key.Length -lt 12 -or $tunnel.Length -lt 8) {
            $errorText.Text = 'Bitte beide vollständigen Werte eingeben. Sie werden nur lokal verarbeitet.'
            return
        }
        try {
            Save-Secrets -RuntimeKey $key -TunnelId $tunnel
            $keyBox.Clear(); $tunnelBox.Clear()
            $script:CredentialDialogSaved = $true
            $dialog.DialogResult = $true
        } catch {
            $errorText.Text = 'Die DPAPI-Verschlüsselung ist fehlgeschlagen: ' + $_.Exception.Message
        }
    })
    $dialog.FindName('CancelButton').Add_Click({ $dialog.DialogResult = $false })
    $script:CredentialDialogSaved = $false
    $null = $dialog.ShowDialog()
    return $script:CredentialDialogSaved
}

function Update-PathLabels {
    $script:BridgePathBox.Text = [string]$script:Config.BridgePath
    $script:TunnelPathBox.Text = [string]$script:Config.TunnelPath
    $script:ConsoleHostBox.Text = [string]$script:Config.ConsoleHost
    $script:SoundToggle.IsChecked = [bool]$script:Config.SoundEnabled
    $script:AutoOpenToggle.IsChecked = [bool]$script:Config.AutoOpenChatGPT
    $script:SoundButton.Content = if ([bool]$script:Config.SoundEnabled) { 'SOUND: ON' } else { 'SOUND: OFF' }
    $script:ModeObserverButton.IsChecked = ([string]$script:Config.ModeSelection -eq 'observer')
    $script:ModeProgrammingButton.IsChecked = ([string]$script:Config.ModeSelection -eq 'programming')
    $script:ModeFullAdminButton.IsChecked = ([string]$script:Config.ModeSelection -eq 'full_admin')
    $script:SetupNoConsoleButton.IsChecked = ([string]$script:Config.SetupSelection -eq 'without_console')
    $script:SetupConsoleButton.IsChecked = ([string]$script:Config.SetupSelection -eq 'with_console')
    $profile = Get-ModeProfile ([string]$script:Config.ModeSelection)
    $setupLabel = if ([string]$script:Config.SetupSelection -eq 'with_console') { 'MIT LICHTPULT' } else { 'OHNE LICHTPULT · NUR ONPC' }
    $script:SelectionStatusText.Text = "$($profile.Label) · $setupLabel"
}

function Set-LauncherSelection {
    param([string]$Mode, [string]$Setup)
    try {
        if ($script:IsBusy) { return }
        Assert-OmaStopped
        $null = Sync-ConfigFromDisk
        $nextMode = if ([string]::IsNullOrWhiteSpace($Mode)) { [string]$script:Config.ModeSelection } else { $Mode }
        $nextSetup = if ([string]::IsNullOrWhiteSpace($Setup)) { [string]$script:Config.SetupSelection } else { $Setup }
        if ($nextMode -eq [string]$script:Config.ModeSelection -and $nextSetup -eq [string]$script:Config.SetupSelection) {
            Update-PathLabels
            return
        }
        $script:Config.ModeSelection = $nextMode
        $script:Config.SetupSelection = $nextSetup
        Save-Config $script:Config
        Update-PathLabels
        Write-SafeLog 'Launcher' "Auswahl vorgemerkt: mode=$nextMode, setup=$nextSetup." 'PASS'
        Set-GlobalStatus 'idle' 'OMA OFFLINE' 'Auswahl gespeichert. Sie wird beim Start als unveränderlicher Session-Snapshot bestätigt.'
    } catch {
        Update-PathLabels
        [Windows.MessageBox]::Show($_.Exception.Message, $script:AppName, 'OK', 'Warning') | Out-Null
    } finally {
        Set-ControlsBusy $false
    }
}

function Save-SettingsFromUi {
    try { Assert-OmaStopped } catch {
        [Windows.MessageBox]::Show($_.Exception.Message, $script:AppName, 'OK', 'Warning') | Out-Null
        return
    }
    $bridge = Resolve-ManagedBridgeRelease
    $tunnel = $script:TunnelPathBox.Text.Trim()
    $consoleHost = $script:ConsoleHostBox.Text.Trim()
    if (-not $bridge -or -not $tunnel) {
        [Windows.MessageBox]::Show('Beide Pfade müssen angegeben werden.', $script:AppName, 'OK', 'Warning') | Out-Null
        return
    }
    if ($consoleHost -and -not (Test-ValidGmaHost $consoleHost)) {
        [Windows.MessageBox]::Show('Die Pult-IP bzw. der Hostname ist ungültig.', $script:AppName, 'OK', 'Warning') | Out-Null
        return
    }
    $script:Config.BridgePath = $bridge
    $script:Config.TunnelPath = $tunnel
    $script:Config.ConsoleHost = $consoleHost
    $script:Config.SoundEnabled = [bool]$script:SoundToggle.IsChecked
    $script:Config.AutoOpenChatGPT = [bool]$script:AutoOpenToggle.IsChecked
    Save-Config $script:Config
    Update-PathLabels
    Write-SafeLog 'Settings' 'Nicht geheime Einstellungen gespeichert.' 'PASS'
    Show-MainView
}

function Show-MainView {
    $script:MainView.Visibility = 'Visible'
    $script:HelpView.Visibility = 'Collapsed'
    $script:SettingsView.Visibility = 'Collapsed'
}

function Show-HelpView {
    $script:MainView.Visibility = 'Collapsed'
    $script:HelpView.Visibility = 'Visible'
    $script:SettingsView.Visibility = 'Collapsed'
}

function Show-SettingsView {
    try { Assert-OmaStopped } catch {
        [Windows.MessageBox]::Show($_.Exception.Message, $script:AppName, 'OK', 'Information') | Out-Null
        return
    }
    $null = Sync-ConfigFromDisk
    Update-PathLabels
    $script:MainView.Visibility = 'Collapsed'
    $script:HelpView.Visibility = 'Collapsed'
    $script:SettingsView.Visibility = 'Visible'
}

function Open-ChatGPT {
    try { Start-Process 'https://chatgpt.com/' } catch { Write-SafeLog 'ChatGPT' $_.Exception.Message 'ERROR' }
}

function Open-TunnelUi {
    if (Test-HttpReady 'http://127.0.0.1:8080/ui') {
        Start-Process 'http://127.0.0.1:8080/ui'
    } else {
        [Windows.MessageBox]::Show('Die lokale Tunnel-UI ist nicht erreichbar. Starte OMA zuerst.', $script:AppName, 'OK', 'Information') | Out-Null
    }
}

function Open-LogFolder {
    Start-Process explorer.exe -ArgumentList ('/select,"{0}"' -f $script:LogPath)
}

function New-DesktopShortcut {
    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        $shortcutPath = Join-Path $desktop 'OMA GrandMAKI-BOT.lnk'
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $bootstrap = Join-Path $PSScriptRoot 'OMA_Launcher_Bootstrap.ps1'
        if (-not (Test-Path -LiteralPath $bootstrap -PathType Leaf)) { throw 'Launcher-Bootstrap fehlt.' }
        $powerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        if (-not (Test-Path -LiteralPath $powerShellExe -PathType Leaf)) {
            $powerShellExe = (Get-Command powershell.exe -ErrorAction Stop).Source
        }
        $shortcut.TargetPath = $powerShellExe
        $shortcut.Arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "' + $bootstrap + '"'
        $shortcut.WorkingDirectory = $PSScriptRoot
        $shortcut.Description = 'OMA GrandMAKI-BOT Launcher 1.2.5 sicher starten'
        $iconPath = Join-Path $PSScriptRoot 'assets\OMA.ico'
        if (Test-Path -LiteralPath $iconPath) { $shortcut.IconLocation = $iconPath }
        $shortcut.Save()
        Write-SafeLog 'Settings' 'Desktop-Verknuepfung erstellt.' 'PASS'
        [Windows.MessageBox]::Show('Desktop-Verknüpfung wurde erstellt.', $script:AppName, 'OK', 'Information') | Out-Null
    } catch {
        [Windows.MessageBox]::Show('Verknüpfung konnte nicht erstellt werden: ' + $_.Exception.Message, $script:AppName, 'OK', 'Error') | Out-Null
    }
}

function Set-ControlsBusy {
    param([bool]$Busy)
    $script:IsBusy = $Busy
    $running = Test-OmaSessionRunning
    $script:StartButton.IsEnabled = (-not $Busy -and -not $running)
    $script:RestartButton.IsEnabled = (-not $Busy -and $running)
    $script:StopButton.IsEnabled = (-not $Busy -and $running)
    $script:SettingsButton.IsEnabled = (-not $Busy -and -not $running)
    $script:SoundButton.IsEnabled = (-not $Busy -and -not $running)
    $script:ModeObserverButton.IsEnabled = (-not $Busy -and -not $running)
    $script:ModeProgrammingButton.IsEnabled = (-not $Busy -and -not $running)
    $script:ModeFullAdminButton.IsEnabled = (-not $Busy -and -not $running)
    $script:SetupNoConsoleButton.IsEnabled = (-not $Busy -and -not $running)
    $script:SetupConsoleButton.IsEnabled = (-not $Busy -and -not $running)
    $script:UpdateButton.IsEnabled = (-not $Busy -and -not $running)
    $script:DiagnosticButton.IsEnabled = (-not $Busy)
    if ($script:SessionLockText) {
        $script:SessionLockText.Text = if ($running) { 'SESSION AKTIV · ÄNDERUNGEN GESPERRT · ZUERST OMA STOPPEN' } else { 'OMA GESTOPPT · AUSWAHL UND UPDATES FREIGEGEBEN' }
        $lockColor = if ($running) { '#FFFFC857' } else { '#FF58FF9A' }
        $script:SessionLockText.Foreground = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($lockColor))
    }
}

function Open-ControlWindow {
    if (Test-HttpReady 'http://127.0.0.1:8091/v1/health/live') {
        Start-Process 'http://127.0.0.1:8091/'
    } else {
        [Windows.MessageBox]::Show('Das schreibgeschützte OMA-Kontrollfenster ist nicht erreichbar. Basement 0.5.0 prüfen.', $script:AppName, 'OK', 'Information') | Out-Null
    }
}

function Export-LauncherDiagnostic {
    if ($script:IsBusy) { return }
    $diagnosticRoot = $null
    try {
        Set-ControlsBusy $true
        $diagnosticConfig = Sync-ConfigFromDisk -RefreshUi
        $diagnosticMode = [string]$diagnosticConfig.ModeSelection
        $diagnosticSetup = [string]$diagnosticConfig.SetupSelection
        $runtimeMode = 'unavailable'
        $runtimeSetup = 'unavailable'
        $selectionConsistent = 'unknown'
        $timestamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
        $uploadRoot = Join-Path $env:USERPROFILE 'Desktop\OMA AI assistent\Uploads'
        $diagnosticRoot = Join-Path $env:TEMP ("OMA_Launcher_Phase5_Diagnostic_" + [Guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $uploadRoot -Force | Out-Null
        New-Item -ItemType Directory -Path $diagnosticRoot -Force | Out-Null

        $copyMap = @{
            $script:ConfigPath = 'launcher_config.json'
            $script:LogPath = 'launcher_runtime.log'
            (Join-Path $script:BasementRoot 'state\settings.json') = 'basement_settings.json'
            (Join-Path $script:BasementRoot 'state\launcher_session.json') = 'launcher_session.json'
            (Join-Path $script:BasementRoot 'current.json') = 'current_release.json'
            $script:LastProbeDiagnosticPath = 'last_probe_diagnostic.txt'
        }
        foreach ($source in $copyMap.Keys) {
            if (Test-Path -LiteralPath $source -PathType Leaf) {
                Copy-Item -LiteralPath $source -Destination (Join-Path $diagnosticRoot $copyMap[$source]) -Force
            }
        }
        $installedMarker = Join-Path $PSScriptRoot 'installed_launcher.json'
        if (Test-Path -LiteralPath $installedMarker -PathType Leaf) {
            Copy-Item -LiteralPath $installedMarker -Destination (Join-Path $diagnosticRoot 'installed_launcher.json') -Force
        }
        $startupLogRoot = Join-Path $script:BasementRoot 'startup_logs'
        if (Test-Path -LiteralPath $startupLogRoot -PathType Container) {
            Get-ChildItem -LiteralPath $startupLogRoot -File | Sort-Object LastWriteTime -Descending |
                Select-Object -First 12 | ForEach-Object {
                    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $diagnosticRoot ('startup_' + $_.Name)) -Force
                }
        }
        try {
            $desktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'OMA GrandMAKI-BOT.lnk'
            $shortcutShell = New-Object -ComObject WScript.Shell
            $shortcutInfo = $shortcutShell.CreateShortcut($desktopShortcut)
            [ordered]@{
                shortcut_path = $desktopShortcut
                shortcut_exists = (Test-Path -LiteralPath $desktopShortcut -PathType Leaf)
                target_path = [string]$shortcutInfo.TargetPath
                arguments = [string]$shortcutInfo.Arguments
                working_directory = [string]$shortcutInfo.WorkingDirectory
                launcher_root = $PSScriptRoot
            } | ConvertTo-Json -Depth 4 | Out-File -LiteralPath (Join-Path $diagnosticRoot 'LAUNCHER_START_PATH.json') -Encoding UTF8
        } catch {
            ('shortcut_report_error=' + $_.Exception.Message) | Out-File -LiteralPath (Join-Path $diagnosticRoot 'LAUNCHER_START_PATH_ERROR.txt') -Encoding UTF8
        }

        try {
            $runtime = Invoke-RestMethod -Uri 'http://127.0.0.1:8091/v1/status' -Method Get -TimeoutSec 3
            $runtime | ConvertTo-Json -Depth 15 | Out-File -LiteralPath (Join-Path $diagnosticRoot 'RUNTIME_STATUS.json') -Encoding UTF8
            $runtimeMode = [string]$runtime.data.mode.selected
            $runtimeSetup = [string]$runtime.data.setup.selected
            $selectionConsistent = (($diagnosticMode -eq $runtimeMode) -and ($diagnosticSetup -eq $runtimeSetup)).ToString().ToLowerInvariant()
        } catch {
            ('runtime_status_error=' + $_.Exception.Message) | Out-File -LiteralPath (Join-Path $diagnosticRoot 'RUNTIME_STATUS_ERROR.txt') -Encoding UTF8
        }

        Get-CimInstance Win32_Process | Where-Object {
            $null -ne $_.CommandLine -and $_.CommandLine -match 'oma_basement|tunnel-client|OMA_GrandMAKI'
        } | Select-Object Name,ProcessId,ParentProcessId,CreationDate,CommandLine |
            Format-List | Out-File -LiteralPath (Join-Path $diagnosticRoot 'OMA_PROCESSES.txt') -Encoding UTF8
        & netstat.exe -ano -p tcp | Out-File -LiteralPath (Join-Path $diagnosticRoot 'TCP_CONNECTIONS.txt') -Encoding UTF8

        @(
            'result=collected'
            "timestamp=$timestamp"
            "launcher_version=$($script:AppVersion)"
            'basement_version=0.5.0'
            "oma_running=$(Test-OmaSessionRunning)"
            "selected_mode=$diagnosticMode"
            "selected_setup=$diagnosticSetup"
            "runtime_selected_mode=$runtimeMode"
            "runtime_selected_setup=$runtimeSetup"
            "config_runtime_consistent=$selectionConsistent"
            'grandma_commands_executed=0'
            'active_bridge_modified=false'
            'write_gate_modified=false'
            'secrets_included=false'
        ) | Out-File -LiteralPath (Join-Path $diagnosticRoot 'SUMMARY.txt') -Encoding ASCII

        $hashLines = Get-ChildItem -LiteralPath $diagnosticRoot -File | Sort-Object Name | ForEach-Object {
            $hash = Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256
            $hash.Hash.ToLowerInvariant() + '  ' + $_.Name
        }
        $hashLines | Out-File -LiteralPath (Join-Path $diagnosticRoot 'SHA256SUMS.txt') -Encoding ASCII
        $zipPath = Join-Path $uploadRoot ("OMA_Launcher_Phase5_Diagnostic_$timestamp.zip")
        Compress-Archive -Path (Join-Path $diagnosticRoot '*') -DestinationPath $zipPath -CompressionLevel Optimal -Force
        Write-SafeLog 'Diagnose' "Diagnose-ZIP erstellt: $zipPath" 'PASS'
        [Windows.MessageBox]::Show("Diagnose-ZIP wurde erstellt:`n$zipPath`n`nDiese Datei bitte hier im Chat hochladen.", $script:AppName, 'OK', 'Information') | Out-Null
        Start-Process explorer.exe -ArgumentList ('/select,"{0}"' -f $zipPath)
    } catch {
        Write-SafeLog 'Diagnose' $_.Exception.Message 'ERROR'
        [Windows.MessageBox]::Show('Diagnose konnte nicht erstellt werden: ' + $_.Exception.Message, $script:AppName, 'OK', 'Error') | Out-Null
    } finally {
        if ($diagnosticRoot -and (Test-Path -LiteralPath $diagnosticRoot -PathType Container)) {
            Remove-Item -LiteralPath $diagnosticRoot -Recurse -Force
        }
        Set-ControlsBusy $false
    }
}

function Start-OmaSequence {
    if ($script:IsBusy) { return }
    Set-ControlsBusy $true
    Reset-Stages
    Set-GlobalStatus 'running' 'SYSTEMCHECK' 'OMA prüft die vollständige Verbindungskette.'
    Play-OmaSound 'Start'
    Write-SafeLog 'Start' "OMA Launcher $($script:AppVersion) startet Sicherheitssequenz."

    try {
        $null = Sync-ConfigFromDisk -RefreshUi
        $session = Prepare-OmaSession
        $profile = Get-ModeProfile ([string]$script:Config.ModeSelection)
        $connectionProfile = Get-ConnectionProfile ([string]$script:Config.SetupSelection)
        Write-SafeLog 'Session' "Unveränderlicher Snapshot $($session.session_id): mode=$($script:Config.ModeSelection), setup=$($script:Config.SetupSelection), scope=$($profile.Scope)." 'PASS'
        # 1: grandMA2 / Telnet
        Set-Stage 1 'running' ("PRÜFT {0}:30000" -f $connectionProfile.Host)
        Invoke-UiPump
        if (-not (Test-TcpPort -HostName ([string]$connectionProfile.Host) -Port ([int]$connectionProfile.Port))) {
            Set-Stage 1 'error' 'PORT 30000 NICHT ERREICHBAR'
            throw [InvalidOperationException]::new('MA2_PORT: Das gewählte grandMA2-Ziel ist nicht erreichbar. grandMA2 starten, Show laden und Telnet Login/Remote = Enabled prüfen.')
        }
        if ($script:Closing) { throw [OperationCanceledException]::new('START_ABORT: OMA wurde während des Starts geschlossen.') }
        Set-Stage 1 'pass' ("ONLINE // {0}:30000" -f $connectionProfile.Host)
        Write-SafeLog 'grandMA2' "Ziel $($connectionProfile.Host):$($connectionProfile.Port) erreichbar; Profil=$($connectionProfile.Name)." 'PASS'

        # 2: Bridge-Dateien
        Set-Stage 2 'running' 'PRÜFT PROJEKTDATEIEN'
        $bridgePath = [string]$script:Config.BridgePath
        $pythonExe = Resolve-BasementPython
        $runMcp = Join-Path $bridgePath 'run_mcp.py'
        $requiredBridge = @($bridgePath, $runMcp)
        $missing = @($requiredBridge | Where-Object { -not (Test-Path -LiteralPath $_) })
        if ($missing.Count -gt 0) {
            Set-Stage 2 'error' 'BRIDGE-DATEI FEHLT'
            throw [IO.FileNotFoundException]::new('BRIDGE_PATH: Benötigte Bridge-Datei fehlt. Pfade unter Einstellungen prüfen.')
        }
        Set-Stage 2 'pass' 'BRIDGE VOLLSTÄNDIG'
        Write-SafeLog 'Bridge' 'Verifizierter A/B-Quellslot, run_mcp.py und getrennte lokale Python-Laufzeit vorhanden.' 'PASS'

        # 3: Tunnel-Dateien
        Set-Stage 3 'running' 'PRÜFT TUNNEL-CLIENT'
        $tunnelPath = [string]$script:Config.TunnelPath
        $tunnelExe = Join-Path $tunnelPath 'tunnel-client.exe'
        if (-not (Test-Path -LiteralPath $tunnelExe)) {
            Set-Stage 3 'error' 'TUNNEL-CLIENT FEHLT'
            throw [IO.FileNotFoundException]::new('TUNNEL_PATH: tunnel-client.exe wurde nicht gefunden. Pfad unter Einstellungen prüfen.')
        }
        Set-Stage 3 'pass' 'TUNNEL-CLIENT GEFUNDEN'
        Write-SafeLog 'Tunnel' 'tunnel-client.exe vorhanden.' 'PASS'

        # 4: DPAPI secrets and enforced scope
        Set-Stage 4 'running' 'LÄDT DPAPI-ZUGANG'
        $secrets = Get-Secrets
        if (-not $secrets) {
            if (-not (Show-CredentialsDialog)) {
                Set-Stage 4 'warn' 'EINGABE ABGEBROCHEN'
                throw [OperationCanceledException]::new('SECRETS: Sichere Zugangseingabe wurde abgebrochen.')
            }
            $secrets = Get-Secrets
        }
        if (-not $secrets) {
            Set-Stage 4 'error' 'DPAPI-ZUGANG UNGÜLTIG'
            throw [Security.SecurityException]::new('SECRETS: Zugangsdaten konnten nicht entschlüsselt werden. Unter Einstellungen neu eingeben.')
        }
        Set-Stage 4 'pass' ("DPAPI OK // {0}" -f $profile.Scope.ToUpperInvariant())
        Write-SafeLog 'Security' "DPAPI entschluesselt; Session-Scope fest auf $($profile.Scope), OMA_MODE=$($profile.OmaMode)." 'PASS'

        $mcpCommand = ('{0} {1}' -f $pythonExe.Replace('\','/'), $runMcp.Replace('\','/'))
        $expectedBuild = Get-ExpectedBridgeBuild -BridgeRoot $bridgePath
        $childEnvironment = @{
            'CONTROL_PLANE_API_KEY' = $secrets.RuntimeKey
            'CONTROL_PLANE_TUNNEL_ID' = $secrets.TunnelId
            'MCP_COMMAND' = $mcpCommand
            'GMA_SCOPE' = $profile.Scope
            'OMA_MODE' = $profile.OmaMode
            'OMA_OBSERVER_AUTOSTART' = $(if ($profile.OmaMode -eq 'observer') { '1' } else { '0' })
            'GMA_HOST' = [string]$connectionProfile.Host
            'GMA_PORT' = [string]$connectionProfile.Port
            'OMA_EXPECTED_BUILD_SHA256' = $expectedBuild
            'PYTHONNOUSERSITE' = '1'
            'PYTHONPATH' = $bridgePath
        }

        # 5a: Exact runtime identity before any tunnel can start.
        Set-Stage 5 'running' 'RUNTIME-PREFLIGHT'
        $preflightArguments = '-m src.runtime_preflight --expected-root "{0}" --expected-build {1} --expected-mode {2} --expected-scope {3}' -f $bridgePath.Replace('"','\"'), $expectedBuild, $profile.OmaMode, $profile.Scope
        $preflight = Invoke-ProcessCheck -FileName $pythonExe -Arguments $preflightArguments -WorkingDirectory $bridgePath -Environment $childEnvironment -TimeoutSeconds ([int]$script:Config.ProbeTimeoutSeconds)
        if (-not $preflight.Success) {
            $reason = if ($preflight.TimedOut) { 'TIMEOUT' } else { "EXIT $($preflight.ExitCode)" }
            Save-LastProbeDiagnostic -Stage 'runtime_preflight' -Target ("{0}:{1}" -f $connectionProfile.Host,$connectionProfile.Port) -Result $preflight
            Set-Stage 5 'error' "PREFLIGHT FEHLER // $reason"
            throw [Security.SecurityException]::new("RUNTIME_SOURCE_MISMATCH: Die aktive Bridge-Quelle wurde nicht bestätigt ($reason). Keine Showänderung wurde ausgeführt.")
        }
        Write-SafeLog 'Bridge' "Runtime-Preflight bestanden: Ziel=$($connectionProfile.Host):$($connectionProfile.Port), build=$expectedBuild, mode=$($profile.OmaMode), scope=$($profile.Scope)." 'PASS'

        # 5b: One bounded read-only request against the exact selected target.
        Set-Stage 5 'running' 'SAFE_READ BRIDGE-PROBE'
        $probeEnvironment = @{
            'GMA_SCOPE'='tier:0'
            'OMA_MODE'='observer'
            'GMA_HOST'=[string]$connectionProfile.Host
            'GMA_PORT'=[string]$connectionProfile.Port
            'OMA_EXPECTED_BUILD_SHA256'=$expectedBuild
            'PYTHONNOUSERSITE'='1'
            'PYTHONPATH'=$bridgePath
        }
        $probe = Invoke-ProcessCheck -FileName $pythonExe -Arguments '-m scripts.probe_onpc_state' -WorkingDirectory $bridgePath -Environment $probeEnvironment -TimeoutSeconds ([int]$script:Config.ProbeTimeoutSeconds)
        if (-not $probe.Success) {
            $reason = if ($probe.TimedOut) { 'TIMEOUT' } else { "EXIT $($probe.ExitCode)" }
            Save-LastProbeDiagnostic -Stage 'safe_read_probe' -Target ("{0}:{1}" -f $connectionProfile.Host,$connectionProfile.Port) -Result $probe
            Set-Stage 5 'error' "SAFE_READ FEHLER // $reason"
            $safeDetail = if ([string]::IsNullOrWhiteSpace([string]$probe.SafeOutput)) { '' } else { ' · ' + [string]$probe.SafeOutput }
            throw [InvalidOperationException]::new("MCP_PROBE: Der Read-only-Probe für $($connectionProfile.Host):$($connectionProfile.Port) ist fehlgeschlagen ($reason)$safeDetail. Keine Showänderung wurde ausgeführt.")
        }
        if (Test-Path -LiteralPath $script:LastProbeDiagnosticPath -PathType Leaf) { Remove-Item -LiteralPath $script:LastProbeDiagnosticPath -Force }
        Set-Stage 5 'pass' 'SAFE_READ BESTANDEN'
        Write-SafeLog 'Probe' 'Direkter Read-only-Probe erfolgreich; Taxonomy-Helper nicht verwendet.' 'PASS'

        # 6: doctor then tunnel run. Never expose command output because it may contain identifiers.
        Set-Stage 6 'running' 'TUNNEL DOCTOR'
        if (Test-HttpReady 'http://127.0.0.1:8080/readyz') {
            throw [InvalidOperationException]::new('EXTERNAL_SESSION: Ein Tunnel wurde parallel gestartet. OMA-Start aus Sicherheitsgründen gestoppt; zuerst diese Session vollständig beenden.')
        } else {
            Stop-OwnedTunnel
            $doctor = Invoke-ProcessCheck -FileName $tunnelExe -Arguments 'doctor --explain' -WorkingDirectory $tunnelPath -Environment $childEnvironment -TimeoutSeconds 35
            if (-not $doctor.Success) {
                $reason = if ($doctor.TimedOut) { 'TIMEOUT' } else { "EXIT $($doctor.ExitCode)" }
                Set-Stage 6 'error' "DOCTOR FEHLER // $reason"
                throw [InvalidOperationException]::new("TUNNEL_DOCTOR: Tunnel-Konfiguration wurde abgelehnt ($reason). Zugangsdaten unter Einstellungen ggf. neu eingeben.")
            }
            if ($script:Closing) { throw [OperationCanceledException]::new('START_ABORT: OMA wurde während des Tunnel-Checks geschlossen.') }
            Write-SafeLog 'Tunnel' 'doctor --explain erfolgreich; Ausgabe aus Geheimnisschutz nicht protokolliert.' 'PASS'
            $script:OwnedTunnelProcess = New-TunnelProcess -RuntimeKey $secrets.RuntimeKey -TunnelId $secrets.TunnelId -McpCommand $mcpCommand -TunnelExe $tunnelExe -TunnelDirectory $tunnelPath -Scope $profile.Scope -OmaMode $profile.OmaMode -GmaHost ([string]$connectionProfile.Host) -GmaPort ([int]$connectionProfile.Port)
            Set-Stage 6 'pass' "GESTARTET // PID $($script:OwnedTunnelProcess.Id)"
        }

        # discard plaintext references as early as PowerShell permits
        $secrets = $null
        $childEnvironment = $null

        # 7: official readiness surfaces
        Set-Stage 7 'running' 'WARTET AUF /READYZ'
        $deadline = (Get-Date).AddSeconds([int]$script:Config.ReadyTimeoutSeconds)
        $ready = $false
        while ((Get-Date) -lt $deadline) {
            if ($script:Closing) { throw [OperationCanceledException]::new('START_ABORT: OMA wurde während des Ready-Checks geschlossen.') }
            if ($script:OwnedTunnelProcess -and $script:OwnedTunnelProcess.HasExited) {
                throw [InvalidOperationException]::new("TUNNEL_PROCESS: tunnel-client wurde vor Ready beendet (Exit $($script:OwnedTunnelProcess.ExitCode)).")
            }
            if ((Test-HttpReady 'http://127.0.0.1:8080/healthz') -and (Test-HttpReady 'http://127.0.0.1:8080/readyz')) {
                $ready = $true; break
            }
            Start-Sleep -Milliseconds 550
            Invoke-UiPump
        }
        if (-not $ready) {
            Set-Stage 7 'error' 'READY TIMEOUT'
            throw [TimeoutException]::new('TUNNEL_READY: healthz/readyz wurde nicht rechtzeitig grün. Tunnel-UI oder Log öffnen.')
        }
        Set-Stage 7 'pass' 'PLUGIN-TRANSPORT BEREIT'
        Write-SafeLog 'Ready' 'healthz und readyz erfolgreich. Plugin-Transport ist erreichbar.' 'PASS'
        Activate-OmaSession

        Set-GlobalStatus 'ready' ("{0} AKTIV" -f $profile.Label) 'Session-Konfiguration ist gesperrt. Für Änderungen zuerst OMA STOPPEN.'
        Play-OmaSound 'Success'
        if ([bool]$script:Config.AutoOpenChatGPT) { Open-ChatGPT }
    } catch {
        $message = $_.Exception.Message
        Write-SafeLog 'Start' $message 'ERROR'
        Set-GlobalStatus 'error' 'VERBINDUNG GESTOPPT' $message
        Play-OmaSound 'Error'
        if ($script:OwnedTunnelProcess -and -not (Test-HttpReady 'http://127.0.0.1:8080/readyz')) {
            Stop-OwnedTunnel
        }
        if (-not (Test-OmaSessionRunning)) {
            try { Release-OmaSession } catch { Write-SafeLog 'Session' $_.Exception.Message 'WARN' }
        }
    } finally {
        Set-ControlsBusy $false
    }
}

function Stop-OmaSequence {
    if ($script:IsBusy) { return }
    Set-ControlsBusy $true
    try {
        if ($script:ExternalTunnel) {
            Write-SafeLog 'Stop' 'Externe Tunnel-Instanz bleibt aus Sicherheitsgruenden aktiv.' 'WARN'
            Set-GlobalStatus 'warn' 'EXTERNE INSTANZ' 'Der bereits vorher laufende Tunnel wurde nicht beendet.'
        } else {
            Stop-OwnedTunnel
            Release-OmaSession
            Reset-Stages
            Set-GlobalStatus 'idle' 'OMA OFFLINE' 'grandMA2 läuft unabhängig weiter. OMA kann jederzeit erneut gestartet werden.'
            Write-SafeLog 'Stop' 'Eigene OMA-Tunnel-Prozesskette beendet.' 'PASS'
        }
        Play-OmaSound 'Stop'
    } catch {
        $message = $_.Exception.Message
        Write-SafeLog 'Stop' $message 'ERROR'
        Set-GlobalStatus 'error' 'STOPP NICHT ABGESCHLOSSEN' 'OMA bleibt sicher gesperrt. Bitte Diagnose-ZIP erstellen.'
        [Windows.MessageBox]::Show($message, $script:AppName, 'OK', 'Warning') | Out-Null
    } finally { Set-ControlsBusy $false }
}

function Restart-OmaSequence {
    if ($script:IsBusy) { return }
    if ($script:ExternalTunnel) {
        [Windows.MessageBox]::Show('Eine externe OMA-Session kann nicht sicher neu gestartet werden. Zuerst extern vollständig stoppen.', $script:AppName, 'OK', 'Warning') | Out-Null
        return
    }
    Stop-OwnedTunnel
    try { Release-OmaSession } catch { Write-SafeLog 'Session' $_.Exception.Message 'WARN' }
    Start-OmaSequence
}

$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="OMA GrandMAKI-BOT" Width="1280" Height="900" MinWidth="1120" MinHeight="780" WindowStartupLocation="CenterScreen" Background="#060A12" Foreground="#E6F8FF" FontFamily="Segoe UI">
  <Window.Resources>
    <LinearGradientBrush x:Key="NeonGradient" StartPoint="0,0" EndPoint="1,0"><GradientStop Color="#00F5FF" Offset="0"/><GradientStop Color="#8D5CFF" Offset="0.52"/><GradientStop Color="#FF4FD8" Offset="1"/></LinearGradientBrush>
    <Style x:Key="CyberButton" TargetType="Button">
      <Setter Property="Foreground" Value="#DDFBFF"/><Setter Property="Background" Value="#111C2B"/><Setter Property="BorderBrush" Value="#2C5570"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="18,11"/><Setter Property="Margin" Value="0,0,10,0"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="FontSize" Value="13"/><Setter Property="Cursor" Value="Hand"/>
      <Style.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter Property="BorderBrush" Value="#00F5FF"/><Setter Property="Foreground" Value="#00F5FF"/><Setter Property="Background" Value="#142A39"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.35"/></Trigger></Style.Triggers>
    </Style>
    <Style x:Key="PrimaryButton" TargetType="Button" BasedOn="{StaticResource CyberButton}"><Setter Property="Foreground" Value="#051015"/><Setter Property="Background" Value="#00F5FF"/><Setter Property="BorderBrush" Value="#70FBFF"/><Setter Property="FontWeight" Value="Bold"/><Style.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#72FBFF"/><Setter Property="Foreground" Value="#051015"/></Trigger></Style.Triggers></Style>
    <Style x:Key="DangerButton" TargetType="Button" BasedOn="{StaticResource CyberButton}"><Setter Property="BorderBrush" Value="#B22A56"/><Setter Property="Foreground" Value="#FF6C9A"/><Style.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#351426"/><Setter Property="BorderBrush" Value="#FF3B78"/></Trigger></Style.Triggers></Style>
    <Style x:Key="ChoiceButton" TargetType="ToggleButton"><Setter Property="Foreground" Value="#DDFBFF"/><Setter Property="Background" Value="#07131A"/><Setter Property="BorderBrush" Value="#00F5FF"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="12,9"/><Setter Property="Margin" Value="0,0,7,0"/><Setter Property="FontWeight" Value="Bold"/><Setter Property="Cursor" Value="Hand"/><Style.Triggers><Trigger Property="IsChecked" Value="True"><Setter Property="Background" Value="#FFFFB000"/><Setter Property="Foreground" Value="#FF07131A"/><Setter Property="BorderBrush" Value="#FFFFD166"/></Trigger><Trigger Property="IsMouseOver" Value="True"><Setter Property="BorderBrush" Value="#FFFFB000"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.38"/></Trigger></Style.Triggers></Style>
    <Style x:Key="Card" TargetType="Border"><Setter Property="Background" Value="#B30C1421"/><Setter Property="BorderBrush" Value="#26384D"/><Setter Property="BorderThickness" Value="1"/><Setter Property="CornerRadius" Value="4"/><Setter Property="Padding" Value="22"/></Style>
    <Style TargetType="TextBox"><Setter Property="Background" Value="#0A1321"/><Setter Property="Foreground" Value="#DDF7FF"/><Setter Property="BorderBrush" Value="#31435B"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="10"/><Setter Property="FontFamily" Value="Consolas"/></Style>
    <Style TargetType="CheckBox"><Setter Property="Foreground" Value="#C6D4E7"/><Setter Property="Margin" Value="0,8,0,0"/></Style>
  </Window.Resources>
  <Grid>
    <Grid.Background><RadialGradientBrush Center="0.72,0.12" GradientOrigin="0.72,0.12" RadiusX="0.9" RadiusY="0.9"><GradientStop Color="#1B183B59" Offset="0"/><GradientStop Color="#070B13" Offset="0.55"/><GradientStop Color="#04070D" Offset="1"/></RadialGradientBrush></Grid.Background>
    <Canvas IsHitTestVisible="False" Opacity="0.16">
      <Line X1="0" Y1="130" X2="1180" Y2="130" Stroke="#00F5FF" StrokeThickness="1"/>
      <Line X1="0" Y1="690" X2="1180" Y2="690" Stroke="#FF4FD8" StrokeThickness="1"/>
      <Line Name="ScanLine" X1="0" Y1="0" X2="1180" Y2="0" Stroke="#00F5FF" StrokeThickness="2" Opacity="0.35"/>
    </Canvas>
    <Grid Margin="28">
      <Grid.RowDefinitions><RowDefinition Height="78"/><RowDefinition Height="*"/><RowDefinition Height="44"/></Grid.RowDefinitions>
      <Grid Grid.Row="0">
        <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
          <Border Width="46" Height="46" BorderBrush="{StaticResource NeonGradient}" BorderThickness="2" CornerRadius="3" Margin="0,0,15,0"><Grid><TextBlock Text="O" FontSize="26" FontWeight="Black" Foreground="#00F5FF" HorizontalAlignment="Center" VerticalAlignment="Center"/><Border BorderBrush="#FF4FD8" BorderThickness="0,0,3,3" Margin="4"/></Grid></Border>
          <StackPanel><TextBlock Text="OMA // GRANDMAKI-BOT" FontSize="25" FontWeight="Bold"/><TextBlock Text="SECURE GRANDMA2 INTELLIGENCE BRIDGE" Foreground="#6E829F" FontSize="11" Margin="1,4,0,0"/></StackPanel>
        </StackPanel>
        <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
          <Border Name="StatusPill" Background="#191F2A3A" BorderBrush="#30425A" BorderThickness="1" CornerRadius="14" Padding="14,6" Margin="0,0,10,0"><StackPanel Orientation="Horizontal"><Ellipse Width="7" Height="7" Fill="#00F5FF" Margin="0,0,8,0"/><TextBlock Name="StatusPillText" Text="OMA OFFLINE" Foreground="#8391A7" FontSize="11" FontWeight="Bold"/></StackPanel></Border>
          <Button Name="HelpButton" Content="?" Style="{StaticResource CyberButton}" Width="42" Height="38" Padding="0" FontSize="18" Margin="0,0,8,0" ToolTip="Hilfe und Tutorial"/>
          <Button Name="SettingsButton" Content="⚙" Style="{StaticResource CyberButton}" Width="42" Height="38" Padding="0" FontSize="17" Margin="0" ToolTip="Einstellungen"/>
        </StackPanel>
      </Grid>

      <Grid Grid.Row="1" Name="MainView">
        <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
        <Border Style="{StaticResource Card}" BorderBrush="#31546A" Margin="0,0,0,16" Padding="18">
          <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
            <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
              <StackPanel><TextBlock Name="MainStatus" Text="OMA OFFLINE" FontSize="32" FontWeight="Bold" Foreground="#8391A7"/><TextBlock Name="MainSubStatus" Text="Modus und Aufbau wählen, dann OMA starten." Foreground="#9BAABD" TextWrapping="Wrap" Margin="0,5,20,0" FontSize="13"/></StackPanel>
              <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center"><Button Name="StartButton" Content="OMA STARTEN" Style="{StaticResource PrimaryButton}" MinWidth="150"/><Button Name="StopButton" Content="OMA STOPPEN" Style="{StaticResource DangerButton}" MinWidth="130"/><Button Name="RestartButton" Content="NEUSTART" Style="{StaticResource CyberButton}" MinWidth="105" Margin="0"/></StackPanel>
            </Grid>
            <Grid Grid.Row="1" Margin="0,15,0,0"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions><Grid.ColumnDefinitions><ColumnDefinition Width="1.25*"/><ColumnDefinition Width="1.05*"/><ColumnDefinition Width="1.1*"/></Grid.ColumnDefinitions>
              <StackPanel Grid.Column="0"><TextBlock Text="ACTIVE MODE" Foreground="#FF4FD8" FontWeight="Bold" FontSize="11" Margin="0,0,0,7"/><StackPanel Orientation="Horizontal"><ToggleButton Name="ModeObserverButton" Content="OBSERVER" Style="{StaticResource ChoiceButton}"/><ToggleButton Name="ModeProgrammingButton" Content="PROGRAMMING" Style="{StaticResource ChoiceButton}"/><ToggleButton Name="ModeFullAdminButton" Content="FULL ADMIN" Style="{StaticResource ChoiceButton}" Margin="0"/></StackPanel></StackPanel>
              <StackPanel Grid.Column="1" Margin="20,0,0,0"><TextBlock Text="MA2 AUFBAU" Foreground="#FF4FD8" FontWeight="Bold" FontSize="11" Margin="0,0,0,7"/><StackPanel Orientation="Horizontal"><ToggleButton Name="SetupNoConsoleButton" Content="NUR ONPC" Style="{StaticResource ChoiceButton}"/><ToggleButton Name="SetupConsoleButton" Content="MIT LICHTPULT" Style="{StaticResource ChoiceButton}" Margin="0"/></StackPanel></StackPanel>
              <StackPanel Grid.Column="2" Margin="20,0,0,0"><TextBlock Text="OMA UPDATE" Foreground="#FF4FD8" FontWeight="Bold" FontSize="11"/><TextBlock Name="UpdateStatusText" Text="Signierter Kanal wird geprüft" Foreground="#9BAABD" FontSize="11" Margin="0,3,0,4" TextTrimming="CharacterEllipsis"/><Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><ProgressBar Name="UpdateProgress" Height="8" Minimum="0" Maximum="100" Value="0" VerticalAlignment="Center"/><Button Grid.Column="1" Name="UpdateButton" Content="UPDATES PRÜFEN" Style="{StaticResource CyberButton}" Padding="10,7" Margin="10,0,0,0"/></Grid></StackPanel>
              <StackPanel Grid.Row="1" Grid.ColumnSpan="3" Margin="0,7,0,0"><TextBlock Name="SelectionStatusText" Text="FULL ADMIN · OHNE LICHTPULT · NUR ONPC" Foreground="#00F5FF" FontWeight="Bold" FontSize="11"/><TextBlock Name="SessionLockText" Text="OMA GESTOPPT · AUSWAHL UND UPDATES FREIGEGEBEN" Foreground="#58FF9A" FontFamily="Consolas" FontSize="10"/></StackPanel>
            </Grid>
          </Grid>
        </Border>
        <Grid Grid.Row="1"><Grid.ColumnDefinitions><ColumnDefinition Width="1.08*"/><ColumnDefinition Width="16"/><ColumnDefinition Width="0.92*"/></Grid.ColumnDefinitions>
          <Border Grid.Column="0" Style="{StaticResource Card}">
            <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
              <StackPanel><TextBlock Text="BOOT SEQUENCE" FontSize="12" FontWeight="Bold" Foreground="#FF4FD8"/><TextBlock Text="Sichere Verbindungskette" FontSize="21" FontWeight="SemiBold" Margin="0,5,0,17"/></StackPanel>
              <StackPanel Grid.Row="1">
                <Grid Margin="0,5"><Grid.ColumnDefinitions><ColumnDefinition Width="24"/><ColumnDefinition/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions><Ellipse Name="StageDot1" Width="10" Height="10" Fill="#354052" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Text="01  GRANDMA2 / TELNET" FontWeight="SemiBold"/><TextBlock Grid.Column="2" Name="StageDetail1" Text="WARTET" HorizontalAlignment="Right" Foreground="#647187" FontFamily="Consolas" FontSize="11"/></Grid>
                <Border Height="1" Background="#1C2B3D" Margin="24,9,0,9"/>
                <Grid Margin="0,5"><Grid.ColumnDefinitions><ColumnDefinition Width="24"/><ColumnDefinition/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions><Ellipse Name="StageDot2" Width="10" Height="10" Fill="#354052" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Text="02  MCP BRIDGE" FontWeight="SemiBold"/><TextBlock Grid.Column="2" Name="StageDetail2" Text="WARTET" HorizontalAlignment="Right" Foreground="#647187" FontFamily="Consolas" FontSize="11"/></Grid>
                <Border Height="1" Background="#1C2B3D" Margin="24,9,0,9"/>
                <Grid Margin="0,5"><Grid.ColumnDefinitions><ColumnDefinition Width="24"/><ColumnDefinition/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions><Ellipse Name="StageDot3" Width="10" Height="10" Fill="#354052" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Text="03  TUNNEL CLIENT" FontWeight="SemiBold"/><TextBlock Grid.Column="2" Name="StageDetail3" Text="WARTET" HorizontalAlignment="Right" Foreground="#647187" FontFamily="Consolas" FontSize="11"/></Grid>
                <Border Height="1" Background="#1C2B3D" Margin="24,9,0,9"/>
                <Grid Margin="0,5"><Grid.ColumnDefinitions><ColumnDefinition Width="24"/><ColumnDefinition/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions><Ellipse Name="StageDot4" Width="10" Height="10" Fill="#354052" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Text="04  SECURITY / DPAPI" FontWeight="SemiBold"/><TextBlock Grid.Column="2" Name="StageDetail4" Text="WARTET" HorizontalAlignment="Right" Foreground="#647187" FontFamily="Consolas" FontSize="11"/></Grid>
                <Border Height="1" Background="#1C2B3D" Margin="24,9,0,9"/>
                <Grid Margin="0,5"><Grid.ColumnDefinitions><ColumnDefinition Width="24"/><ColumnDefinition/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions><Ellipse Name="StageDot5" Width="10" Height="10" Fill="#354052" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Text="05  SAFE_READ PROBE" FontWeight="SemiBold"/><TextBlock Grid.Column="2" Name="StageDetail5" Text="WARTET" HorizontalAlignment="Right" Foreground="#647187" FontFamily="Consolas" FontSize="11"/></Grid>
                <Border Height="1" Background="#1C2B3D" Margin="24,9,0,9"/>
                <Grid Margin="0,5"><Grid.ColumnDefinitions><ColumnDefinition Width="24"/><ColumnDefinition/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions><Ellipse Name="StageDot6" Width="10" Height="10" Fill="#354052" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Text="06  SECURE MCP TUNNEL" FontWeight="SemiBold"/><TextBlock Grid.Column="2" Name="StageDetail6" Text="WARTET" HorizontalAlignment="Right" Foreground="#647187" FontFamily="Consolas" FontSize="11"/></Grid>
                <Border Height="1" Background="#1C2B3D" Margin="24,9,0,9"/>
                <Grid Margin="0,5"><Grid.ColumnDefinitions><ColumnDefinition Width="24"/><ColumnDefinition/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions><Ellipse Name="StageDot7" Width="10" Height="10" Fill="#354052" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Text="07  CHATGPT PLUGIN-TRANSPORT" FontWeight="SemiBold"/><TextBlock Grid.Column="2" Name="StageDetail7" Text="WARTET" HorizontalAlignment="Right" Foreground="#647187" FontFamily="Consolas" FontSize="11"/></Grid>
              </StackPanel>
            </Grid>
          </Border>
          <Grid Grid.Column="2"><Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="14"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
            <Border Style="{StaticResource Card}"><Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><StackPanel><TextBlock Text="DIAGNOSTIC STREAM" FontSize="12" FontWeight="Bold" Foreground="#00F5FF"/><TextBlock Text="Geheimnisfreies Live-Protokoll" FontSize="18" FontWeight="SemiBold" Margin="0,5,0,13"/></StackPanel><TextBox Name="LogBox" Grid.Row="1" IsReadOnly="True" VerticalScrollBarVisibility="Auto" TextWrapping="Wrap" FontSize="11" Background="#070D16" BorderBrush="#1E344A" Foreground="#88D7E0"/></Grid></Border>
            <Border Grid.Row="2" Style="{StaticResource Card}" Padding="16"><StackPanel><TextBlock Text="QUICK ACCESS" FontSize="11" Foreground="#FF4FD8" FontWeight="Bold" Margin="0,0,0,10"/><WrapPanel><Button Name="ChatGPTButton" Content="CHATGPT ÖFFNEN" Style="{StaticResource CyberButton}"/><Button Name="StatusButton" Content="KONTROLLFENSTER" Style="{StaticResource CyberButton}"/><Button Name="DiagnosticButton" Content="DIAGNOSE ZIP" Style="{StaticResource CyberButton}"/><Button Name="TunnelUiButton" Content="TUNNEL UI" Style="{StaticResource CyberButton}"/><Button Name="SoundButton" Content="SOUND: ON" Style="{StaticResource CyberButton}" Margin="0"/></WrapPanel></StackPanel></Border>
          </Grid>
        </Grid>
      </Grid>

      <Grid Grid.Row="1" Name="HelpView" Visibility="Collapsed">
        <Border Style="{StaticResource Card}"><Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
          <StackPanel><TextBlock Text="OMA // HILFE-TUTORIAL" FontSize="27" FontWeight="Bold" Foreground="#00F5FF"/><TextBlock Text="Vom grandMA2-Start bis zum ersten ChatGPT-Auftrag" Foreground="#9AAAC0" Margin="0,5,0,18"/></StackPanel>
          <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto"><StackPanel Margin="0,0,20,0">
            <Border BorderBrush="#234157" BorderThickness="0,0,0,1" Padding="0,10,0,15"><StackPanel><TextBlock Text="01  GRANDMA2 VORBEREITEN" Foreground="#FF4FD8" FontWeight="Bold"/><TextBlock Text="grandMA2 onPC starten und die gewünschte Show laden. Der zuletzt bestätigte Stand ist grandMA2 3.9.63.6. OMA startet oder verändert grandMA2 selbst nicht." TextWrapping="Wrap" Margin="0,6,0,0" Foreground="#C2D0E2"/></StackPanel></Border>
            <Border BorderBrush="#234157" BorderThickness="0,0,0,1" Padding="0,15"><StackPanel><TextBlock Text="02  TELNET AKTIVIEREN" Foreground="#FF4FD8" FontWeight="Bold"/><TextBlock Text="In grandMA2 muss Telnet Login/Remote auf Enabled stehen. Bei Nur onPC erzwingt OMA 127.0.0.1:30000; bei Mit Lichtpult verwendet OMA ausschließlich die gespeicherte Pult-IP. Der sichtbare Operator darf dein normales Profil bleiben; die Bridge meldet sich getrennt als AI_BRIDGE an." TextWrapping="Wrap" Margin="0,6,0,0" Foreground="#C2D0E2"/></StackPanel></Border>
            <Border BorderBrush="#234157" BorderThickness="0,0,0,1" Padding="0,15"><StackPanel><TextBlock Text="03  MODUS UND AUFBAU WÄHLEN" Foreground="#FF4FD8" FontWeight="Bold"/><TextBlock Text="Im Launcher Observer, Programming oder Full Admin sowie Nur onPC oder Mit Lichtpult wählen. Diese Auswahl ist ausschließlich bei OMA OFFLINE möglich und wird beim Start als unveränderlicher Session-Snapshot fixiert." TextWrapping="Wrap" Margin="0,6,0,0" Foreground="#C2D0E2"/></StackPanel></Border>
            <Border BorderBrush="#234157" BorderThickness="0,0,0,1" Padding="0,15"><StackPanel><TextBlock Text="04  CYBERCHECK ABWARTEN" Foreground="#FF4FD8" FontWeight="Bold"/><TextBlock Text="Der Launcher prüft Port, Dateien, DPAPI, den lokalen SAFE_READ-Probe, tunnel-client doctor sowie /healthz und /readyz. Er verwendet ausdrücklich nicht suggest_tool_for_task, weil dessen fehlende Taxonomie den MCP-Unterprozess bereits beendet hat." TextWrapping="Wrap" Margin="0,6,0,0" Foreground="#C2D0E2"/></StackPanel></Border>
            <Border BorderBrush="#234157" BorderThickness="0,0,0,1" Padding="0,15"><StackPanel><TextBlock Text="05  CHATGPT VERBINDEN" Foreground="#FF4FD8" FontWeight="Bold"/><TextBlock Text="Bei OMA IST BEREIT ChatGPT öffnen. Im Plus-Menü Developer Mode wählen und das bereits installierte Plugin „grandMA2 AI Bridge“ aktivieren. Kein neues Plugin anlegen. Der lokale Launcher kann die ChatGPT-Auswahl nicht automatisch anklicken; er bestätigt den vollständigen Transport bis zur Plugin-Schnittstelle." TextWrapping="Wrap" Margin="0,6,0,0" Foreground="#C2D0E2"/></StackPanel></Border>
            <Border BorderBrush="#234157" BorderThickness="0,0,0,1" Padding="0,15"><StackPanel><TextBlock Text="06  SESSION-REGEL" Foreground="#FF4FD8" FontWeight="Bold"/><TextBlock Text="Während OMA aktiv ist, sind Modus, Aufbau, Einstellungen, Zugangsdaten und Updates gesperrt. Für jede Änderung zuerst OMA STOPPEN. Der Browser ist ein reines Kontrollfenster und kann niemals Einstellungen verändern." TextWrapping="Wrap" Margin="0,6,0,0" Foreground="#C2D0E2"/></StackPanel></Border>
            <Border BorderBrush="#234157" BorderThickness="0,0,0,1" Padding="0,15"><StackPanel><TextBlock Text="07  UPDATES WIE BEI EINEM SPIEL-LAUNCHER" Foreground="#FF4FD8" FontWeight="Bold"/><TextBlock Text="UPDATES PRÜFEN arbeitet nur bei gestoppter OMA. Der Launcher lädt ausschließlich über HTTPS, verlangt Ed25519-Signatur und SHA-256, installiert in den inaktiven A/B-Slot und rollt bei einem Fehler automatisch zurück." TextWrapping="Wrap" Margin="0,6,0,0" Foreground="#C2D0E2"/></StackPanel></Border>
            <Border Background="#111A28" BorderBrush="#FFC857" BorderThickness="1" Padding="15" Margin="0,18,0,5"><StackPanel><TextBlock Text="FEHLERKARTE" Foreground="#FFC857" FontWeight="Bold"/><TextBlock Text="Port 30000 rot: grandMA2 läuft nicht oder Telnet Login ist nicht Enabled.  Bridge/Tunnel rot: Pfade in Einstellungen prüfen.  DPAPI rot: Zugangsdaten neu eingeben.  SAFE_READ rot: Bridge/.env/Telnet prüfen.  DOCTOR rot: Runtime-Key oder Tunnel-ID prüfen.  READY rot: Tunnel-UI und Log öffnen. CONNECTION_REFUSED bedeutet, dass tunnel-client nicht lauscht." TextWrapping="Wrap" Margin="0,7,0,0" Foreground="#D9E1EC"/></StackPanel></Border>
          </StackPanel></ScrollViewer>
          <StackPanel Grid.Row="2" Orientation="Horizontal" HorizontalAlignment="Right" Margin="0,16,0,0"><Button Name="HelpTunnelButton" Content="TUNNEL UI" Style="{StaticResource CyberButton}"/><Button Name="HelpChatGPTButton" Content="CHATGPT ÖFFNEN" Style="{StaticResource CyberButton}"/><Button Name="HelpBackButton" Content="ZURÜCK" Style="{StaticResource PrimaryButton}" Margin="0"/></StackPanel>
        </Grid></Border>
      </Grid>

      <Grid Grid.Row="1" Name="SettingsView" Visibility="Collapsed">
        <Border Style="{StaticResource Card}"><Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
          <StackPanel><TextBlock Text="OMA // EINSTELLUNGEN" FontSize="27" FontWeight="Bold" Foreground="#00F5FF"/><TextBlock Text="Nur lokale Pfade und Bedienoptionen. Geheimnisse werden getrennt mit DPAPI gespeichert." Foreground="#9AAAC0" Margin="0,5,0,20"/></StackPanel>
          <StackPanel Grid.Row="1" MaxWidth="850" HorizontalAlignment="Left">
            <TextBlock Text="MCP-BRIDGE-ORDNER · VERIFIZIERTES A/B-RELEASE" Foreground="#FF4FD8" FontWeight="Bold"/><TextBox Name="BridgePathBox" Width="820" Margin="0,7,0,18" IsReadOnly="True"/>
            <TextBlock Text="TUNNELCLIENT-ORDNER" Foreground="#FF4FD8" FontWeight="Bold"/><TextBox Name="TunnelPathBox" Width="820" Margin="0,7,0,18"/>
            <TextBlock Text="LICHTPULT-IP · NUR FÜR MIT LICHTPULT" Foreground="#FF4FD8" FontWeight="Bold"/><TextBox Name="ConsoleHostBox" Width="820" Margin="0,7,0,18" ToolTip="Beispiel: 192.168.1.15. Bei Nur onPC wird dieser Wert vollständig ignoriert."/>
            <CheckBox Name="SoundToggle" Content="Systemklänge für Start, Erfolg und Fehler verwenden"/>
            <CheckBox Name="AutoOpenToggle" Content="ChatGPT automatisch öffnen, sobald OMA bereit ist"/>
            <Border BorderBrush="#273B50" BorderThickness="1" Background="#0A121E" Padding="15" Margin="0,24,0,0"><StackPanel><TextBlock Text="SICHERHEIT" Foreground="#58FF9A" FontWeight="Bold"/><TextBlock Text="Modus, MA2-Aufbau, Zugangsdaten und Updates können ausschließlich bei vollständig gestoppter OMA-Session geändert werden. Der Start erzeugt einen unveränderlichen Session-Snapshot. GMA_AUTH_BYPASS wird immer entfernt." TextWrapping="Wrap" Margin="0,7,0,0" Foreground="#B9C6D7"/></StackPanel></Border>
            <WrapPanel Margin="0,20,0,0"><Button Name="ResetSecretsButton" Content="ZUGANG NEU EINGEBEN" Style="{StaticResource DangerButton}"/><Button Name="OpenLogButton" Content="LOG ÖFFNEN" Style="{StaticResource CyberButton}"/><Button Name="ShortcutButton" Content="DESKTOP-VERKNÜPFUNG" Style="{StaticResource CyberButton}" Margin="0"/></WrapPanel>
          </StackPanel>
          <StackPanel Grid.Row="2" Orientation="Horizontal" HorizontalAlignment="Right"><Button Name="SettingsCancelButton" Content="ABBRECHEN" Style="{StaticResource CyberButton}"/><Button Name="SettingsSaveButton" Content="SPEICHERN" Style="{StaticResource PrimaryButton}" Margin="0"/></StackPanel>
        </Grid></Border>
      </Grid>

      <Grid Grid.Row="2" VerticalAlignment="Bottom"><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="OMA CORE // READ-ONLY SAFETY LAYER // LOCAL SECURE RUNTIME" Foreground="#40516A" FontFamily="Consolas" FontSize="10" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Name="VersionText" Foreground="#40516A" FontFamily="Consolas" FontSize="10" VerticalAlignment="Center"/></Grid>
    </Grid>
  </Grid>
</Window>
'@

try {
    $xmlReader = New-Object Xml.XmlNodeReader ([xml]$xaml)
    $script:Window = [Windows.Markup.XamlReader]::Load($xmlReader)
} catch {
    [Windows.MessageBox]::Show('OMA-Oberfläche konnte nicht geladen werden: ' + $_.Exception.Message, 'OMA GrandMAKI-BOT', 'OK', 'Error') | Out-Null
    exit 1
}

foreach ($name in @(
    'MainView','HelpView','SettingsView','MainStatus','MainSubStatus','StatusPill','StatusPillText','LogBox',
    'StartButton','StopButton','RestartButton','HelpButton','SettingsButton','ChatGPTButton','StatusButton','TunnelUiButton','SoundButton',
    'ModeObserverButton','ModeProgrammingButton','ModeFullAdminButton','SetupNoConsoleButton','SetupConsoleButton',
    'UpdateButton','UpdateProgress','UpdateStatusText','SelectionStatusText','SessionLockText','DiagnosticButton',
    'HelpTunnelButton','HelpChatGPTButton','HelpBackButton','BridgePathBox','TunnelPathBox','ConsoleHostBox','SoundToggle','AutoOpenToggle',
    'ResetSecretsButton','OpenLogButton','ShortcutButton','SettingsCancelButton','SettingsSaveButton','ScanLine','VersionText'
)) {
    Set-Variable -Scope Script -Name $name -Value $script:Window.FindName($name)
}

for ($i=1; $i -le 7; $i++) {
    $script:StageControls[$i] = @{
        Dot = $script:Window.FindName("StageDot$i")
        Detail = $script:Window.FindName("StageDetail$i")
    }
}

$script:VersionText.Text = "v$($script:AppVersion) // 26.08.2026"
$null = Sync-ConfigFromDisk
Update-PathLabels
Reset-Stages
Set-GlobalStatus 'idle' 'OMA OFFLINE' 'grandMA2 läuft unabhängig. Starte OMA nur dann, wenn du Unterstützung möchtest.'
Set-UpdateUi 'MMO-Launcher-Updater bereit' 0 'idle'
if ((Test-OmaSessionRunning) -and -not $script:OwnedTunnelProcess) {
    $script:ExternalTunnel = $true
    Set-GlobalStatus 'warn' 'EXTERNE OMA-SESSION' 'Änderungen bleiben gesperrt, bis diese Session vollständig gestoppt ist.'
}
Set-ControlsBusy $false
Write-SafeLog 'Launcher' "Oberflaeche v$($script:AppVersion) geladen."

$script:StartButton.Add_Click({ Start-OmaSequence })
$script:StopButton.Add_Click({ Stop-OmaSequence })
$script:RestartButton.Add_Click({ Restart-OmaSequence })
$script:ChatGPTButton.Add_Click({ Open-ChatGPT })
$script:HelpChatGPTButton.Add_Click({ Open-ChatGPT })
$script:TunnelUiButton.Add_Click({ Open-TunnelUi })
$script:StatusButton.Add_Click({ Open-ControlWindow })
$script:DiagnosticButton.Add_Click({ Export-LauncherDiagnostic })
$script:HelpTunnelButton.Add_Click({ Open-TunnelUi })
$script:HelpButton.Add_Click({ Show-HelpView })
$script:SettingsButton.Add_Click({ Show-SettingsView })
$script:HelpBackButton.Add_Click({ Show-MainView })
$script:SettingsCancelButton.Add_Click({ Show-MainView })
$script:SettingsSaveButton.Add_Click({ Save-SettingsFromUi })
$script:ModeObserverButton.Add_Click({ Set-LauncherSelection -Mode 'observer' -Setup '' })
$script:ModeProgrammingButton.Add_Click({ Set-LauncherSelection -Mode 'programming' -Setup '' })
$script:ModeFullAdminButton.Add_Click({ Set-LauncherSelection -Mode 'full_admin' -Setup '' })
$script:SetupNoConsoleButton.Add_Click({ Set-LauncherSelection -Mode '' -Setup 'without_console' })
$script:SetupConsoleButton.Add_Click({ Set-LauncherSelection -Mode '' -Setup 'with_console' })
$script:UpdateButton.Add_Click({ Invoke-LauncherUpdate })
$script:SoundButton.Add_Click({
    try { Assert-OmaStopped } catch { [Windows.MessageBox]::Show($_.Exception.Message, $script:AppName, 'OK', 'Information') | Out-Null; return }
    $script:Config.SoundEnabled = -not [bool]$script:Config.SoundEnabled
    Save-Config $script:Config
    Update-PathLabels
    if ([bool]$script:Config.SoundEnabled) { Play-OmaSound 'Start' }
})
$script:ResetSecretsButton.Add_Click({
    try { Assert-OmaStopped } catch { [Windows.MessageBox]::Show($_.Exception.Message, $script:AppName, 'OK', 'Information') | Out-Null; return }
    if (Show-CredentialsDialog) { Write-SafeLog 'Security' 'DPAPI-Zugangsdaten wurden lokal ersetzt.' 'PASS' }
})
$script:OpenLogButton.Add_Click({ Open-LogFolder })
$script:ShortcutButton.Add_Click({ New-DesktopShortcut })

$script:ScanPosition = 0.0
$script:ScanTimer = New-Object Windows.Threading.DispatcherTimer
$script:ScanTimer.Interval = [TimeSpan]::FromMilliseconds(75)
$script:ScanTimer.Add_Tick({
    $script:ScanPosition += 5.0
    if ($script:ScanPosition -gt [Math]::Max(650, $script:Window.ActualHeight - 80)) { $script:ScanPosition = 0 }
    [Windows.Controls.Canvas]::SetTop($script:ScanLine, $script:ScanPosition)
})
$script:ScanTimer.Start()

$script:StatusTimer = New-Object Windows.Threading.DispatcherTimer
$script:StatusTimer.Interval = [TimeSpan]::FromSeconds(4)
$script:StatusTimer.Add_Tick({
    if ($script:IsBusy) { return }
    if ($script:OwnedTunnelProcess -and $script:OwnedTunnelProcess.HasExited) {
        Write-SafeLog 'Monitor' "tunnel-client unerwartet beendet (Exit $($script:OwnedTunnelProcess.ExitCode))." 'ERROR'
        $script:OwnedTunnelProcess = $null
        Set-GlobalStatus 'error' 'TUNNEL BEENDET' 'Der OMA-Tunnelprozess wurde unerwartet beendet. Neustart ausführen.'
        Set-Stage 7 'error' 'VERBINDUNG VERLOREN'
        Play-OmaSound 'Error'
    } elseif (($script:OwnedTunnelProcess -or $script:ExternalTunnel) -and -not (Test-TcpPort -HostName '127.0.0.1' -Port 8080 -TimeoutMs 180)) {
        Set-GlobalStatus 'warn' 'VERBINDUNG PRÜFEN' 'Der lokale OMA-Port antwortet momentan nicht. OMA versucht beim Neustart eine saubere Wiederherstellung.'
        Set-Stage 7 'warn' 'OMA-PORT NICHT ERREICHBAR'
    } elseif (-not $script:OwnedTunnelProcess -and (Test-OmaSessionRunning)) {
        $script:ExternalTunnel = $true
        Set-GlobalStatus 'warn' 'EXTERNE OMA-SESSION' 'Änderungen bleiben gesperrt. Diese Session muss außerhalb des Launchers gestoppt werden.'
    } elseif ($script:ExternalTunnel -and -not (Test-OmaSessionRunning)) {
        $script:ExternalTunnel = $false
        Set-GlobalStatus 'idle' 'OMA OFFLINE' 'Externe Session beendet. Auswahl und Updates sind wieder freigegeben.'
    }
    Set-ControlsBusy $false
})
$script:StatusTimer.Start()

$script:Window.Add_Closing({
    if ($script:Closing) { return }
    $script:Closing = $true
    try {
        if ($script:StatusTimer) { $script:StatusTimer.Stop() }
        if ($script:ScanTimer) { $script:ScanTimer.Stop() }
        if ($script:AutoUpdateTimer) { $script:AutoUpdateTimer.Stop() }
        if ($script:AutoUpdateProcess -and -not $script:AutoUpdateProcess.HasExited) { $script:AutoUpdateProcess.Kill() }
        if ($script:OwnedTunnelProcess) { Stop-OwnedTunnel }
        if (-not (Test-OmaSessionRunning)) { try { Release-OmaSession } catch { } }
        Write-SafeLog 'Launcher' 'Fenster geschlossen; eigene Kindprozesse bereinigt.' 'PASS'
    } catch { }
})

$script:Window.Add_ContentRendered({ Start-AutoUpdateCheck })
$null = $script:Window.ShowDialog()
