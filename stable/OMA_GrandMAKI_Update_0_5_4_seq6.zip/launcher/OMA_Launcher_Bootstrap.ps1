#requires -Version 5.1

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$launcherRoot = $PSScriptRoot
$launcherScript = Join-Path $launcherRoot 'OMA_GrandMAKI_BOT.ps1'
$localRoot = $env:LOCALAPPDATA
if ([string]::IsNullOrWhiteSpace($localRoot)) {
    $localRoot = $env:TEMP
}
$logRoot = Join-Path $localRoot 'OMA_GrandMAKI_BOT\startup_logs'
New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$bootstrapLog = Join-Path $logRoot ("OMA_Launcher_Startup_${timestamp}.log")
$stdoutLog = Join-Path $logRoot ("OMA_Launcher_Startup_${timestamp}.stdout.log")
$stderrLog = Join-Path $logRoot ("OMA_Launcher_Startup_${timestamp}.stderr.log")

function Write-BootstrapLog {
    param([string]$Message)
    $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss.fffK'), $Message
    Add-Content -LiteralPath $bootstrapLog -Value $line -Encoding UTF8
}

function Show-StartupError {
    param([string]$Message)
    $fullMessage = "Der OMA Launcher konnte nicht gestartet werden.`n`n$Message`n`nFehlerprotokoll:`n$bootstrapLog"
    try {
        Add-Type -AssemblyName PresentationFramework
        [Windows.MessageBox]::Show($fullMessage, 'OMA GrandMAKI-BOT', 'OK', 'Error') | Out-Null
    }
    catch {
        try {
            $shell = New-Object -ComObject WScript.Shell
            $shell.Popup($fullMessage, 0, 'OMA GrandMAKI-BOT', 16) | Out-Null
        }
        catch {}
    }
}

try {
    Write-BootstrapLog "Bootstrap 1.2.5 gestartet. LauncherRoot=$launcherRoot"
    if (-not (Test-Path -LiteralPath $launcherScript -PathType Leaf)) {
        throw "Launcher-Datei fehlt: $launcherScript"
    }

    $powerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powerShellExe -PathType Leaf)) {
        $powerShellExe = (Get-Command powershell.exe -ErrorAction Stop).Source
    }
    $childArguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "' + $launcherScript + '"'
    Write-BootstrapLog "Starte Launcher-Prozess. PowerShell=$powerShellExe"
    $process = Start-Process -FilePath $powerShellExe -ArgumentList $childArguments `
        -WorkingDirectory $launcherRoot -WindowStyle Hidden -PassThru -Wait `
        -RedirectStandardOutput $stdoutLog -RedirectStandardError $stderrLog
    Write-BootstrapLog ("Launcher-Prozess beendet. ExitCode=" + $process.ExitCode)

    if ($process.ExitCode -ne 0) {
        $detail = "Exitcode $($process.ExitCode)."
        if (Test-Path -LiteralPath $stderrLog -PathType Leaf) {
            $tail = @(Get-Content -LiteralPath $stderrLog -Tail 20 -ErrorAction SilentlyContinue)
            if ($tail.Count -gt 0) {
                $detail += "`n`n" + ($tail -join "`n")
            }
        }
        throw $detail
    }
    exit 0
}
catch {
    $message = $_.Exception.Message
    try { Write-BootstrapLog ("STARTFEHLER: " + $message) } catch {}
    Show-StartupError -Message $message
    exit 1
}
