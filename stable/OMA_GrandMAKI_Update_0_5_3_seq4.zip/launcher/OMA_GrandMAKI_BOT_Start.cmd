@echo off
setlocal
set "OMA_INSTALL=%LOCALAPPDATA%\OMA_GrandMAKI_BOT\launcher\1.2.3"
set "OMA_BOOTSTRAP=%OMA_INSTALL%\OMA_Launcher_Bootstrap.ps1"
if not exist "%OMA_BOOTSTRAP%" (
  echo.
  echo OMA Launcher 1.2.3 ist noch nicht installiert.
  echo Bitte zuerst OMA_Launcher_Update_Install.cmd aus diesem Paket starten.
  echo.
  pause
  exit /b 2
)
start "OMA GrandMAKI-BOT" powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "%OMA_BOOTSTRAP%"
endlocal
exit /b 0
