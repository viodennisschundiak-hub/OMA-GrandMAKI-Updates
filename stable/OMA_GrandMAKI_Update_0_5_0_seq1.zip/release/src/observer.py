"""Delta-oriented, read-only live observer for OMA GrandMAKI-BOT.

The observer stores only bounded structured deltas.  It never stores raw
credentials, never invokes a write command and never treats missing telemetry
as an exceptional process state.
"""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import inspect
import json
import os
import re
import threading
import time
import uuid
from collections import deque
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Any

from src.reliability import (
    OperationCancelledError,
    OperationLane,
    OperationTimeoutError,
    get_operation_supervisor,
)


class Availability(StrEnum):
    AVAILABLE = "AVAILABLE"
    UNAVAILABLE = "UNAVAILABLE"
    UNKNOWN = "UNKNOWN"
    STALE = "STALE"
    DEGRADED = "DEGRADED"
    ERROR = "ERROR"


class ObserverSourceUnavailableError(RuntimeError):
    """A live source is unavailable but the observer process remains healthy."""


@dataclass(frozen=True)
class FieldValue:
    value: Any = None
    status: Availability = Availability.UNKNOWN
    verified: bool = False
    reason: str | None = None

    def payload(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "value": _sanitize(self.value),
            "verified": self.verified,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class ObserverSample:
    source: str
    fields: Mapping[str, FieldValue]
    source_note: str | None = None


Sampler = Callable[[], Awaitable[ObserverSample]]
ShowChangeCallback = Callable[[str | None, str], Any]


@dataclass
class SamplerSpec:
    name: str
    reader: Sampler
    min_interval_seconds: float
    max_interval_seconds: float
    timeout_seconds: float
    lane: OperationLane = OperationLane.FAST_LIVE_READ
    priority: int = 100
    current_interval_seconds: float = field(init=False)
    next_due_monotonic: float = field(default=0.0, init=False)
    unchanged_polls: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        self.min_interval_seconds = max(0.2, float(self.min_interval_seconds))
        self.max_interval_seconds = max(self.min_interval_seconds, float(self.max_interval_seconds))
        self.timeout_seconds = max(0.1, float(self.timeout_seconds))
        self.current_interval_seconds = self.min_interval_seconds


_SECRET_KEY = re.compile(
    r"(?:api.?key|credential|dpapi|password|runtime.?key|secret|token|tunnel.?id)",
    re.IGNORECASE,
)
_SECRET_VALUE_PATTERNS = (
    re.compile(r"\bsk-[A-Za-z0-9_-]{8,}\b"),
    re.compile(r"\btunnel_[A-Za-z0-9_-]{8,}\b", re.IGNORECASE),
)


class JsonlEventStore:
    """Append-only JSONL store with size rotation and mandatory redaction."""

    def __init__(
        self,
        path: Path,
        *,
        max_bytes: int = 32 * 1024 * 1024,
        backups: int = 5,
    ) -> None:
        self.path = path
        self.max_bytes = max(64 * 1024, int(max_bytes))
        self.backups = max(1, min(int(backups), 20))
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, record: Mapping[str, Any]) -> None:
        safe_record = _sanitize(dict(record))
        line = json.dumps(
            safe_record,
            ensure_ascii=False,
            separators=(",", ":"),
            default=str,
        )
        encoded = (line + "\n").encode("utf-8")
        if len(encoded) > 128 * 1024:
            digest = hashlib.sha256(encoded).hexdigest()
            compact = {
                "wall_clock_timestamp": safe_record.get("wall_clock_timestamp"),
                "monotonic_timestamp_ns": safe_record.get("monotonic_timestamp_ns"),
                "session_id": safe_record.get("session_id"),
                "source": safe_record.get("source"),
                "type": safe_record.get("type"),
                "status": "DEGRADED",
                "payload_truncated": True,
                "original_record_sha256": digest,
            }
            encoded = (json.dumps(compact, separators=(",", ":")) + "\n").encode("utf-8")

        with self._lock:
            current_size = self.path.stat().st_size if self.path.exists() else 0
            if current_size and current_size + len(encoded) > self.max_bytes:
                self._rotate()
            with self.path.open("ab") as handle:
                handle.write(encoded)
                handle.flush()

    def _rotate(self) -> None:
        oldest = self.path.with_name(f"{self.path.name}.{self.backups}")
        if oldest.exists():
            oldest.unlink()
        for index in range(self.backups - 1, 0, -1):
            source = self.path.with_name(f"{self.path.name}.{index}")
            destination = self.path.with_name(f"{self.path.name}.{index + 1}")
            if source.exists():
                source.replace(destination)
        if self.path.exists():
            self.path.replace(self.path.with_name(f"{self.path.name}.1"))


class ObserverEngine:
    """Schedule small read samplers and persist only verified/status deltas."""

    def __init__(
        self,
        samplers: list[SamplerSpec],
        *,
        store: JsonlEventStore,
        on_show_change: ShowChangeCallback | None = None,
        recent_event_limit: int = 500,
        max_concurrent_polls: int = 1,
    ) -> None:
        if not samplers:
            raise ValueError("ObserverEngine requires at least one sampler")
        names = [spec.name for spec in samplers]
        if len(names) != len(set(names)):
            raise ValueError("Observer sampler names must be unique")
        self._samplers = sorted(samplers, key=lambda spec: spec.priority)
        self._store = store
        self._on_show_change = on_show_change
        self._supervisor = get_operation_supervisor()
        # Every Telnet reader ultimately shares one stateful MA2 socket and one
        # FIFO transaction gate.  Launching many observer jobs concurrently only
        # creates a timeout queue in front of that single transport and can cause
        # cancellation-driven reconnect storms.  Keep observer-originated work
        # bounded; external MCP reads still retain the remaining worker capacity.
        self._max_concurrent_polls = max(1, min(int(max_concurrent_polls), 4))
        self._task: asyncio.Task[None] | None = None
        self._poll_tasks: dict[str, asyncio.Task[None]] = {}
        self._lifecycle_lock = asyncio.Lock()
        self._stop_requested = asyncio.Event()
        self._session_id: str | None = None
        self._session_showfile: str | None = None
        self._state: dict[str, FieldValue] = {}
        self._initialized_sources: set[str] = set()
        self._source_status: dict[str, dict[str, Any]] = {}
        self._recent_events: deque[dict[str, Any]] = deque(maxlen=max(10, int(recent_event_limit)))
        self._event_count = 0
        self._storage_error: str | None = None
        self._started_monotonic: float | None = None

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    async def start(self) -> bool:
        async with self._lifecycle_lock:
            if self.running:
                return False
            self._stop_requested.clear()
            self._poll_tasks.clear()
            self._started_monotonic = time.monotonic()
            self._begin_session(self._session_showfile)
            now = time.monotonic()
            for spec in self._samplers:
                spec.current_interval_seconds = spec.min_interval_seconds
                spec.next_due_monotonic = now
                spec.unchanged_polls = 0
            self._task = asyncio.create_task(self._run(), name="oma:observer:coordinator")
            return True

    async def stop(self) -> bool:
        async with self._lifecycle_lock:
            if self._task is None:
                return False
            task = self._task
            self._task = None
            self._stop_requested.set()
            task.cancel()
            poll_tasks = list(self._poll_tasks.values())
            for poll_task in poll_tasks:
                poll_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, TimeoutError):
            await asyncio.wait_for(task, timeout=3.0)
        if poll_tasks:
            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(asyncio.gather(*poll_tasks, return_exceptions=True), timeout=3.0)
        self._poll_tasks.clear()
        self._end_session("observer_stopped")
        return True

    async def _run(self) -> None:
        while not self._stop_requested.is_set():
            now = time.monotonic()
            due = sorted(
                (
                    spec
                    for spec in self._samplers
                    if spec.next_due_monotonic <= now and spec.name not in self._poll_tasks
                ),
                key=lambda item: (item.next_due_monotonic, item.priority),
            )
            available_slots = max(0, self._max_concurrent_polls - len(self._poll_tasks))
            for spec in due[:available_slots]:
                spec.next_due_monotonic = float("inf")
                self._poll_tasks[spec.name] = asyncio.create_task(
                    self._poll_and_reschedule(spec),
                    name=f"oma:observer:poll:{spec.name}",
                )
            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(self._stop_requested.wait(), timeout=0.05)

    async def _poll_and_reschedule(self, spec: SamplerSpec) -> None:
        try:
            changed = await self.poll_once(spec)
            source_status = self._source_status.get(spec.name, {}).get("status")
            if source_status in {
                Availability.UNAVAILABLE.value,
                Availability.STALE.value,
                Availability.DEGRADED.value,
                Availability.ERROR.value,
            }:
                # Failure is a normal live condition, but it must immediately
                # reduce pressure on grandMA2 instead of retrying at the fastest
                # cadence ten more times.
                spec.unchanged_polls += 1
                spec.current_interval_seconds = min(
                    spec.max_interval_seconds,
                    max(
                        spec.min_interval_seconds,
                        spec.current_interval_seconds * 2.0,
                    ),
                )
            elif changed:
                spec.unchanged_polls = 0
                spec.current_interval_seconds = spec.min_interval_seconds
            else:
                spec.unchanged_polls += 1
                if spec.unchanged_polls >= 10:
                    spec.current_interval_seconds = min(
                        spec.max_interval_seconds,
                        spec.current_interval_seconds * 1.25,
                    )
            spec.next_due_monotonic = time.monotonic() + spec.current_interval_seconds
        finally:
            self._poll_tasks.pop(spec.name, None)

    async def poll_once(self, spec: SamplerSpec) -> bool:
        try:
            sample = await self._supervisor.run(
                name=f"observer_{spec.name}",
                risk_tier="SAFE_READ",
                operation_factory=spec.reader,
                timeout_seconds=spec.timeout_seconds,
                lane=spec.lane,
            )
        except OperationCancelledError:
            if self._stop_requested.is_set():
                return False
            return self._set_source_status(spec.name, Availability.STALE, "cancelled")
        except OperationTimeoutError as exc:
            return self._set_source_status(
                spec.name,
                Availability.DEGRADED,
                f"timeout_after_{exc.timeout_seconds:.1f}s",
            )
        except ObserverSourceUnavailableError as exc:
            return self._set_source_status(
                spec.name,
                Availability.UNAVAILABLE,
                str(exc),
            )
        except Exception as exc:
            return self._set_source_status(
                spec.name,
                Availability.ERROR,
                f"{type(exc).__name__}: {exc}",
            )

        self._set_source_status(spec.name, Availability.AVAILABLE, None)
        return await self._apply_sample(sample)

    async def _apply_sample(self, sample: ObserverSample) -> bool:
        fields = {str(name): value for name, value in sample.fields.items() if isinstance(value, FieldValue)}
        show_field = fields.get("console.showfile")
        new_showfile = (
            str(show_field.value)
            if show_field and show_field.status == Availability.AVAILABLE and show_field.value
            else None
        )
        if new_showfile and self._session_showfile and new_showfile != self._session_showfile:
            await self._change_show(self._session_showfile, new_showfile)
        elif new_showfile and self._session_showfile is None:
            self._session_showfile = new_showfile

        if sample.source not in self._initialized_sources:
            self._initialized_sources.add(sample.source)
            self._state.update(fields)
            self._emit(
                source=sample.source,
                event_type="INITIAL_SNAPSHOT",
                previous=None,
                new={name: value.payload() for name, value in fields.items()},
                verification_status="MIXED",
                availability=Availability.AVAILABLE,
            )
            return bool(fields)

        changed = False
        for name, new_value in fields.items():
            previous = self._state.get(name)
            if previous == new_value:
                continue
            changed = True
            self._state[name] = new_value
            self._emit(
                source=sample.source,
                event_type=_event_type_for_field(name, previous, new_value),
                previous=previous.payload() if previous else None,
                new={"field": name, **new_value.payload()},
                verification_status=(
                    "VERIFIED"
                    if new_value.verified
                    else "BEST_EFFORT"
                    if new_value.status == Availability.AVAILABLE
                    else new_value.status.value
                ),
                availability=new_value.status,
            )
        return changed

    async def _change_show(self, old: str | None, new: str) -> None:
        self._emit(
            source="console_identity",
            event_type="SHOW_CHANGED",
            previous={"showfile": old},
            new={"showfile": new},
            verification_status="VERIFIED",
            availability=Availability.AVAILABLE,
        )
        if self._on_show_change is not None:
            result = self._on_show_change(old, new)
            if inspect.isawaitable(result):
                await result
        self._end_session("show_changed")
        self._state.clear()
        self._initialized_sources.clear()
        self._session_showfile = new
        self._begin_session(new)

    def _set_source_status(
        self,
        source: str,
        status: Availability,
        reason: str | None,
    ) -> bool:
        current = {"status": status.value, "reason": reason}
        previous = self._source_status.get(source)
        self._source_status[source] = current
        if previous == current:
            return False
        self._emit(
            source=source,
            event_type="OBSERVER_SOURCE_STATUS",
            previous=previous,
            new=current,
            verification_status=status.value,
            availability=status,
        )
        return True

    def _begin_session(self, showfile: str | None) -> None:
        self._session_id = str(uuid.uuid4())
        self._session_showfile = showfile
        self._emit(
            source="observer",
            event_type="OBSERVER_SESSION_START",
            previous=None,
            new={"showfile": showfile},
            verification_status="LOCAL",
            availability=Availability.AVAILABLE,
        )

    def _end_session(self, reason: str) -> None:
        if self._session_id is None:
            return
        self._emit(
            source="observer",
            event_type="OBSERVER_SESSION_END",
            previous={"showfile": self._session_showfile},
            new={"reason": reason},
            verification_status="LOCAL",
            availability=Availability.AVAILABLE,
        )
        self._session_id = None

    def _emit(
        self,
        *,
        source: str,
        event_type: str,
        previous: Any,
        new: Any,
        verification_status: str,
        availability: Availability,
    ) -> None:
        event = {
            "monotonic_timestamp_ns": time.monotonic_ns(),
            "wall_clock_timestamp": datetime.now(UTC).isoformat(),
            "session_id": self._session_id,
            "showfile": self._session_showfile,
            "source": source,
            "type": event_type,
            "previous": _sanitize(previous),
            "new": _sanitize(new),
            "verification_status": verification_status,
            "availability": availability.value,
        }
        self._event_count += 1
        self._recent_events.append(event)
        try:
            self._store.append(event)
            self._storage_error = None
        except Exception as exc:  # storage failure cannot kill live observation
            self._storage_error = f"{type(exc).__name__}: {exc}"

    def recent_events(self, limit: int = 50) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), self._recent_events.maxlen or 500))
        return list(self._recent_events)[-limit:]

    def status(self) -> dict[str, Any]:
        now = time.monotonic()
        return {
            "running": self.running,
            "session_id": self._session_id,
            "showfile": self._session_showfile,
            "uptime_seconds": None if self._started_monotonic is None else round(now - self._started_monotonic, 3),
            "event_count": self._event_count,
            "in_memory_event_count": len(self._recent_events),
            "source_status": self._source_status,
            "storage_path": str(self._store.path),
            "storage_error": self._storage_error,
            "max_concurrent_polls": self._max_concurrent_polls,
            "active_poll_count": len(self._poll_tasks),
            "samplers": {
                spec.name: {
                    "interval_seconds": round(spec.current_interval_seconds, 3),
                    "min_interval_seconds": spec.min_interval_seconds,
                    "max_interval_seconds": spec.max_interval_seconds,
                    "timeout_seconds": spec.timeout_seconds,
                    "lane": spec.lane.value,
                }
                for spec in self._samplers
            },
        }


def _event_type_for_field(
    name: str,
    previous: FieldValue | None,
    new: FieldValue,
) -> str:
    lowered = name.casefold()
    if lowered == "console.showfile":
        return "SHOW_CHANGED"
    if lowered.endswith(("fader_page", "button_page", "channel_page")):
        return "PAGE_CHANGED"
    if lowered.endswith(".is_active"):
        before = bool(previous.value) if previous else False
        after = bool(new.value)
        if not before and after:
            return "EXECUTOR_GO"
        if before and not after:
            return "EXECUTOR_OFF"
        return "PLAYBACK_CHANGED"
    if lowered.endswith((".fader_value", ".fader_value_text")):
        return "FADER_CHANGED"
    if lowered.endswith((".current_cue", "selected_cue")):
        return "CUE_CHANGED"
    if lowered.startswith("playback."):
        return "PLAYBACK_CHANGED"
    if lowered.startswith("bpm."):
        return "BPM_CHANGED"
    if lowered.startswith("history."):
        return "COMMAND_FEEDBACK"
    if lowered in ("programmer.selection_count", "programmer.fixture_ids"):
        return "SELECTION_CHANGED"
    if lowered.startswith("programmer."):
        return "PROGRAMMER_CHANGED"
    if lowered.startswith("fixture.") and ".output." in lowered:
        attribute = lowered.rsplit(".output.", 1)[-1]
        if any(token in attribute for token in ("color", "rgb", "cyan", "magenta", "yellow", "hue", "saturation")):
            return "COLOR_CHANGED"
        if any(token in attribute for token in ("pan", "tilt", "position")):
            return "POSITION_CHANGED"
        return "FIXTURE_OUTPUT_CHANGED"
    if ".color" in lowered:
        return "COLOR_CHANGED"
    if ".position" in lowered:
        return "POSITION_CHANGED"
    return "STATE_CHANGED"


def _sanitize(value: Any, *, _depth: int = 0) -> Any:
    if _depth > 8:
        return "[TRUNCATED_DEPTH]"
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for index, (key, item) in enumerate(value.items()):
            if index >= 200:
                result["_truncated"] = True
                break
            clean_key = str(key)[:256]
            result[clean_key] = "[REDACTED]" if _SECRET_KEY.search(clean_key) else _sanitize(item, _depth=_depth + 1)
        return result
    if isinstance(value, (list, tuple, set, frozenset)):
        items = list(value)
        result = [_sanitize(item, _depth=_depth + 1) for item in items[:200]]
        if len(items) > 200:
            result.append("[TRUNCATED_ITEMS]")
        return result
    if isinstance(value, str):
        text = value[:4096]
        for pattern in _SECRET_VALUE_PATTERNS:
            text = pattern.sub("[REDACTED]", text)
        return text
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(value)[:4096]


def default_event_store() -> JsonlEventStore:
    local_app_data = os.getenv("LOCALAPPDATA", "").strip()
    if local_app_data:
        default_path = Path(local_app_data) / "OMA_GrandMAKI_BOT" / "observer" / "oma_events.jsonl"
    else:
        default_path = Path(__file__).resolve().parent.parent / "data" / "observer" / "oma_events.jsonl"
    path = Path(os.getenv("OMA_OBSERVER_LOG_PATH", str(default_path))).expanduser()
    try:
        max_mb = float(os.getenv("OMA_OBSERVER_LOG_MAX_MB", "32"))
    except (TypeError, ValueError):
        max_mb = 32.0
    try:
        backups = int(os.getenv("OMA_OBSERVER_LOG_BACKUPS", "5"))
    except (TypeError, ValueError):
        backups = 5
    return JsonlEventStore(
        path,
        max_bytes=int(max(1.0, min(max_mb, 1024.0)) * 1024 * 1024),
        backups=backups,
    )


__all__ = [
    "Availability",
    "FieldValue",
    "JsonlEventStore",
    "ObserverEngine",
    "ObserverSample",
    "SamplerSpec",
    "default_event_store",
]
