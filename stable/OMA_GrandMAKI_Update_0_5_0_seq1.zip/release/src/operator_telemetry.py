"""Read-only operator telemetry helpers for grandMA2.

This module deliberately separates *verified data* from *capability gaps*.
It never reconstructs selection members, preset references, or running
playbacks from weak proxies such as $SELECTEDFIXTURESCOUNT or $SELECTEDEXEC.

The only filesystem reader is restricted to MA Lighting's installed
``plugins/plugin_1.lua`` API reference.  No caller-supplied path is accepted.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from src.prompt_parser import parse_list_output

_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
_SEQUENCE_ASSIGN_RE = re.compile(r"\bSeq(?:uence)?\s+(\d+)(?:\((\d+)\))?(?![\d(])", re.IGNORECASE)
_GMA_SYMBOL_RE = re.compile(r"\bgma(?:\.[A-Za-z_][A-Za-z0-9_]*)+\b")
_VERSION_DIR_RE = re.compile(r"gma2_V_(\d+(?:\.\d+)*)", re.IGNORECASE)


def strip_ansi(text: str) -> str:
    return _ANSI_ESCAPE_RE.sub("", text or "")


def parse_listvar(raw: str) -> dict[str, str]:
    """Parse grandMA2 ListVar output into ``{$NAME: value}``."""
    variables: dict[str, str] = {}
    for line in strip_ansi(raw).replace("\r", "\n").splitlines():
        line = line.strip()
        if "=" not in line or line.startswith("[") or line.startswith("Executing"):
            continue
        if " : " in line:
            _, _, line = line.partition(" : ")
            line = line.strip()
        name, _, value = line.partition("=")
        name = name.strip().lstrip("$")
        if name:
            variables[f"${name}"] = value.strip()
    return variables


def parse_selected_exec_ref(
    value: str | None,
    *,
    fader_page: int | None = None,
    button_page: int | None = None,
) -> dict[str, Any]:
    """Resolve MA2's $SELECTEDEXEC value without guessing.

    Live grandMA2 can report ``pool.page.executor`` (for example ``1.1.4``),
    while some contexts expose ``page.executor`` or a bare executor number.
    A bare number is resolved against the matching fader/button page only when
    that page value is available.
    """
    raw = (value or "").strip()
    result: dict[str, Any] = {
        "raw": raw,
        "page_pool": None,
        "page": None,
        "executor": None,
        "page_qualified": None,
        "verified": False,
        "reason": None,
    }
    if not raw or raw.upper() == "NONE":
        result["reason"] = "No selected executor reported by $SELECTEDEXEC."
        return result

    parts = raw.split(".")
    if not all(part.isdigit() for part in parts):
        result["reason"] = f"Unrecognised $SELECTEDEXEC format: {raw!r}."
        return result

    nums = [int(p) for p in parts]
    if len(nums) == 3:
        result["page_pool"], result["page"], result["executor"] = nums
    elif len(nums) == 2:
        result["page"], result["executor"] = nums
    elif len(nums) == 1:
        executor = nums[0]
        result["executor"] = executor
        if executor <= 100 and fader_page is not None:
            result["page"] = int(fader_page)
        elif executor > 100 and button_page is not None:
            result["page"] = int(button_page)
        else:
            result["reason"] = (
                "Bare executor number cannot be page-qualified without the matching "
                "$FADERPAGE/$BUTTONPAGE value."
            )
            return result
    else:
        result["reason"] = f"Unrecognised $SELECTEDEXEC format: {raw!r}."
        return result

    page = result["page"]
    executor = result["executor"]
    if page is None or executor is None:
        result["reason"] = "Selected executor did not resolve to page + executor."
        return result

    result["page_qualified"] = f"{page}.{executor}"
    result["verified"] = True
    return result


def parse_sequence_assignment(value: str | None) -> dict[str, Any] | None:
    """Parse an executor ``Sequence=Seq N(count)`` field."""
    if not value:
        return None
    match = _SEQUENCE_ASSIGN_RE.search(value)
    if not match:
        return None
    return {
        "sequence_id": int(match.group(1)),
        "object_count_hint": int(match.group(2)) if match.group(2) else None,
        "raw": value.strip(),
    }


def parse_sequence_label(raw: str, sequence_id: int) -> str | None:
    """Extract a sequence label from ``List Sequence N`` output."""
    parsed = parse_list_output(raw)
    wanted = str(sequence_id)
    for entry in parsed.entries:
        if entry.object_id == wanted and entry.name:
            return entry.name
    return None


def parse_sequence_executor_inventory(raw: str) -> list[dict[str, Any]]:
    """Parse ``List AllSequExecutors`` into assignment inventory.

    This is intentionally named *inventory*: presence in AllSequExecutors does
    not establish that an executor is currently running.
    """
    clean = strip_ansi(raw).replace("\r", "\n")
    inventory: list[dict[str, Any]] = []
    for line in clean.splitlines():
        line = line.strip()
        if not line.startswith("Exec "):
            continue
        head = re.match(r"Exec\s+([0-9]+\.[0-9]+)\s+", line)
        if not head:
            continue
        page_exec = head.group(1)
        page_s, exec_s = page_exec.split(".", 1)
        name_match = re.search(r"\bName=(.*?)(?=\s+\w+=|\s*$)", line)
        seq_match = re.search(r"\bSequence=(Seq(?:uence)?\s+\d+(?:\(\d+\))?)", line, re.IGNORECASE)
        seq = parse_sequence_assignment(seq_match.group(1) if seq_match else None)
        inventory.append({
            "page": int(page_s),
            "executor": int(exec_s),
            "page_qualified": page_exec,
            "name": name_match.group(1).strip() if name_match else "",
            "sequence_id": seq["sequence_id"] if seq else None,
            "sequence_raw": seq["raw"] if seq else None,
        })
    return inventory


def _version_tuple(path: Path) -> tuple[int, ...]:
    match = _VERSION_DIR_RE.search(str(path))
    if not match:
        return ()
    return tuple(int(part) for part in match.group(1).split("."))


def find_installed_plugin_api_file(ma_path_hint: str | None = None) -> Path | None:
    """Locate MA Lighting's installed ``plugins/plugin_1.lua`` safely.

    The search root is fixed to ``%PROGRAMDATA%\\MA Lighting Technologies\\grandma``.
    ``ma_path_hint`` may only influence ranking; it is never opened directly.
    """
    programdata = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
    grandma_root = programdata / "MA Lighting Technologies" / "grandma"
    if not grandma_root.exists():
        return None

    candidates = [
        p for p in grandma_root.glob("gma2_V_*/plugins/plugin_1.lua")
        if p.is_file()
    ]
    if not candidates:
        return None

    hint = (ma_path_hint or "").replace("\\", "/").lower()
    hinted = [p for p in candidates if p.parent.parent.name.lower() in hint]
    pool = hinted or candidates
    return max(pool, key=_version_tuple)


def inspect_installed_lua_api(ma_path_hint: str | None = None, *, max_snippets: int = 80) -> dict[str, Any]:
    """Read the installed grandMA2 Lua API reference without arbitrary file access."""
    api_file = find_installed_plugin_api_file(ma_path_hint)
    if api_file is None:
        return {
            "found": False,
            "path": None,
            "symbols": [],
            "relevant_snippets": [],
            "reason": "MA Lighting plugins/plugin_1.lua was not found under %PROGRAMDATA%.",
        }

    try:
        # plugin_1.lua is small; cap the read to avoid accidental oversized files.
        with api_file.open("r", encoding="utf-8", errors="replace") as fh:
            text = fh.read(2_000_001)
        if len(text) > 2_000_000:
            return {
                "found": False,
                "path": str(api_file),
                "symbols": [],
                "relevant_snippets": [],
                "reason": "plugin_1.lua exceeded the 2 MB safety read limit.",
            }
    except OSError as exc:
        return {
            "found": False,
            "path": str(api_file),
            "symbols": [],
            "relevant_snippets": [],
            "reason": f"Could not read plugin_1.lua: {exc}",
        }

    symbols = sorted(set(_GMA_SYMBOL_RE.findall(text)))
    keywords = (
        "selection", "selected", "fixture", "preset", "executor", "playback",
        "getobj", "gethandle", "getvar", "show.get", "show.property", "amount",
        "child", "class", "name", "index", "dmx",
    )
    snippets: list[str] = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        lower = line.lower()
        if any(keyword in lower for keyword in keywords):
            snippets.append(f"L{lineno}: {line.rstrip()}")
            if len(snippets) >= max_snippets:
                break

    return {
        "found": True,
        "path": str(api_file),
        "version_dir": api_file.parent.parent.name,
        "symbol_count": len(symbols),
        "symbols": symbols,
        "relevant_snippets": snippets,
        "truncated_snippets": len(snippets) >= max_snippets,
        "safety": "Fixed MA Lighting ProgramData path only; no caller-supplied path is accepted.",
    }

# ---------------------------------------------------------------------------
# Fixed, read-only Lua runtime probes
# ---------------------------------------------------------------------------

_OMA_RO_MARKER = "OMA_RO1"
_FIXTURE_LINE_RE = re.compile(
    r"^Fixture\s+(?P<object_id>\d+)\s+"
    r"(?P<name>.*?)\s+"
    r"(?P<fixid>\d+|-)\s+"
    r"(?P<chaid>\d+|-)\s+"
    r"(?P<fixture_type_id>\d+)\s+"
    r"(?P<fixture_type_name>.*?)\s+"
    r"(?P<patch>\d+\.\d+|-)\s+"
    r"(?P<no_parameters>Yes|No)\b",
    re.IGNORECASE,
)


def _lua_clean(value_expr: str) -> str:
    """Return a compact call to the probe-local Lua field sanitizer."""
    return f"e({value_expr})"


def _lua_escape_function() -> str:
    """Compact Lua helper used only to keep marker fields single-line."""
    return "local function e(v) if v==nil then return '' end return string.gsub(tostring(v),';',',') end"


def build_readonly_selection_lua_probe() -> str:
    """Build a fixed Lua probe that only reads the current Selection object.

    Safety invariant: the returned script contains no ``gma.cmd``, setters,
    exports/imports, file I/O, or caller-controlled Lua source. It uses only
    the read-only object API verified in MA Lighting's installed plugin_1.lua
    plus ``gma.feedback`` for returning structured command-line feedback.
    """
    clean = _lua_clean
    parts = [
        _lua_escape_function(),
        "local O=gma.show.getobj",
        "local h=O.handle('Selection')",
        f"gma.feedback('{_OMA_RO_MARKER};SEL_HANDLE;'..{clean('h')})",
        "if h then",
        "local n=O.amount(h) or 0",
        f"gma.feedback('{_OMA_RO_MARKER};SEL_AMOUNT;'..{clean('n')})",
        "for i=1,n do",
        "local c=O.child(h,i)",
        "if c then",
        (
            f"gma.feedback('{_OMA_RO_MARKER};SEL_MEMBER;'..{clean('i')}..';'.."
            f"{clean('O.class(c)')}..';'..{clean('O.number(c)')}..';'.."
            f"{clean('O.index(c)')}..';'..{clean('O.name(c)')}..';'..{clean('O.label(c)')})"
        ),
        "end",
        "end",
        "end",
    ]
    return ";".join(parts)



def build_readonly_runtime_schema_lua_probe(executor_page: int = 1, executor_id: int = 220) -> str:
    """Build a fixed diagnostic Lua probe for read-only object properties.

    This does *not* attempt to infer running state. It exposes property names
    and values of three handles so the next bridge revision can be based on
    actual v3.9.63 runtime data rather than guessed property names:
    current Selection, selected executor, and a numeric executor target.
    """
    page = max(1, min(int(executor_page), 999))
    executor = max(1, min(int(executor_id), 999))
    clean = _lua_clean
    emit_props = (
        "local function ep(tag,h) "
        f"gma.feedback('{_OMA_RO_MARKER};HANDLE;'..tag..';'..{clean('h')}); "
        "if not h then return end; local P=gma.show.property; local n=P.amount(h) or 0; "
        f"gma.feedback('{_OMA_RO_MARKER};PROP_AMOUNT;'..tag..';'..{clean('n')}); "
        "local lim=n; if lim>160 then lim=160 end; "
        "for i=0,lim do local pn=P.name(h,i); if pn then local pv=P.get(h,i); "
        f"gma.feedback('{_OMA_RO_MARKER};PROP;'..tag..';'..{clean('i')}..';'..{clean('pn')}..';'..{clean('pv')}); end end end"
    )
    parts = [
        _lua_escape_function(),
        emit_props,
        "local O=gma.show.getobj",
        "local s=O.handle('Selection')",
        "ep('SELECTION',s)",
        "if s then ep('SELECTION_PARENT',O.parent(s));gma.feedback('OMA_RO1;X;SELECTION;'..e(type(O.x(s)))..';'..e(O.x(s))) end",
        "if s and (O.amount(s) or 0)>0 then ep('SEL_FIRST',O.child(s,1)) end",
        "local se=gma.user.getselectedexec()",
        "ep('SELECTED_EXEC',se)",
        f"local te=O.handle('Executor {page}.{executor}')",
        "ep('TARGET_EXEC',te)",
        "if te then ep('TARGET_EXEC_PARENT',O.parent(te));gma.feedback('OMA_RO1;X;TARGET_EXEC;'..e(type(O.x(te)))..';'..e(O.x(te))) end",
    ]
    return ";".join(parts)


def parse_readonly_lua_probe(raw: str) -> dict[str, Any]:
    """Parse OMA_RO1 structured feedback emitted by the fixed Lua probes."""
    result: dict[str, Any] = {
        "selection_handle": None,
        "selection_amount": None,
        "selection_members": [],
        "selection_matches": [],
        "x_values": {},
        "handles": {},
        "properties": {},
        "marker_lines": [],
    }
    clean = strip_ansi(raw).replace("\r", "\n")
    for line in clean.splitlines():
        stripped = line.strip()
        # grandMA2 may append the first gma.feedback row directly after the
        # command prompt (e.g. "[Fixture]>OMA_RO1;...").  Accept that prompt-
        # prefixed form, but never accept marker text from the echoed Lua source.
        marker = _OMA_RO_MARKER + ";"
        pos = stripped.find(marker)
        if pos < 0:
            continue
        prefix = stripped[:pos]
        if prefix and not prefix.rstrip().endswith(">"):
            continue
        if "Executing :" in prefix or "LUA" in prefix.upper():
            continue
        payload = stripped[pos:]
        result["marker_lines"].append(payload)
        parts = payload.split(";")
        if len(parts) < 2:
            continue
        kind = parts[1]
        if kind == "SEL_HANDLE" and len(parts) >= 3:
            result["selection_handle"] = parts[2] or None
        elif kind == "SEL_AMOUNT" and len(parts) >= 3:
            try:
                result["selection_amount"] = int(float(parts[2]))
            except ValueError:
                result["selection_amount"] = None
        elif kind == "SEL_MEMBER" and len(parts) >= 8:
            def _num(text: str) -> int | None:
                try:
                    return int(float(text))
                except (TypeError, ValueError):
                    return None
            result["selection_members"].append({
                "selection_index": _num(parts[2]),
                "class": parts[3] or None,
                "number": _num(parts[4]),
                "object_index": _num(parts[5]),
                "name": parts[6] or None,
                "label": parts[7] or None,
            })
        elif kind == "SEL_MATCH" and len(parts) >= 6:
            def _match_num(text: str) -> int | None:
                try:
                    return int(float(text))
                except (TypeError, ValueError):
                    return None
            result["selection_matches"].append({
                "candidate_fixture_id": _match_num(parts[2]),
                "number": _match_num(parts[3]),
                "class": parts[4] or None,
                "name": parts[5] or None,
            })
        elif kind == "X" and len(parts) >= 5:
            result["x_values"][parts[2]] = {"type": parts[3], "value": parts[4]}
        elif kind == "HANDLE" and len(parts) >= 4:
            result["handles"][parts[2]] = parts[3] or None
        elif kind == "PROP_AMOUNT" and len(parts) >= 4:
            tag = parts[2]
            bucket = result["properties"].setdefault(tag, {"amount": None, "items": []})
            try:
                bucket["amount"] = int(float(parts[3]))
            except ValueError:
                bucket["amount"] = None
        elif kind == "PROP" and len(parts) >= 6:
            tag = parts[2]
            bucket = result["properties"].setdefault(tag, {"amount": None, "items": []})
            try:
                index = int(float(parts[3]))
            except ValueError:
                index = None
            bucket["items"].append({"index": index, "name": parts[4], "value": parts[5]})
    return result


def parse_fixture_inventory(raw: str) -> dict[int, dict[str, Any]]:
    """Parse ``List Fixture`` rows into a FixId-keyed inventory."""
    inventory: dict[int, dict[str, Any]] = {}
    clean = strip_ansi(raw).replace("\r", "\n")
    for line in clean.splitlines():
        match = _FIXTURE_LINE_RE.match(line.strip())
        if not match:
            continue
        gd = match.groupdict()
        if gd["fixid"] == "-":
            continue
        fixid = int(gd["fixid"])
        inventory[fixid] = {
            "fixture_id": fixid,
            "name": gd["name"].strip(),
            "channel_id": None if gd["chaid"] == "-" else int(gd["chaid"]),
            "fixture_type_id": int(gd["fixture_type_id"]),
            "fixture_type_name": gd["fixture_type_name"].strip(),
            "patch": None if gd["patch"] == "-" else gd["patch"],
            "no_parameters": gd["no_parameters"].lower() == "yes",
        }
    return inventory
