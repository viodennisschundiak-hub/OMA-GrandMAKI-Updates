OMA GRANDMAKI-BOT LAUNCHER 1.2.0
Stand: 25.08.2026

BEDIENUNG
1. grandMA2 onPC und gewünschte Show starten; Telnet Login = Enabled.
2. Observer, Programming oder Full Admin wählen.
3. Nur onPC oder Mit Lichtpult wählen.
4. OMA STARTEN drücken.
5. Für jede Änderung und jedes Update zuerst OMA STOPPEN.

PHASE-5-UPDATER
- Der Updatekanal wird beim Öffnen im Hintergrund geprüft.
- UPDATES PRÜFEN lädt ein signiertes Suite-Paket über HTTPS.
- SHA-256 und Ed25519 müssen stimmen.
- Bridge wird im inaktiven A/B-Slot getestet.
- Launcher wird parallel unter einer neuen Versionsnummer installiert.
- Bei Fehlern wird nicht umgeschaltet bzw. automatisch zurückgerollt.
- Nach Erfolg startet der neue Launcher selbstständig.
- Private Signierschlüssel sind niemals Bestandteil des Clients.

HARTE SESSION-REGEL
- Bei laufender OMA- oder tunnel-client-Session sind alle Änderungen gesperrt.
- Der Browser auf Port 8091 ist ausschließlich ein GET-only-Kontrollfenster.
- Observer: OMA_MODE=observer, GMA_SCOPE=tier:0
- Programming: OMA_MODE=normal, GMA_SCOPE=tier:4
- Full Admin: OMA_MODE=full_admin, GMA_SCOPE=tier:5
- GMA_AUTH_BYPASS wird immer entfernt.

STARTWEG
Der Desktop-Link startet den festen Bootstrap aus
%LOCALAPPDATA%\OMA_GrandMAKI_BOT\launcher\1.2.0.
Startfehler werden sichtbar gemeldet und unter
%LOCALAPPDATA%\OMA_GrandMAKI_BOT\startup_logs protokolliert.

DIAGNOSE
DIAGNOSE ZIP erzeugt eine geheimnisfreie Datei unter
Desktop\OMA AI assistent\Uploads.
