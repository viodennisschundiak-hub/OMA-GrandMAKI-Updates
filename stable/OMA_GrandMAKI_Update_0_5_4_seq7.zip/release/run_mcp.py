import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from src.server import main
main()