"""Bounded launcher SAFE_READ probe for the selected grandMA2 Telnet transport.

The launcher must never enumerate whole show pools during startup. This probe
therefore performs exactly one bounded ``ListVar`` request. An empty response
is reported as degraded but still proves that connect/login/command handling
must be readable.  An empty response is fail-closed because an open TCP port
alone does not prove that Telnet Login/Remote is enabled on the selected station.
"""

from __future__ import annotations

import asyncio
import os
import sys

from dotenv import load_dotenv

load_dotenv()


async def main() -> int:
    from src.telnet_client import GMA2TelnetClient

    host = os.getenv("GMA_HOST", "127.0.0.1")
    port = int(os.getenv("GMA_PORT", "30000"))
    user = os.getenv("GMA_USER", "administrator")
    password = os.getenv("GMA_PASSWORD", "admin")

    try:
        async with GMA2TelnetClient(
            host=host,
            port=port,
            user=user,
            password=password,
        ) as client:
            response = await client.send_command_with_response(
                "ListVar",
                timeout=1.5,
                delay=0.10,
                subsequent_timeout=0.05,
                max_response_bytes=131_072,
            )
        response_size = len(response.encode("utf-8"))
        if response.strip():
            print(f"SAFE_READ_OK ListVar bytes={response_size}")
            return 0
        print(
            "SAFE_READ_FAILED EmptyResponse: ListVar bytes=0; verify selected "
            "station and enable Telnet Login/Remote",
            file=sys.stderr,
        )
        return 2
    except Exception as exc:  # noqa: BLE001 - probe must return one bounded status
        print(f"SAFE_READ_FAILED {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
