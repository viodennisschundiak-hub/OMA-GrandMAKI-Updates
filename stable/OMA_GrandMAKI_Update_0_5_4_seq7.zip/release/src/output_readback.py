"""Read-only grandMA2 output telemetry helpers.

The Fixture/Channel Sheet ``Output`` layer and the DMX Sheet ultimately expose
calculated console output.  The installed grandMA2 Lua API provides the same
DMX-level evidence through ``gma.show.getdmx``.  This module builds only fixed,
numeric, read-only Lua probes and parses their feedback.

No helper in this file contains ``gma.cmd``, a setter, file I/O, or
caller-provided Lua source.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
_DMX_MARKER = "OMA_DMX1"
_PERF_MARKER = "OMA_PERF1"

# Live EditSetup rows use this shape (v3.9):
# ChannelType <index> <No.> <ATTRIBUTE> (<short>) <Break> <Coarse> <Fine> ...
_CHANNEL_ROW_RE = re.compile(
    r"ChannelType\s+\d+\s+\d+\s+"
    r"(?P<attribute>[A-Z][A-Z0-9_]*)\s*\([^)]*\)\s+"
    r"(?P<break>\d+)\s+"
    r"(?P<coarse>\d+|None|-)\s+"
    r"(?P<fine>\d+|None|-)",
    re.IGNORECASE,
)


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text or "")


def parse_patch_address(value: str | None) -> dict[str, int] | None:
    """Parse MA2 ``universe.address`` notation into absolute DMX addressing."""
    text = (value or "").strip()
    match = re.fullmatch(r"(\d+)\.(\d+)", text)
    if not match:
        return None
    universe = int(match.group(1))
    address = int(match.group(2))
    if not (1 <= universe <= 256 and 1 <= address <= 512):
        return None
    return {
        "universe": universe,
        "address": address,
        "absolute": (universe - 1) * 512 + address,
    }


def parse_channel_dmx_rows(raw: str) -> list[dict[str, Any]]:
    """Extract attribute-to-break/coarse/fine mappings from ChannelType rows."""
    rows: list[dict[str, Any]] = []
    for line in _strip_ansi(raw).replace("\r", "\n").splitlines():
        match = _CHANNEL_ROW_RE.search(line)
        if not match:
            continue

        def _slot(value: str) -> int | None:
            return None if value.casefold() in {"none", "-"} else int(value)

        rows.append({
            "attribute": match.group("attribute").upper(),
            "break": int(match.group("break")),
            "coarse": _slot(match.group("coarse")),
            "fine": _slot(match.group("fine")),
        })
    return rows


def is_intensity_attribute(name: str) -> bool:
    """Accept MA2 dimmer attributes while excluding unrelated DIM* controls."""
    token = (name or "").strip().upper()
    return bool(re.fullmatch(r"DIM(?:\d+)?", token) or token.startswith("DIMMER"))


def resolve_attribute_dmx_addresses(
    *,
    patch: str | None,
    channel_rows: list[dict[str, Any]],
    intensity_only: bool = True,
) -> list[dict[str, Any]]:
    """Resolve break-1 ChannelType offsets to absolute DMX addresses.

    ``List Fixture`` exposes the first patch break.  Breaks above one are kept
    as unresolved rows instead of being guessed.
    """
    base = parse_patch_address(patch)
    resolved: list[dict[str, Any]] = []
    for row in channel_rows:
        if intensity_only and not is_intensity_attribute(str(row.get("attribute", ""))):
            continue
        item = dict(row)
        item.update({
            "coarse_absolute": None,
            "fine_absolute": None,
            "resolved": False,
            "reason": None,
        })
        if base is None:
            item["reason"] = "Fixture has no valid primary DMX patch."
        elif row.get("break") != 1:
            item["reason"] = (
                "Attribute uses DMX break > 1; List Fixture does not expose that "
                "break address in the primary patch field."
            )
        elif not isinstance(row.get("coarse"), int):
            item["reason"] = "Attribute has no coarse DMX slot."
        else:
            coarse = base["absolute"] + int(row["coarse"]) - 1
            fine_slot = row.get("fine")
            item["coarse_absolute"] = coarse
            item["fine_absolute"] = (
                base["absolute"] + int(fine_slot) - 1
                if isinstance(fine_slot, int)
                else None
            )
            item["resolved"] = True
        resolved.append(item)
    return resolved


def _validated_addresses(addresses: Iterable[int], *, limit: int = 512) -> list[int]:
    clean: list[int] = []
    seen: set[int] = set()
    for raw in addresses:
        try:
            address = int(raw)
        except (TypeError, ValueError):
            continue
        if not (1 <= address <= 256 * 512) or address in seen:
            continue
        seen.add(address)
        clean.append(address)
        if len(clean) >= limit:
            break
    return clean


def build_readonly_dmx_lua_probe(addresses: Iterable[int]) -> str:
    """Build a fixed ``gma.show.getdmx`` probe for numeric addresses only."""
    clean = _validated_addresses(addresses)
    parts = [
        "local function e(v) if v==nil then return '' end return string.gsub(tostring(v),';',',') end",
    ]
    for address in clean:
        parts.append(f"local v{address}=gma.show.getdmx({address})")
        parts.append(
            f"gma.feedback('{_DMX_MARKER};DMX;{address};'..e(v{address}))"
        )
    return ";".join(parts)


def parse_readonly_dmx_lua_probe(raw: str) -> dict[int, int | None]:
    """Parse fixed DMX marker feedback, ignoring echoed Lua source."""
    values: dict[int, int | None] = {}
    marker = _DMX_MARKER + ";"
    for line in _strip_ansi(raw).replace("\r", "\n").splitlines():
        stripped = line.strip()
        pos = stripped.find(marker)
        if pos < 0:
            continue
        prefix = stripped[:pos]
        if prefix and not prefix.rstrip().endswith(">"):
            continue
        if "Executing :" in prefix or "LUA" in prefix.upper():
            continue
        parts = stripped[pos:].split(";")
        if len(parts) < 4 or parts[1] != "DMX":
            continue
        try:
            address = int(parts[2])
            number = float(parts[3])
        except ValueError:
            continue
        value = max(0, min(int(round(number)), 255))
        values[address] = value
    return values


def dmx_value_to_percent(coarse: int, fine: int | None = None) -> float:
    """Convert an 8- or 16-bit DMX value to percent."""
    coarse = max(0, min(int(coarse), 255))
    if fine is None:
        return round(coarse * 100.0 / 255.0, 1)
    fine = max(0, min(int(fine), 255))
    return round(((coarse << 8) | fine) * 100.0 / 65535.0, 1)


def build_readonly_performance_lua_probe(slot: int) -> str:
    """Build a fixed read-only Realtime Performance table probe."""
    clean_slot = max(1, min(int(slot), 256))
    return ";".join([
        "local function e(v) if v==nil then return '' end return string.gsub(tostring(v),';',',') end",
        f"local t=gma.network.getperformance({clean_slot})",
        f"gma.feedback('{_PERF_MARKER};TYPE;'..e(type(t)))",
        "if type(t)=='table' then",
        "local n=0",
        "for k,v in pairs(t) do",
        "n=n+1",
        f"if n<=512 then gma.feedback('{_PERF_MARKER};ITEM;'..e(k)..';'..e(v)) end",
        "end",
        "end",
    ])


def parse_readonly_performance_lua_probe(raw: str) -> dict[str, Any]:
    """Parse fixed Realtime Performance marker feedback."""
    result: dict[str, Any] = {"return_type": None, "items": {}}
    marker = _PERF_MARKER + ";"
    for line in _strip_ansi(raw).replace("\r", "\n").splitlines():
        stripped = line.strip()
        pos = stripped.find(marker)
        if pos < 0:
            continue
        prefix = stripped[:pos]
        if prefix and not prefix.rstrip().endswith(">"):
            continue
        if "Executing :" in prefix or "LUA" in prefix.upper():
            continue
        parts = stripped[pos:].split(";")
        if len(parts) >= 3 and parts[1] == "TYPE":
            result["return_type"] = parts[2]
        elif len(parts) >= 4 and parts[1] == "ITEM":
            result["items"][parts[2]] = parts[3]
    return result
