"""
Telnet Client Module

This module is responsible for establishing Telnet connections with grandMA2,
handling authentication, and sending commands. This is the only module in the
project permitted to directly manipulate Telnet.

According to coding-standards.md, the Telnet client is the only component that can:
- Open connections
- Execute login commands
- Perform reconnection logic
- Send raw MA commands

Uses telnetlib3 (based on asyncio) to replace the deprecated telnetlib module.
"""

import asyncio
import base64
import contextlib
import hashlib
import json
import logging
import os
import struct
import time
from collections import deque
from typing import Any

import telnetlib3

from src.telnet_gateway import TelnetTransactionGate

logger = logging.getLogger(__name__)


class WebRemoteError(RuntimeError):
    """Raised when the read-only grandMA2 Web Remote channel is unavailable."""


class TelnetResponseLimitError(RuntimeError):
    """Raised when one console response exceeds the configured safety bound."""

    def __init__(self, *, limit_bytes: int, received_bytes: int) -> None:
        super().__init__(
            "grandMA2 response exceeded the bounded live-read limit "
            f"({received_bytes} > {limit_bytes} bytes); use an offline/chunked reader"
        )
        self.limit_bytes = limit_bytes
        self.received_bytes = received_bytes


class _WebSocketConnection:
    """Minimal RFC 6455 client used to avoid an extra runtime dependency.

    It implements only the text, continuation, ping/pong and close frames needed
    by grandMA2's local Web Remote.  Client frames are always masked as required
    by RFC 6455.  No command or playback-userInput request is exposed here.
    """

    def __init__(self, host: str, port: int, timeout: float) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout
        self.reader: asyncio.StreamReader | None = None
        self.writer: asyncio.StreamWriter | None = None
        self.max_message_bytes = _bounded_int_env(
            "GMA_WEB_REMOTE_MAX_MESSAGE_BYTES",
            2 * 1024 * 1024,
            64 * 1024,
            8 * 1024 * 1024,
        )

    async def connect(self) -> None:
        try:
            self.reader, self.writer = await asyncio.wait_for(
                asyncio.open_connection(self.host, self.port),
                timeout=self.timeout,
            )
        except Exception as exc:
            raise WebRemoteError(f"Web Remote is not reachable at {self.host}:{self.port}: {exc}") from exc

        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            "GET /?ma=1 HTTP/1.1\r\n"
            f"Host: {self.host}:{self.port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            f"Origin: http://{self.host}\r\n\r\n"
        )
        self.writer.write(request.encode("ascii"))
        try:
            await asyncio.wait_for(self.writer.drain(), timeout=self.timeout)
            raw_headers = await asyncio.wait_for(
                self.reader.readuntil(b"\r\n\r\n"),
                timeout=self.timeout,
            )
        except asyncio.CancelledError:
            self.abort()
            raise
        except Exception as exc:
            await self.close_socket()
            raise WebRemoteError(f"WebSocket handshake timed out or failed: {exc}") from exc

        header_text = raw_headers.decode("latin-1", errors="replace")
        lines = header_text.split("\r\n")
        if not lines or " 101 " not in f" {lines[0]} ":
            await self.close_socket()
            raise WebRemoteError(f"Web Remote rejected WebSocket upgrade: {lines[0] if lines else 'empty response'}")

        response_headers: dict[str, str] = {}
        for line in lines[1:]:
            if ":" in line:
                name, value = line.split(":", 1)
                response_headers[name.strip().casefold()] = value.strip()
        expected_accept = base64.b64encode(
            hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")).digest()
        ).decode("ascii")
        if response_headers.get("sec-websocket-accept") != expected_accept:
            await self.close_socket()
            raise WebRemoteError("Web Remote returned an invalid WebSocket accept key.")

    async def send_text(self, text: str) -> None:
        await self._send_frame(0x1, text.encode("utf-8"))

    async def _send_frame(self, opcode: int, payload: bytes = b"") -> None:
        if self.writer is None:
            raise WebRemoteError("WebSocket is not connected.")
        first = 0x80 | (opcode & 0x0F)
        length = len(payload)
        if length < 126:
            header = bytes((first, 0x80 | length))
        elif length <= 0xFFFF:
            header = bytes((first, 0x80 | 126)) + struct.pack("!H", length)
        else:
            header = bytes((first, 0x80 | 127)) + struct.pack("!Q", length)
        mask = os.urandom(4)
        masked = bytes(byte ^ mask[index % 4] for index, byte in enumerate(payload))
        self.writer.write(header + mask + masked)
        await asyncio.wait_for(self.writer.drain(), timeout=self.timeout)

    async def _read_exactly(self, size: int) -> bytes:
        if self.reader is None:
            raise WebRemoteError("WebSocket is not connected.")
        try:
            return await asyncio.wait_for(self.reader.readexactly(size), timeout=self.timeout)
        except asyncio.CancelledError:
            self.abort()
            raise
        except Exception as exc:
            raise WebRemoteError(f"Web Remote receive failed: {exc}") from exc

    async def receive_text(self) -> str:
        if self.reader is None:
            raise WebRemoteError("WebSocket is not connected.")
        fragments: list[bytes] = []
        message_opcode: int | None = None
        message_size = 0
        while True:
            head = await self._read_exactly(2)
            fin = bool(head[0] & 0x80)
            opcode = head[0] & 0x0F
            masked = bool(head[1] & 0x80)
            length = head[1] & 0x7F
            if length == 126:
                length = struct.unpack("!H", await self._read_exactly(2))[0]
            elif length == 127:
                length = struct.unpack("!Q", await self._read_exactly(8))[0]
            if length > self.max_message_bytes:
                self.abort()
                raise WebRemoteError("Web Remote frame exceeded the bounded live-read limit.")
            mask = await self._read_exactly(4) if masked else b""
            payload = await self._read_exactly(length)
            if masked:
                payload = bytes(byte ^ mask[index % 4] for index, byte in enumerate(payload))

            if opcode == 0x8:
                with contextlib.suppress(Exception):
                    await self._send_frame(0x8, payload[:125])
                raise WebRemoteError("Web Remote closed the session.")
            if opcode == 0x9:
                await self._send_frame(0xA, payload[:125])
                continue
            if opcode == 0xA:
                continue
            if opcode in (0x1, 0x2):
                message_opcode = opcode
                fragments = [payload]
            elif opcode == 0x0 and message_opcode is not None:
                fragments.append(payload)
            else:
                continue
            message_size += len(payload)
            if message_size > self.max_message_bytes:
                self.abort()
                raise WebRemoteError("Web Remote message exceeded the bounded live-read limit.")
            if fin:
                return b"".join(fragments).decode("utf-8", errors="replace")

    async def close_socket(self) -> None:
        writer = self.writer
        self.writer = None
        self.reader = None
        if writer is not None:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await asyncio.wait_for(self._send_close(writer), timeout=0.5)
            writer.close()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await asyncio.wait_for(writer.wait_closed(), timeout=0.5)

    async def _send_close(self, writer: asyncio.StreamWriter) -> None:
        first = 0x88
        mask = os.urandom(4)
        writer.write(bytes((first, 0x80)) + mask)
        await writer.drain()

    def abort(self) -> None:
        """Synchronously quarantine a partially-read Web Remote socket."""
        writer = self.writer
        self.writer = None
        self.reader = None
        if writer is not None:
            with contextlib.suppress(Exception):
                writer.close()


class GMA2WebRemoteClient:
    """Read-only grandMA2 Web Remote playback client.

    Only session/login/keepalive/close and ``requestType=playbacks`` messages
    can be emitted.  There is deliberately no generic command or user-input
    method, preventing the Web Remote transport from becoming a new escape hatch.
    """

    def __init__(
        self,
        host: str,
        user: str,
        password: str,
        *,
        port: int = 80,
        timeout: float = 4.0,
    ) -> None:
        self.host = host
        self.user = user
        self._password = password
        self.port = port
        self.timeout = timeout
        self._socket = _WebSocketConnection(host, port, timeout)
        self._session: int | None = None

    async def _send_json(self, payload: dict[str, Any]) -> None:
        await self._socket.send_text(json.dumps(payload, separators=(",", ":")))

    async def _receive_json(self) -> dict[str, Any]:
        for _ in range(20):
            text = await self._socket.receive_text()
            try:
                payload = json.loads(text)
            except json.JSONDecodeError:
                continue
            if isinstance(payload, dict):
                return payload
        raise WebRemoteError("Web Remote produced no parseable JSON response.")

    async def _receive_until(self, predicate) -> dict[str, Any]:
        for _ in range(40):
            payload = await self._receive_json()
            if predicate(payload):
                return payload
        raise WebRemoteError("Web Remote did not return the expected response type.")

    async def connect_and_login(self) -> dict[str, Any]:
        if self.user.strip().casefold() == "administrator":
            raise WebRemoteError(
                "grandMA2 Web Remote does not allow the default Administrator user; use the dedicated AI_BRIDGE user."
            )
        try:
            await self._socket.connect()
            await self._send_json({"session": 0})
            hello = await self._receive_until(lambda item: "session" in item)
            try:
                session = int(hello.get("session"))
            except (TypeError, ValueError) as exc:
                raise WebRemoteError("Web Remote did not allocate a numeric session.") from exc
            if session < 0 or hello.get("connections_limit_reached"):
                raise WebRemoteError("grandMA2 Web Remote session limit reached (maximum three remote users).")
            self._session = session
            password_md5 = hashlib.md5(self._password.encode("utf-8")).hexdigest()
            await self._send_json(
                {
                    "requestType": "login",
                    "username": self.user,
                    "password": password_md5,
                    "session": session,
                    "maxRequests": 1,
                }
            )
            login = await self._receive_until(lambda item: item.get("responseType") == "login")
            if login.get("result") is not True:
                raise WebRemoteError(
                    "Web Remote login was rejected. Verify AI_BRIDGE credentials and "
                    "Setup > Console > Global Settings > Remotes = Login Enabled."
                )
            return login
        except BaseException:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await asyncio.shield(self.close())
            self._socket.abort()
            raise

    async def request_playbacks(
        self,
        *,
        page: int,
        start_index: int,
        items_count: int,
        item_type: int,
        view: int,
    ) -> dict[str, Any]:
        if self._session is None:
            raise WebRemoteError("Web Remote session is not logged in.")
        await self._send_json(
            {
                "requestType": "playbacks",
                "startIndex": [int(start_index)],
                "itemsCount": [int(items_count)],
                "pageIndex": int(page) - 1,
                "itemsType": [int(item_type)],
                "view": int(view),
                "execButtonViewMode": 0,
                "buttonsViewMode": 1,
                "session": self._session,
                "maxRequests": 1,
            }
        )

        def _is_expected_playback(item: dict[str, Any]) -> bool:
            if item.get("responseType") != "playbacks":
                return False
            try:
                return int(item.get("responseSubType", item_type)) == item_type
            except (TypeError, ValueError):
                return False

        return await self._receive_until(_is_expected_playback)

    async def read_pages(self, pages: list[int]) -> list[tuple[int, dict[str, Any]]]:
        """Read standard executors plus the operator-priority 201-220 bank."""
        await self.connect_and_login()
        responses: list[tuple[int, dict[str, Any]]] = []
        request_interval = _bounded_float_env("GMA_WEB_REMOTE_REQUEST_INTERVAL", 0.025, 0.02, 1.0)
        try:
            for page in pages:
                responses.append(
                    (
                        page,
                        await self.request_playbacks(
                            page=page,
                            start_index=0,
                            items_count=90,
                            item_type=2,
                            view=2,
                        ),
                    )
                )
                await asyncio.sleep(request_interval)
                responses.append(
                    (
                        page,
                        await self.request_playbacks(
                            page=page,
                            start_index=200,
                            items_count=20,
                            item_type=2,
                            view=2,
                        ),
                    )
                )
                await asyncio.sleep(request_interval)
                responses.append(
                    (
                        page,
                        await self.request_playbacks(
                            page=page,
                            start_index=100,
                            items_count=90,
                            item_type=3,
                            view=3,
                        ),
                    )
                )
                await asyncio.sleep(request_interval)
            return responses
        finally:
            await self.close()

    async def read_executor(self, page: int, executor: int) -> dict[str, Any]:
        if 1 <= executor <= 90:
            item_type, view = 2, 2
        elif 101 <= executor <= 190:
            item_type, view = 3, 3
        elif 201 <= executor <= 220:
            item_type, view = 2, 2
        else:
            raise WebRemoteError(
                "Web Remote targeted readback supports executors 1-90, 101-190 and the priority bank 201-220."
            )
        await self.connect_and_login()
        try:
            return await self.request_playbacks(
                page=page,
                start_index=executor - 1,
                items_count=1,
                item_type=item_type,
                view=view,
            )
        finally:
            await self.close()

    async def read_physical_fader_slot(
        self,
        page: int,
        physical_fader_number: int,
    ) -> dict[str, Any]:
        """Read one standard fader position without inferring an executor ID.

        ``startIndex`` addresses the displayed fader position.  The caller must
        use the ``iExec`` value returned by grandMA2 as the resolved executor;
        the requested position itself is never treated as that identity.
        """
        if not 1 <= int(page) <= 999:
            raise WebRemoteError("Fader page must be between 1 and 999.")
        if not 1 <= int(physical_fader_number) <= 90:
            raise WebRemoteError("Physical fader position must be between 1 and 90.")
        await self.connect_and_login()
        try:
            return await self.request_playbacks(
                page=int(page),
                start_index=int(physical_fader_number) - 1,
                items_count=1,
                item_type=2,
                view=2,
            )
        finally:
            await self.close()

    async def close(self) -> None:
        if self._session is not None:
            with contextlib.suppress(Exception):
                await self._send_json(
                    {
                        "requestType": "close",
                        "session": self._session,
                        "maxRequests": 1,
                    }
                )
        self._session = None
        await self._socket.close_socket()


class GMA2TelnetClient:
    """Asynchronous grandMA2 Telnet client.

    Two serialization layers deliberately coexist:

    * ``_io_lock`` protects one concrete reader/writer exchange so a
      ``telnetlib3.StreamReader`` can never have concurrent readers.
    * ``_transaction_gate`` serializes *logical* operations on the stateful MA2
      Telnet session.  It is re-entrant for the owning asyncio Task, allowing a
      caller to hold one transaction over ``cd -> list -> cd /`` while the nested
      ``send_command*`` calls use the same gate.
    """

    DEFAULT_PORT = 30000
    DEFAULT_USER = "administrator"
    DEFAULT_PASSWORD = "admin"

    def __init__(
        self,
        host: str,
        port: int = DEFAULT_PORT,
        user: str = DEFAULT_USER,
        password: str = DEFAULT_PASSWORD,
    ):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self._reader: Any | None = None
        self._writer: Any | None = None
        self._connection: Any | None = None
        self._io_lock = asyncio.Lock()
        self._transaction_gate = TelnetTransactionGate()
        self._needs_reconnect = False
        self._unhealthy_reason: str | None = None
        self._connected_monotonic: float | None = None
        self._last_io_monotonic: float | None = None
        self._last_successful_read_monotonic: float | None = None
        self._cancelled_reads = 0
        self._oversized_responses = 0
        self._failure_history: deque[dict[str, Any]] = deque(maxlen=50)

        logger.debug(
            "GMA2TelnetClient initialized: host=%s, port=%s, user=%s",
            host,
            port,
            user,
        )

    def transaction(self, label: str = ""):
        """Return the session-wide FIFO transaction context manager."""
        return self._transaction_gate.transaction(label)

    @property
    def transaction_stats(self) -> dict[str, int | bool]:
        """Return non-sensitive transaction queue diagnostics."""
        return self._transaction_gate.stats()

    @property
    def is_connected(self) -> bool:
        """Check whether the telnet connection appears healthy."""
        return self._writer is not None and self._connection is not None and not self._needs_reconnect

    @property
    def health_snapshot(self) -> dict[str, Any]:
        """Return non-secret transport diagnostics without performing I/O."""
        now = time.monotonic()

        def age(value: float | None) -> float | None:
            return None if value is None else round(max(0.0, now - value), 3)

        return {
            "connected": self.is_connected,
            "needs_reconnect": self._needs_reconnect,
            "unhealthy_reason": self._unhealthy_reason,
            "seconds_since_connect": age(self._connected_monotonic),
            "seconds_since_io": age(self._last_io_monotonic),
            "seconds_since_successful_read": age(self._last_successful_read_monotonic),
            "cancelled_reads": self._cancelled_reads,
            "oversized_responses": self._oversized_responses,
            "failure_history": list(self._failure_history)[-10:],
            "transaction": self.transaction_stats,
        }

    def invalidate(self, reason: str) -> None:
        """Quarantine this socket so SessionManager reconnects on the next get()."""
        self._failure_history.append({
            "at_unix": round(time.time(), 3),
            "reason": str(reason)[:256],
        })
        self._needs_reconnect = True
        self._unhealthy_reason = reason
        writer = self._writer
        if writer is not None:
            with contextlib.suppress(Exception):
                writer.close()
        self._writer = None
        self._reader = None
        self._connection = None

    def force_close(self, reason: str = "forced_close") -> None:
        """Synchronous last-resort close used only by bounded cleanup paths."""
        self.invalidate(reason)

    def run_sync(self, coro: Any) -> Any:
        """Run an async client method from a synchronous context."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            raise RuntimeError("Cannot call run_sync() from within a running event loop. Use 'await' directly instead.")
        return asyncio.run(coro)

    async def connect(self) -> None:
        """Establish a Telnet connection."""
        logger.info("Connecting to %s:%s...", self.host, self.port)

        async with self.transaction("connect"), self._io_lock:
            try:
                connect_timeout = _bounded_float_env("GMA_TELNET_CONNECT_TIMEOUT_SECONDS", 5.0, 0.5, 30.0)
                self._reader, self._writer = await asyncio.wait_for(
                    telnetlib3.open_connection(
                        host=self.host,
                        port=self.port,
                    ),
                    timeout=connect_timeout,
                )
                self._connection = True
                self._needs_reconnect = False
                self._unhealthy_reason = None
                self._connected_monotonic = time.monotonic()
                self._last_io_monotonic = self._connected_monotonic
                await asyncio.sleep(0.5)
                logger.info("Successfully connected to %s:%s", self.host, self.port)
            except asyncio.CancelledError:
                self.invalidate("connect_cancelled")
                raise
            except Exception as exc:
                self.invalidate(f"connect_failed:{type(exc).__name__}")
                logger.error("Connection failed: %s", exc)
                raise ConnectionError(f"Unable to connect to {self.host}:{self.port}: {exc}") from exc

    async def login(self) -> bool:
        """Perform login authentication."""
        if self._writer is None or self._reader is None:
            raise RuntimeError("Connection not established, call connect() first")

        logger.info("Logging in as %s...", self.user)

        async with self.transaction("login"), self._io_lock:
            login_cmd = f'login "{self.user}" "{self.password}"\r\n'
            try:
                self._writer.write(login_cmd)
            except Exception as exc:
                self.invalidate(f"login_write_failed:{type(exc).__name__}")
                raise ConnectionError("Telnet login write failed") from exc
            await asyncio.sleep(0.5)

            try:
                response = await asyncio.wait_for(
                    self._reader.read(1024),
                    timeout=1.0,
                )
                logger.debug(
                    "Login response: %d bytes received",
                    len(response) if response else 0,
                )
                if response:
                    text = (
                        response.decode("utf-8", errors="replace") if isinstance(response, bytes) else response
                    ).lower()
                    error_patterns = (
                        "error #",
                        "login failed",
                        "invalid",
                        "denied",
                        "not allowed",
                    )
                    for pattern in error_patterns:
                        if pattern in text:
                            logger.error(
                                "Login rejected — response contains %r: %s",
                                pattern,
                                text.strip(),
                            )
                            return False
                logger.info("Login completed (response received)")
                self._last_io_monotonic = time.monotonic()
                return True
            except asyncio.CancelledError:
                self.invalidate("login_cancelled")
                raise
            except TimeoutError:
                logger.warning(
                    "Login response timeout — could not verify login success. "
                    "grandMA2 may not send a response on successful login, "
                    "but this could also indicate invalid credentials."
                )
                return False

    async def send_command(self, command: str, delay: float = 0.3) -> None:
        """Send one MA command without collecting its response."""
        if self._writer is None:
            raise RuntimeError("Connection not established, call connect() first")

        command = command.replace("\r", "").replace("\n", "")
        logger.debug("Sending command: %s", command)

        async with self.transaction("command"), self._io_lock:
            try:
                if self._writer is None or self._reader is None or self._needs_reconnect:
                    raise ConnectionError(
                        "Telnet connection became unavailable before command execution"
                    )
                self._writer.write(f"{command}\r\n")
                self._last_io_monotonic = time.monotonic()
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                # A write may already have reached MA2.  Quarantine the
                # channel so the caller cannot blindly continue a batch.
                self.invalidate("command_cancelled_unknown_completion")
                raise
            except ConnectionError:
                raise
            except Exception as exc:
                self.invalidate(f"command_write_failed:{type(exc).__name__}")
                raise ConnectionError("Telnet command write failed") from exc
        logger.debug("Command sent, waiting %s seconds", delay)

    async def send_command_with_response(
        self,
        command: str,
        timeout: float = 2.0,
        delay: float = 0.3,
        subsequent_timeout: float = 0.10,
        max_response_bytes: int | None = None,
    ) -> str:
        """Send one MA command and collect one bounded response.

        Cancellation cleanup drains any already-arriving feedback while the
        same transaction and I/O locks are still held.  If the stream cannot be
        realigned within the cleanup budget, it is quarantined for a controlled
        reconnect instead of contaminating the next tool call.
        """
        if self._writer is None or self._reader is None:
            raise RuntimeError("Connection not established, call connect() first")

        command = command.replace("\r", "").replace("\n", "")
        logger.debug("Sending command with response: %s", command)
        if max_response_bytes is None:
            max_response_bytes = _bounded_int_env("GMA_TELNET_MAX_RESPONSE_BYTES", 524_288, 16_384, 8_388_608)
        else:
            max_response_bytes = max(1024, min(int(max_response_bytes), 8_388_608))

        async with self.transaction("command_with_response"), self._io_lock:
            # Pending-input drain belongs to the same I/O critical section as
            # write+read; otherwise another reader can steal feedback.
            try:
                # A caller may have obtained this client before a queued earlier
                # transaction quarantined it.  Re-check under both serialization
                # locks so a stale queued job fails cleanly instead of dereferencing
                # a cleared reader/writer and starting another reconnect cascade.
                if self._writer is None or self._reader is None or self._needs_reconnect:
                    raise ConnectionError(
                        "Telnet connection became unavailable before command execution"
                    )
                # Keep stable references for this serialized exchange.  A
                # watchdog/cleanup path may quarantine the shared client while
                # this task is awaiting a read.  Dereferencing ``self._reader``
                # again after quarantine previously produced ``None.read``.
                reader = self._reader
                writer = self._writer
                await self._drain_pending_input(
                    max_seconds=0.15,
                    quiet_timeout=0.03,
                    max_bytes=65_536,
                    eof_is_quiet=True,
                    reader=reader,
                )

                writer.write(f"{command}\r\n")
                self._last_io_monotonic = time.monotonic()
                await asyncio.sleep(delay)

                response_parts: list[str] = []
                received_bytes = 0
                read_timeout = timeout
                while True:
                    try:
                        chunk = await asyncio.wait_for(reader.read(4096), timeout=read_timeout)
                        if chunk:
                            if isinstance(chunk, bytes):
                                received_bytes += len(chunk)
                                chunk = chunk.decode("utf-8", errors="replace")
                            else:
                                received_bytes += len(chunk.encode("utf-8"))
                            if received_bytes > max_response_bytes:
                                self._oversized_responses += 1
                                await self._drain_pending_input(
                                    max_seconds=0.35,
                                    quiet_timeout=0.04,
                                    max_bytes=max_response_bytes,
                                    reader=reader,
                                )
                                # A bounded quiet interval cannot prove that a
                                # very large MA2 response has fully ended.  Never
                                # risk feeding late bytes to the next command.
                                self.invalidate("oversized_response_quarantined")
                                raise TelnetResponseLimitError(
                                    limit_bytes=max_response_bytes,
                                    received_bytes=received_bytes,
                                )
                            response_parts.append(chunk)
                            read_timeout = subsequent_timeout
                        else:
                            is_closing = getattr(writer, "is_closing", None)
                            if callable(is_closing) and is_closing() is True:
                                self.invalidate("telnet_eof_during_response")
                            break
                    except TimeoutError:
                        break
                response = "".join(response_parts)
                self._last_successful_read_monotonic = time.monotonic()
                self._last_io_monotonic = self._last_successful_read_monotonic
            except asyncio.CancelledError:
                self._cancelled_reads += 1
                try:
                    await self._drain_pending_input(
                        max_seconds=0.35,
                        quiet_timeout=0.04,
                        max_bytes=max_response_bytes,
                        reader=locals().get("reader"),
                    )
                except asyncio.CancelledError:
                    pass
                except Exception:
                    pass
                # MA2 Telnet has no trustworthy response delimiter.  Even a
                # quiet drain cannot exclude delayed bytes after cancellation,
                # so the socket is always quarantined and re-attested.
                self.invalidate("cancelled_read_quarantined")
                raise
            except TelnetResponseLimitError:
                raise
            except ConnectionError:
                raise
            except Exception as exc:
                self.invalidate(f"response_read_failed:{type(exc).__name__}")
                raise ConnectionError("Telnet response read failed") from exc

        logger.debug("Response received: %d characters", len(response))
        return response

    async def _drain_pending_input(
        self,
        *,
        max_seconds: float,
        quiet_timeout: float,
        max_bytes: int,
        eof_is_quiet: bool = False,
        reader: Any | None = None,
    ) -> bool:
        """Drain until a quiet interval; caller must already hold ``_io_lock``."""
        reader = self._reader if reader is None else reader
        if reader is None:
            return False
        deadline = time.monotonic() + max(0.01, max_seconds)
        drained = 0
        while time.monotonic() < deadline and drained <= max_bytes:
            try:
                chunk = await asyncio.wait_for(reader.read(4096), timeout=max(0.005, quiet_timeout))
            except TimeoutError:
                return True
            if not chunk:
                if eof_is_quiet:
                    return True
                self.invalidate("telnet_eof_while_draining")
                return False
            drained += len(chunk) if isinstance(chunk, bytes) else len(chunk.encode("utf-8"))
        return False

    async def disconnect(self) -> None:
        """Close the Telnet connection."""
        async with self.transaction("disconnect"), self._io_lock:
            if self._writer is not None:
                logger.info("Closing connection...")
                writer = self._writer
                writer.close()
                wait_closed = getattr(writer, "wait_closed", None)
                if callable(wait_closed):
                    with contextlib.suppress(Exception):
                        await asyncio.wait_for(wait_closed(), timeout=1.0)
                self._writer = None
                self._reader = None
                self._connection = None
                self._needs_reconnect = False
                self._unhealthy_reason = None
                logger.info("Connection closed")

    async def __aenter__(self) -> "GMA2TelnetClient":
        await self.connect()
        await self.login()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.disconnect()


def _bounded_int_env(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


def _bounded_float_env(
    name: str,
    default: float,
    minimum: float,
    maximum: float,
) -> float:
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))
