"""Fail-closed launcher preflight for the exact OMA runtime source.

This module is intentionally local-only.  It proves that the Python selected by
the Windows launcher imports ``src.server`` from the configured bridge root and
that build, launcher mode, and scope match before tunnel-client is allowed to
start.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path


def _same_path(left: Path, right: Path) -> bool:
    """Compare resolved paths with Windows-compatible case folding."""
    return os.path.normcase(str(left.resolve())) == os.path.normcase(str(right.resolve()))


def verify_runtime_source(
    *,
    expected_root: str,
    expected_build: str,
    expected_mode: str,
    expected_scope: str,
) -> dict[str, object]:
    """Import the server and verify its complete launcher identity."""
    from src import server

    root = Path(expected_root).resolve()
    imported_server = Path(server.__file__).resolve()
    imported_root = imported_server.parent.parent
    actual_mode = os.getenv("OMA_MODE", "").strip()
    actual_scope = os.getenv("GMA_SCOPE", "").strip()
    actual_build = server._BRIDGE_BUILD_SHA256
    installed_expected = server._EXPECTED_BUILD_SHA256
    checks = {
        "root": _same_path(imported_root, root),
        "server_file_within_root": imported_server.is_relative_to(root),
        "build": actual_build == expected_build.strip().lower(),
        "installed_expected_build": installed_expected == actual_build,
        "mode": actual_mode == expected_mode,
        "scope": actual_scope == expected_scope,
        "auth_bypass_disabled": os.getenv("GMA_AUTH_BYPASS", "0") != "1",
    }
    return {
        "ok": all(checks.values()),
        "checks": checks,
        "actual": {
            "root": str(imported_root),
            "server_file": str(imported_server),
            "build": actual_build,
            "installed_expected_build": installed_expected,
            "mode": actual_mode,
            "scope": actual_scope,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected-root", required=True)
    parser.add_argument("--expected-build", required=True)
    parser.add_argument("--expected-mode", required=True)
    parser.add_argument("--expected-scope", required=True)
    args = parser.parse_args()
    result = verify_runtime_source(
        expected_root=args.expected_root,
        expected_build=args.expected_build,
        expected_mode=args.expected_mode,
        expected_scope=args.expected_scope,
    )
    print(json.dumps(result, sort_keys=True))
    return 0 if result["ok"] else 4


if __name__ == "__main__":
    raise SystemExit(main())
