"""Transaction gate for one stateful grandMA2 Telnet session.

A grandMA2 Telnet login is not a stateless request/response transport: ChangeDest
(``cd``) changes a session-global navigation location.  Serializing individual
reader/writer exchanges therefore prevents StreamReader races, but it does not
prevent another coroutine from interleaving a command between ``cd`` and the
matching ``list``/``cd /``.

``TelnetTransactionGate`` is the single FIFO/re-entrant gate used by the real
client.  Every public Telnet command passes through it.  Callers that perform a
multi-command stateful transaction can hold the same gate across the complete
sequence; nested command calls by the owning asyncio task are re-entrant.
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator


class TelnetTransactionGate:
    """Fair, re-entrant transaction gate bound to one asyncio event loop.

    ``asyncio.Lock`` wakes acquirers in FIFO order.  Re-entrancy is deliberately
    limited to the *same asyncio Task* so a child/concurrent task cannot bypass
    the queue merely because it inherited context variables.
    """

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._owner: asyncio.Task[Any] | None = None
        self._depth = 0
        self._waiting = 0
        self._transactions_started = 0

    @property
    def locked(self) -> bool:
        return self._owner is not None

    @property
    def waiting(self) -> int:
        return self._waiting

    def stats(self) -> dict[str, int | bool]:
        """Return non-sensitive diagnostics; commands/credentials are never stored."""
        return {
            "locked": self.locked,
            "waiting": self._waiting,
            "depth": self._depth,
            "transactions_started": self._transactions_started,
        }

    async def acquire(self) -> None:
        task = asyncio.current_task()
        if task is None:
            raise RuntimeError("TelnetTransactionGate requires an asyncio Task")

        if self._owner is task:
            self._depth += 1
            return

        self._waiting += 1
        try:
            await self._lock.acquire()
        finally:
            self._waiting -= 1

        self._owner = task
        self._depth = 1
        self._transactions_started += 1

    def release(self) -> None:
        task = asyncio.current_task()
        if task is None or self._owner is not task:
            raise RuntimeError("Telnet transaction released by non-owner task")

        self._depth -= 1
        if self._depth > 0:
            return

        self._owner = None
        self._depth = 0
        self._lock.release()

    @asynccontextmanager
    async def transaction(self, label: str = "") -> AsyncIterator[None]:
        # ``label`` is accepted for caller-side diagnostics but intentionally not
        # retained by the gate so arbitrary command text can never become telemetry.
        _ = label
        await self.acquire()
        try:
            yield
        finally:
            self.release()


@asynccontextmanager
async def transaction_scope(client: Any, label: str = "") -> AsyncIterator[None]:
    """Use a client's transaction API when its class defines one.

    The class-level check intentionally avoids treating ``MagicMock``'s dynamic
    attributes as a real transaction API, keeping existing unit-test doubles and
    third-party read-only adapters backward compatible.
    """

    transaction = getattr(type(client), "transaction", None)
    if callable(transaction):
        async with transaction(client, label):
            yield
        return
    yield


__all__ = ["TelnetTransactionGate", "transaction_scope"]
