"""
Per-Operator Telnet Session Manager

Pools GMA2TelnetClient connections keyed by operator identity. In stub mode
(no IdP), the identity is derived from GMA_USER or the effective scope tier.
When a real OAuth Authorization Server is integrated, the identity is the
JWT ``sub`` claim.

Each session authenticates with a console user whose rights level matches or
is more restrictive than the operator's OAuth scope tier, implementing the
dual-enforcement defense-in-depth described in the architecture document:

    Effective Permissions = OAuth Scopes ∩ ABAC Policy ∩ Console Native Rights

The intersection means no single layer can unilaterally escalate privileges.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field

from .telnet_client import GMA2TelnetClient

logger = logging.getLogger(__name__)


# ── Data model ────────────────────────────────────────────────────────────────


@dataclass
class OperatorSession:
    """A live Telnet session for one operator identity."""

    identity: str  # OAuth subject or scope-tier key
    username: str  # Console username used to authenticate
    client: GMA2TelnetClient
    created_at: float = field(default_factory=time.monotonic)
    last_used: float = field(default_factory=time.monotonic)
    reconnect_count: int = 0
    reconnect_attempt_count: int = 0
    last_reconnect: float | None = None
    last_error: str | None = None
    reconnect_attempts: deque[float] = field(default_factory=deque, repr=False)
    reconnect_circuit_open_until: float | None = None
    reconnect_circuit_trip_count: int = 0

    def touch(self) -> None:
        self.last_used = time.monotonic()

    def idle_seconds(self) -> float:
        return time.monotonic() - self.last_used


# ── Session manager ───────────────────────────────────────────────────────────


class SessionManager:
    """
    Pool of per-operator Telnet sessions.

    Session lifecycle
    -----------------
    * Created on first ``get()`` for a given identity.
    * Cached until ``idle_timeout`` seconds of inactivity or explicit
      ``release()``.
    * Auto-reconnected (same credentials) if the Telnet connection drops.
    * Oldest session evicted when the pool reaches ``max_sessions``.
    * ``start_keepalive()`` launches a background task that pings sessions
      and evicts expired ones at ``keepalive_interval``-second intervals.
    """

    def __init__(
        self,
        host: str,
        port: int,
        max_sessions: int = 16,
        idle_timeout: float = 3600.0,
        keepalive_interval: float = 30.0,
        on_reconnect: Callable[[str], None] | None = None,
        on_disconnect: Callable[[str, str], None] | None = None,
        reconnect_limit: int | None = None,
        reconnect_window_seconds: float | None = None,
        reconnect_cooldown_seconds: float | None = None,
    ) -> None:
        self._host = host
        self._port = port
        self._max_sessions = max_sessions
        self._idle_timeout = idle_timeout
        self._keepalive_interval = keepalive_interval
        self._on_reconnect = on_reconnect
        self._on_disconnect = on_disconnect
        self._reconnect_limit = (
            _bounded_int_env("OMA_TELNET_RECONNECT_LIMIT", 3, 1, 20)
            if reconnect_limit is None
            else max(1, min(int(reconnect_limit), 20))
        )
        self._reconnect_window_seconds = (
            _bounded_float_env("OMA_TELNET_RECONNECT_WINDOW_SECONDS", 60.0, 5.0, 600.0)
            if reconnect_window_seconds is None
            else max(0.1, min(float(reconnect_window_seconds), 600.0))
        )
        self._reconnect_cooldown_seconds = (
            _bounded_float_env("OMA_TELNET_RECONNECT_COOLDOWN_SECONDS", 60.0, 5.0, 900.0)
            if reconnect_cooldown_seconds is None
            else max(0.1, min(float(reconnect_cooldown_seconds), 900.0))
        )
        self._sessions: dict[str, OperatorSession] = {}
        self._lock = asyncio.Lock()
        self._identity_locks: dict[str, asyncio.Lock] = {}
        self._keepalive_task: asyncio.Task | None = None

    # ── Public API ───────────────────────────────────────────────────────────

    async def get(
        self,
        identity: str,
        username: str,
        password: str,
    ) -> GMA2TelnetClient:
        """
        Return a live Telnet client for *identity*.

        Creates a new session if none exists; reconnects with the same
        credentials if the Telnet connection dropped.
        """
        # Never hold the global pool lock across network I/O.  A slow reconnect
        # for one operator must not block health inspection or another identity.
        async with self._lock:
            identity_lock = self._identity_locks.setdefault(identity, asyncio.Lock())

        async with identity_lock:
            async with self._lock:
                session = self._sessions.get(identity)

            if session is not None:
                session.touch()
                if not session.client.is_connected:
                    logger.warning(
                        "Session for %r (console user %r) lost connection — reconnecting",
                        identity,
                        session.username,
                    )
                    self._reserve_reconnect_attempt(session)
                    await self._reconnect(session, username, password)
                return session.client

            client = await self._create_client(username, password)
            evicted: OperatorSession | None = None
            async with self._lock:
                if len(self._sessions) >= self._max_sessions:
                    oldest_key = min(
                        self._sessions,
                        key=lambda key: self._sessions[key].last_used,
                    )
                    evicted = self._sessions.pop(oldest_key)
                    self._identity_locks.pop(oldest_key, None)
                self._sessions[identity] = OperatorSession(
                    identity=identity,
                    username=username,
                    client=client,
                )

            if evicted is not None:
                await _safe_disconnect(evicted.client)
                logger.warning("Session pool full — evicted LRU session for %r", evicted.identity)
            logger.info(
                "Created session for operator %r as console user %r",
                identity,
                username,
            )
            return client

    async def release(self, identity: str) -> None:
        """Disconnect and remove the session for *identity*."""
        async with self._lock:
            session = self._sessions.pop(identity, None)
            self._identity_locks.pop(identity, None)
        if session is not None:
            await _safe_disconnect(session.client)
            logger.info("Released session for %r", identity)

    async def cleanup_expired(self) -> int:
        """
        Disconnect sessions idle longer than ``idle_timeout``.

        Returns the number of sessions removed.
        """
        async with self._lock:
            expired = [ident for ident, sess in self._sessions.items() if sess.idle_seconds() > self._idle_timeout]
            removed = []
            for ident in expired:
                removed.append(self._sessions.pop(ident))
                self._identity_locks.pop(ident, None)

        for session in removed:
            await _safe_disconnect(session.client)

        if removed:
            logger.info("Expired %d idle Telnet session(s)", len(removed))
        return len(removed)

    async def close_all(self) -> None:
        """Disconnect all sessions. Called on server shutdown."""
        if self._keepalive_task is not None:
            self._keepalive_task.cancel()
            self._keepalive_task = None

        async with self._lock:
            sessions = list(self._sessions.values())
            self._sessions.clear()
            self._identity_locks.clear()

        for session in sessions:
            await _safe_disconnect(session.client)
        logger.info("All Telnet sessions closed")

    def start_keepalive(self) -> None:
        """Start the background keepalive / expiry task."""
        if self._keepalive_task is None or self._keepalive_task.done():
            self._keepalive_task = asyncio.create_task(self._keepalive_loop(), name="session-keepalive")

    # ── Introspection ────────────────────────────────────────────────────────

    def session_count(self) -> int:
        """Number of currently open sessions."""
        return len(self._sessions)

    def session_info(self) -> list[dict]:
        """Snapshot of active sessions for diagnostics / admin tools."""
        return [
            {
                "identity": s.identity,
                "username": s.username,
                "connected": s.client.is_connected,
                "idle_seconds": round(s.idle_seconds(), 1),
                "age_seconds": round(time.monotonic() - s.created_at, 1),
                "reconnect_count": s.reconnect_count,
                "reconnect_attempt_count": s.reconnect_attempt_count,
                "seconds_since_reconnect": (
                    None if s.last_reconnect is None else round(time.monotonic() - s.last_reconnect, 1)
                ),
                "reconnect_circuit_open": bool(
                    s.reconnect_circuit_open_until is not None
                    and s.reconnect_circuit_open_until > time.monotonic()
                ),
                "seconds_until_reconnect_allowed": (
                    None
                    if s.reconnect_circuit_open_until is None
                    or s.reconnect_circuit_open_until <= time.monotonic()
                    else round(s.reconnect_circuit_open_until - time.monotonic(), 1)
                ),
                "reconnect_circuit_trip_count": s.reconnect_circuit_trip_count,
                "reconnect_attempts_in_window": len(s.reconnect_attempts),
                "last_error": s.last_error,
                "transport": s.client.health_snapshot if hasattr(type(s.client), "health_snapshot") else None,
            }
            for s in self._sessions.values()
        ]

    # ── Private helpers ──────────────────────────────────────────────────────

    def _reserve_reconnect_attempt(self, session: OperatorSession) -> None:
        """Reserve one bounded reconnect cycle or fail fast during cooldown.

        The observer has several small samplers sharing one Telnet session. If
        grandMA2 closes that session after a response, every sampler must see
        the same circuit breaker instead of each one starting a fresh network
        reconnect.  Both successful and failed reconnect cycles count.
        """
        now = time.monotonic()
        open_until = session.reconnect_circuit_open_until
        if open_until is not None and open_until > now:
            remaining = max(0.0, open_until - now)
            raise ConnectionError(
                "Telnet reconnect circuit open for "
                f"{session.identity!r}; retry allowed in {remaining:.1f}s"
            )
        if open_until is not None:
            session.reconnect_circuit_open_until = None

        cutoff = now - self._reconnect_window_seconds
        while session.reconnect_attempts and session.reconnect_attempts[0] < cutoff:
            session.reconnect_attempts.popleft()

        if len(session.reconnect_attempts) >= self._reconnect_limit:
            session.reconnect_attempts.clear()
            session.reconnect_circuit_open_until = now + self._reconnect_cooldown_seconds
            session.reconnect_circuit_trip_count += 1
            session.last_error = (
                "reconnect_circuit_open: "
                f"{self._reconnect_limit} reconnect cycles within "
                f"{self._reconnect_window_seconds:.1f}s"
            )
            if self._on_disconnect is not None:
                self._on_disconnect(session.identity, "reconnect_circuit_open")
            raise ConnectionError(
                "Telnet reconnect circuit opened for "
                f"{session.identity!r} after {self._reconnect_limit} cycles; "
                f"cooldown {self._reconnect_cooldown_seconds:.1f}s"
            )

        session.reconnect_attempts.append(now)
        session.reconnect_attempt_count += 1

    async def _create_client(self, username: str, password: str) -> GMA2TelnetClient:
        client = GMA2TelnetClient(
            host=self._host,
            port=self._port,
            user=username,
            password=password,
        )
        try:
            await client.connect()
            login_ok = await client.login()
        except BaseException:
            await _safe_disconnect(client)
            raise
        if not login_ok:
            await _safe_disconnect(client)
            raise ConnectionError(f"grandMA2 login could not be verified for console user {username!r}")
        return client

    async def _reconnect(
        self,
        session: OperatorSession,
        username: str,
        password: str,
    ) -> None:
        await _safe_disconnect(session.client)
        max_attempts = _bounded_int_env("OMA_TELNET_RECONNECT_ATTEMPTS", 3, 1, 8)
        timeout_seconds = _bounded_float_env("OMA_TELNET_RECONNECT_TIMEOUT_SECONDS", 10.0, 1.0, 60.0)
        last_error: BaseException | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                session.client = await asyncio.wait_for(
                    self._create_client(username, password),
                    timeout=timeout_seconds,
                )
                last_error = None
                break
            except asyncio.CancelledError:
                raise
            except BaseException as exc:
                last_error = exc
                session.last_error = f"{type(exc).__name__}: {exc}"
                if attempt < max_attempts:
                    await asyncio.sleep(min(0.25 * (2 ** (attempt - 1)), 2.0))
        if last_error is not None:
            if self._on_disconnect is not None:
                self._on_disconnect(session.identity, session.last_error or "reconnect_failed")
            raise ConnectionError(
                f"Reconnect failed for session {session.identity!r} after {max_attempts} attempt(s): {last_error}"
            ) from last_error
        session.username = username
        session.reconnect_count += 1
        session.last_reconnect = time.monotonic()
        session.last_error = None
        session.touch()
        if self._on_reconnect is not None:
            self._on_reconnect(session.identity)

    async def _evict_oldest(self) -> None:
        oldest_key = min(self._sessions, key=lambda k: self._sessions[k].last_used)
        session = self._sessions.pop(oldest_key)
        await _safe_disconnect(session.client)
        logger.warning("Session pool full — evicted LRU session for %r", oldest_key)

    async def _keepalive_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(self._keepalive_interval)
                await self.cleanup_expired()
                # Send a no-op to each connected session to keep TCP alive
                async with self._lock:
                    sessions = list(self._sessions.values())
                for session in sessions:
                    if session.client.is_connected:
                        try:
                            # Empty-string send keeps the socket alive without
                            # any console side-effects; will reconnect on next get().
                            await asyncio.wait_for(
                                session.client.send_command("", delay=0.0),
                                timeout=2.0,
                            )
                        except Exception as exc:
                            session.last_error = f"{type(exc).__name__}: {exc}"
                            invalidate = getattr(session.client, "invalidate", None)
                            if callable(invalidate):
                                invalidate("keepalive_failed")
                            if self._on_disconnect is not None:
                                self._on_disconnect(session.identity, "keepalive_failed")
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning("Keepalive loop error: %s", exc)


# ── Helpers ───────────────────────────────────────────────────────────────────


async def _safe_disconnect(client: GMA2TelnetClient) -> None:
    try:
        await asyncio.wait_for(client.disconnect(), timeout=2.0)
    except BaseException:
        force_close = getattr(type(client), "force_close", None)
        if callable(force_close):
            with contextlib.suppress(Exception):
                force_close(client, "disconnect_cleanup_timeout")


def _bounded_int_env(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


def _bounded_float_env(
    name: str,
    default: float,
    minimum: float,
    maximum: float,
) -> float:
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))
