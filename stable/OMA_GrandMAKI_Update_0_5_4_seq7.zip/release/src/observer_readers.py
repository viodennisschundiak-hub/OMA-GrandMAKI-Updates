"""Small, bounded grandMA2 readers used by the OMA live observer.

All Telnet access uses the existing ``GMA2TelnetClient`` and therefore the same
``TelnetTransactionGate``/``_io_lock`` path as every established bridge tool.
The existing read-only Web Remote playback client is used only for its typed
``requestType=playbacks`` surface; it cannot emit commands or user input.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import re
import time
from collections.abc import Awaitable, Callable
from typing import Any

from src.commands import list_messages, list_oops, list_update, run_lua
from src.observer import (
    Availability,
    FieldValue,
    ObserverSample,
    ObserverSourceUnavailableError,
)
from src.operator_telemetry import (
    build_readonly_selection_lua_probe,
    parse_fixture_inventory,
    parse_listvar,
    parse_readonly_lua_probe,
)
from src.output_readback import (
    build_readonly_dmx_lua_probe,
    dmx_value_to_percent,
    parse_channel_dmx_rows,
    parse_readonly_dmx_lua_probe,
    resolve_attribute_dmx_addresses,
)
from src.playback_readback import normalize_playback_response
from src.telnet_client import (
    GMA2TelnetClient,
    GMA2WebRemoteClient,
    TelnetResponseLimitError,
    WebRemoteError,
)

ClientProvider = Callable[[], Awaitable[GMA2TelnetClient]]


_CONTEXT_VARIABLES: dict[str, tuple[str, Callable[[str], Any] | None]] = {
    "console.showfile": ("$SHOWFILE", None),
    "console.version": ("$VERSION", None),
    "console.host": ("$HOSTNAME", None),
    "console.host_status": ("$HOSTSTATUS", None),
    "console.user": ("$USER", None),
    "console.user_rights": ("$USERRIGHTS", None),
    "console.destination": ("$PATH", None),
    "console.session_state": ("$SESSION", None),
    "context.fader_page": ("$FADERPAGE", int),
    "context.button_page": ("$BUTTONPAGE", int),
    "context.channel_page": ("$CHANNELPAGE", int),
    "context.selected_executor": ("$SELECTEDEXEC", None),
    "context.selected_cue": ("$SELECTEDEXECCUE", None),
    "context.preset_type": ("$PRESET", None),
    "context.feature": ("$FEATURE", None),
    "context.attribute": ("$ATTRIBUTE", None),
    "programmer.selection_count": ("$SELECTEDFIXTURESCOUNT", int),
    "programmer.highlight": ("$HIGHLIGHT", None),
    "programmer.solo": ("$SOLO", None),
    "programmer.freeze": ("$FREEZE", None),
    "programmer.blind": ("$BLIND", None),
    "programmer.world": ("$WORLD", None),
    "programmer.filter": ("$FILTER", None),
    "programmer.matricks": ("$MATRICKS", None),
}


class ObserverReaders:
    """Stateful read adapters with a short shared ListVar cache."""

    def __init__(self, client_provider: ClientProvider) -> None:
        self._client_provider = client_provider
        self._listvar_lock = asyncio.Lock()
        self._listvar_cache: dict[str, str] = {}
        self._listvar_cache_monotonic = 0.0
        self._previous_playback_keys: set[str] = set()
        self._fixture_watch_ids = _parse_fixture_watch_ids(os.getenv("OMA_OBSERVER_FIXTURE_IDS", ""))
        self._fixture_watch_cache: dict[int, dict[str, Any]] = {}
        self._fixture_type_channel_cache: dict[int, list[dict[str, Any]]] = {}
        self._history_disabled: dict[str, str] = {}
        self._playback_circuit_reason: str | None = None
        self._playback_circuit_until = 0.0

    async def _variables(self, *, max_age_seconds: float = 0.2) -> dict[str, str]:
        async with self._listvar_lock:
            if self._listvar_cache and time.monotonic() - self._listvar_cache_monotonic <= max(0.0, max_age_seconds):
                return dict(self._listvar_cache)
            client = await self._client_provider()
            raw = await client.send_command_with_response(
                "ListVar",
                timeout=0.8,
                delay=0.05,
                subsequent_timeout=0.04,
                max_response_bytes=131_072,
            )
            variables = parse_listvar(raw)
            self._listvar_cache = variables
            self._listvar_cache_monotonic = time.monotonic()
            return dict(variables)

    def cached_variables(self, *, max_age_seconds: float = 3.0) -> tuple[dict[str, str], float | None]:
        """Return the latest passive ListVar cache without performing I/O."""
        if not self._listvar_cache or self._listvar_cache_monotonic <= 0:
            return {}, None
        age_seconds = max(0.0, time.monotonic() - self._listvar_cache_monotonic)
        if age_seconds > max(0.0, float(max_age_seconds)):
            return {}, age_seconds
        return dict(self._listvar_cache), age_seconds

    def invalidate_static_cache(self) -> None:
        self._listvar_cache.clear()
        self._listvar_cache_monotonic = 0.0
        self._previous_playback_keys.clear()
        self._fixture_watch_cache.clear()
        self._fixture_type_channel_cache.clear()

    def refresh_static_cache(self) -> None:
        """Invalidate only observer-owned static fixture/type metadata."""
        self._fixture_watch_cache.clear()
        self._fixture_type_channel_cache.clear()

    async def read_console_context(self) -> ObserverSample:
        variables = await self._variables(max_age_seconds=0.15)
        fields: dict[str, FieldValue] = {}
        for field_name, (variable_name, caster) in _CONTEXT_VARIABLES.items():
            raw_value = variables.get(variable_name)
            if raw_value is None or raw_value == "":
                fields[field_name] = FieldValue(
                    None,
                    Availability.UNAVAILABLE,
                    False,
                    f"{variable_name} is not exposed in the current ListVar response.",
                )
                continue
            if caster is not None:
                try:
                    value = caster(raw_value)
                except (TypeError, ValueError):
                    fields[field_name] = FieldValue(
                        None,
                        Availability.ERROR,
                        False,
                        f"{variable_name} returned a non-{caster.__name__} value.",
                    )
                    continue
            else:
                value = raw_value
            fields[field_name] = FieldValue(value, Availability.AVAILABLE, True, f"grandMA2 ListVar {variable_name}")

        fields["programmer.attribute_values"] = FieldValue(
            None,
            Availability.UNKNOWN,
            False,
            "Passive ListVar exposes encoder context, not verified programmer values.",
        )
        return ObserverSample(
            source="console_context",
            fields=fields,
            source_note="Bounded ListVar snapshot; no pool or patch scan.",
        )

    async def read_selection_detail(self) -> ObserverSample:
        """Read exact Selection IDs only when the fixed Lua evidence is complete.

        This deliberately uses only the direct Selection-child probe.  The older
        fallback that tested every patched Fixture is suitable for an on-demand
        diagnostic, but would be a patch-sized scan and is therefore prohibited
        in the continuous observer.
        """
        variables = await self._variables(max_age_seconds=0.2)
        try:
            expected_count = int(variables.get("$SELECTEDFIXTURESCOUNT", ""))
        except (TypeError, ValueError):
            return ObserverSample(
                "selection_detail",
                {
                    "programmer.fixture_ids": FieldValue(
                        None,
                        Availability.ERROR,
                        False,
                        "$SELECTEDFIXTURESCOUNT was absent or non-numeric.",
                    )
                },
            )

        client = await self._client_provider()
        raw = await client.send_command_with_response(
            run_lua(build_readonly_selection_lua_probe()),
            timeout=0.8,
            delay=0.04,
            subsequent_timeout=0.04,
            max_response_bytes=65_536,
        )
        parsed = parse_readonly_lua_probe(raw)
        members = parsed.get("selection_members") or []
        lua_amount = parsed.get("selection_amount")
        handle = parsed.get("selection_handle")

        if expected_count == 0 and handle and lua_amount == 0 and not members:
            return ObserverSample(
                "selection_detail",
                {
                    "programmer.fixture_ids": FieldValue(
                        [],
                        Availability.AVAILABLE,
                        True,
                        "ListVar count and the fixed read-only Selection probe both report empty.",
                    )
                },
                source_note="Fixed bridge-owned read-only Lua Selection probe.",
            )

        member_ids = [item.get("number") for item in members]
        direct_ids_valid = bool(
            handle
            and 0 < expected_count <= 64
            and lua_amount == expected_count
            and len(member_ids) == expected_count
            and len(set(member_ids)) == expected_count
            and all(isinstance(item, int) and item > 0 for item in member_ids)
        )
        if direct_ids_valid:
            fixture_ids = sorted(int(item) for item in member_ids)
            # Sparse additive syntax only.  Never serialize unrelated IDs using Thru.
            inventory_raw = await client.send_command_with_response(
                "List Fixture " + " + ".join(str(item) for item in fixture_ids),
                timeout=0.8,
                delay=0.04,
                subsequent_timeout=0.04,
                max_response_bytes=65_536,
            )
            inventory = parse_fixture_inventory(inventory_raw)
            if all(item in inventory for item in fixture_ids):
                return ObserverSample(
                    "selection_detail",
                    {
                        "programmer.fixture_ids": FieldValue(
                            fixture_ids,
                            Availability.AVAILABLE,
                            True,
                            "Direct Selection children were count-matched and cross-checked against targeted List Fixture output.",
                        )
                    },
                    source_note="Fixed Lua probe plus targeted sparse fixture verification.",
                )

        return ObserverSample(
            "selection_detail",
            {
                "programmer.fixture_ids": FieldValue(
                    None,
                    Availability.UNKNOWN,
                    False,
                    (
                        "The direct fixed Lua Selection probe did not expose a complete, "
                        "count-matched Fixture-ID set. The observer will not run the "
                        "patch-sized membership fallback or infer members from count."
                    ),
                )
            },
            source_note="No continuous full-patch membership scan.",
        )

    async def read_fixture_watch_cache(self) -> ObserverSample:
        """Hydrate a bounded explicit fixture watchlist without a full patch read."""
        if not self._fixture_watch_ids:
            return ObserverSample(
                "fixture_watch_cache",
                {
                    "fixture.watchlist": FieldValue(
                        [],
                        Availability.UNAVAILABLE,
                        True,
                        "Set OMA_OBSERVER_FIXTURE_IDS to at most 16 explicit positive Fixture IDs.",
                    )
                },
                source_note="No fixture watchlist configured; no patch reads were issued.",
            )

        if self._fixture_watch_cache and all(
            fixture_id in self._fixture_watch_cache for fixture_id in self._fixture_watch_ids
        ):
            return self._fixture_cache_sample()

        client = await self._client_provider()
        inventory_raw = await client.send_command_with_response(
            "List Fixture " + " + ".join(str(item) for item in self._fixture_watch_ids),
            timeout=1.2,
            delay=0.05,
            subsequent_timeout=0.05,
            max_response_bytes=262_144,
        )
        inventory = parse_fixture_inventory(inventory_raw)
        targeted = {
            fixture_id: inventory[fixture_id] for fixture_id in self._fixture_watch_ids if fixture_id in inventory
        }

        fixture_type_ids = sorted(
            {int(item["fixture_type_id"]) for item in targeted.values() if item.get("fixture_type_id") is not None}
        )
        async with client.transaction("observer_fixture_watch_cache"):
            try:
                for fixture_type_id in fixture_type_ids:
                    if fixture_type_id in self._fixture_type_channel_cache:
                        continue
                    await client.send_command_with_response("cd /")
                    await client.send_command_with_response("cd EditSetup")
                    await client.send_command_with_response("cd FixtureTypes")
                    await client.send_command_with_response(f"cd {fixture_type_id}")
                    await client.send_command_with_response("cd 1")
                    await client.send_command_with_response("cd 1")
                    channel_raw = await client.send_command_with_response(
                        "list",
                        timeout=1.0,
                        delay=0.04,
                        subsequent_timeout=0.04,
                        max_response_bytes=131_072,
                    )
                    self._fixture_type_channel_cache[fixture_type_id] = parse_channel_dmx_rows(channel_raw)
            finally:
                with contextlib.suppress(Exception):
                    await client.send_command_with_response("cd /")

        self._fixture_watch_cache = {}
        for fixture_id, fixture in targeted.items():
            fixture_type_id = int(fixture["fixture_type_id"])
            mappings = resolve_attribute_dmx_addresses(
                patch=fixture.get("patch"),
                channel_rows=self._fixture_type_channel_cache.get(fixture_type_id, []),
                intensity_only=False,
            )
            self._fixture_watch_cache[fixture_id] = {
                "fixture": fixture,
                "mappings": mappings,
            }
        return self._fixture_cache_sample()

    def _fixture_cache_sample(self) -> ObserverSample:
        missing = [item for item in self._fixture_watch_ids if item not in self._fixture_watch_cache]
        fields: dict[str, FieldValue] = {
            "fixture.watchlist": FieldValue(
                self._fixture_watch_ids,
                Availability.AVAILABLE,
                True,
                "Explicit bounded OMA_OBSERVER_FIXTURE_IDS configuration.",
            ),
            "fixture.watchlist_missing": FieldValue(
                missing,
                Availability.DEGRADED if missing else Availability.AVAILABLE,
                not missing,
                "Targeted List Fixture verification; no full patch inventory.",
            ),
        }
        for fixture_id, cached in sorted(self._fixture_watch_cache.items()):
            fixture = cached["fixture"]
            fields[f"fixture.{fixture_id}.identity"] = FieldValue(
                {
                    "fixture_id": fixture_id,
                    "name": fixture.get("name"),
                    "fixture_type_id": fixture.get("fixture_type_id"),
                    "fixture_type_name": fixture.get("fixture_type_name"),
                    "patch": fixture.get("patch"),
                },
                Availability.AVAILABLE,
                True,
                "Targeted List Fixture plus cached FixtureType ChannelType rows.",
            )
        return ObserverSample(
            "fixture_watch_cache",
            fields,
            source_note="Static metadata cache; rebuilt only after explicit invalidation or show change.",
        )

    async def read_fixture_watch_output(self) -> ObserverSample:
        """Read calculated DMX deltas for the already-hydrated watchlist."""
        if not self._fixture_watch_ids:
            return ObserverSample(
                "fixture_watch_output",
                {
                    "fixture.output": FieldValue(
                        None,
                        Availability.UNAVAILABLE,
                        True,
                        "No fixture watchlist configured.",
                    )
                },
            )
        if not self._fixture_watch_cache:
            return ObserverSample(
                "fixture_watch_output",
                {
                    "fixture.output": FieldValue(
                        None,
                        Availability.STALE,
                        False,
                        "Waiting for bounded static watchlist hydration.",
                    )
                },
            )

        addresses: list[int] = []
        for cached in self._fixture_watch_cache.values():
            for mapping in cached["mappings"]:
                if not mapping.get("resolved"):
                    continue
                addresses.append(int(mapping["coarse_absolute"]))
                if mapping.get("fine_absolute") is not None:
                    addresses.append(int(mapping["fine_absolute"]))
        addresses = list(dict.fromkeys(addresses))
        if len(addresses) > 512:
            return ObserverSample(
                "fixture_watch_output",
                {
                    "fixture.output": FieldValue(
                        None,
                        Availability.DEGRADED,
                        False,
                        "Watchlist resolves to more than 512 DMX addresses; reduce OMA_OBSERVER_FIXTURE_IDS.",
                    )
                },
            )

        client = await self._client_provider()
        raw = await client.send_command_with_response(
            run_lua(build_readonly_dmx_lua_probe(addresses)),
            timeout=1.0,
            delay=0.04,
            subsequent_timeout=0.04,
            max_response_bytes=131_072,
        )
        dmx_values = parse_readonly_dmx_lua_probe(raw)
        fields: dict[str, FieldValue] = {}
        for fixture_id, cached in sorted(self._fixture_watch_cache.items()):
            duplicate_count: dict[str, int] = {}
            for mapping in cached["mappings"]:
                attribute = str(mapping.get("attribute") or "UNKNOWN").upper()
                duplicate_count[attribute] = duplicate_count.get(attribute, 0) + 1
                suffix = duplicate_count[attribute]
                field_attribute = _field_token(attribute)
                if suffix > 1:
                    field_attribute = f"{field_attribute}_{suffix}"
                coarse_address = mapping.get("coarse_absolute")
                fine_address = mapping.get("fine_absolute")
                coarse = dmx_values.get(int(coarse_address)) if coarse_address is not None else None
                fine = dmx_values.get(int(fine_address)) if fine_address is not None else None
                verified = bool(
                    mapping.get("resolved") and coarse is not None and (fine_address is None or fine is not None)
                )
                fields[f"fixture.{fixture_id}.output.{field_attribute}"] = FieldValue(
                    {
                        "attribute": attribute,
                        "value_percent": (dmx_value_to_percent(coarse, fine) if verified else None),
                        "coarse_8bit": coarse,
                        "fine_8bit": fine,
                    },
                    Availability.AVAILABLE if verified else Availability.UNKNOWN,
                    verified,
                    (
                        "Calculated grandMA2 output via fixed gma.show.getdmx probe; "
                        "physical fixture emission is not asserted."
                    ),
                )
        return ObserverSample(
            "fixture_watch_output",
            fields,
            source_note="Bounded calculated DMX watchlist, not a full-output scan.",
        )

    async def read_bpm(self) -> ObserverSample:
        variables = await self._variables(max_age_seconds=0.3)
        bpm_variable = next(
            (name for name in ("$BPM", "$SOUNDBPM", "$BEATBPM") if variables.get(name) not in (None, "")),
            None,
        )
        if bpm_variable is None:
            unavailable_reason = (
                "No verified sound/BPM variable is exposed by this grandMA2 session. "
                "Missing sound input is a normal observer state."
            )
            return ObserverSample(
                "bpm",
                {
                    "bpm.sound_input": FieldValue(
                        {"available": False},
                        Availability.UNAVAILABLE,
                        False,
                        unavailable_reason,
                    ),
                    "bpm.value": FieldValue(None, Availability.UNAVAILABLE, False, unavailable_reason),
                    "bpm.speed_master": FieldValue(
                        None,
                        Availability.UNKNOWN,
                        False,
                        "No verified passive numeric SpeedMaster read is configured.",
                    ),
                    "bpm.external_source": FieldValue(
                        None,
                        Availability.UNKNOWN,
                        False,
                        "No external tempo-source adapter is configured.",
                    ),
                },
            )

        raw = variables[bpm_variable].strip().replace(",", ".")
        match = re.search(r"-?\d+(?:\.\d+)?", raw)
        if match is None:
            return ObserverSample(
                "bpm",
                {
                    "bpm.sound_input": FieldValue(
                        {"available": True, "stable": False},
                        Availability.DEGRADED,
                        False,
                        f"{bpm_variable} was present but not numeric.",
                    ),
                    "bpm.value": FieldValue(
                        None,
                        Availability.DEGRADED,
                        False,
                        f"Unparseable value from {bpm_variable}.",
                    ),
                },
            )
        value = float(match.group(0))
        if not 1 <= value <= 300:
            return ObserverSample(
                "bpm",
                {
                    "bpm.sound_input": FieldValue(
                        {"available": True, "stable": False},
                        Availability.DEGRADED,
                        False,
                        f"{bpm_variable} was outside the accepted 1-300 BPM range.",
                    ),
                    "bpm.value": FieldValue(
                        None,
                        Availability.DEGRADED,
                        False,
                        f"Out-of-range value from {bpm_variable}.",
                    ),
                },
            )
        return ObserverSample(
            "bpm",
            {
                "bpm.sound_input": FieldValue(
                    {"available": True, "stable": True, "source": bpm_variable},
                    Availability.AVAILABLE,
                    True,
                    "Numeric grandMA2 system variable.",
                ),
                "bpm.value": FieldValue(
                    value,
                    Availability.AVAILABLE,
                    True,
                    f"grandMA2 ListVar {bpm_variable}",
                ),
            },
        )

    async def read_playback(self) -> ObserverSample:
        now = time.monotonic()
        if self._playback_circuit_reason is not None:
            if self._playback_circuit_until == float("inf") or now < self._playback_circuit_until:
                raise ObserverSourceUnavailableError(self._playback_circuit_reason)
            self._playback_circuit_reason = None
            self._playback_circuit_until = 0.0

        variables = await self._variables(max_age_seconds=0.3)
        pages: set[int] = set()
        for name in ("$FADERPAGE", "$BUTTONPAGE"):
            try:
                value = int(variables.get(name, ""))
            except (TypeError, ValueError):
                continue
            if 1 <= value <= 999:
                pages.add(value)
        if not pages:
            pages.add(1)

        client = await self._client_provider()
        web_remote_port = _bounded_int_env("GMA_WEB_REMOTE_PORT", 80, 1, 65535)
        web_remote_timeout = _bounded_float_env("GMA_WEB_REMOTE_TIMEOUT", 4.0, 1.0, 10.0)
        remote = GMA2WebRemoteClient(
            host=client.host,
            user=client.user,
            password=client.password,
            port=web_remote_port,
            timeout=web_remote_timeout,
        )
        try:
            payloads = await remote.read_pages(sorted(pages))
        except WebRemoteError as exc:
            message = str(exc)
            normalized = message.casefold()
            if (
                "session limit reached" in normalized
                or "connections_limit_reached" in normalized
                or "maximum three remote users" in normalized
            ):
                self._playback_circuit_reason = (
                    "grandMA2 Web Remote session limit reached; playback telemetry is "
                    "quarantined until Observer restart. Other telemetry continues."
                )
                self._playback_circuit_until = float("inf")
            else:
                retry_seconds = _bounded_float_env(
                    "OMA_OBSERVER_WEB_REMOTE_RETRY_SECONDS",
                    30.0,
                    5.0,
                    600.0,
                )
                self._playback_circuit_reason = (
                    f"grandMA2 Web Remote unavailable: {message}; playback retry is "
                    f"suppressed for {retry_seconds:.0f}s. Other telemetry continues."
                )
                self._playback_circuit_until = now + retry_seconds
            raise ObserverSourceUnavailableError(self._playback_circuit_reason) from exc
        fields: dict[str, FieldValue] = {
            "playback.pages_scanned": FieldValue(
                sorted(pages), Availability.AVAILABLE, True, "Current fader/button pages only."
            )
        }
        current_keys: set[str] = set()
        for requested_page, payload in payloads:
            for item in normalize_playback_response(payload, requested_page=requested_page):
                fader_value = item.get("fader_value")
                keep = bool(
                    item.get("object_reference")
                    or item.get("is_active")
                    or item.get("current_cue")
                    or fader_value not in (None, 0, 0.0, "0", "0.0")
                )
                if not keep:
                    continue
                page = item.get("page") or requested_page
                executor = item.get("executor")
                if not isinstance(executor, int):
                    continue
                base = f"playback.{page}.{executor}"
                current_keys.add(base)
                fields[f"{base}.is_active"] = FieldValue(
                    bool(item.get("is_active")),
                    Availability.AVAILABLE,
                    True,
                    "grandMA2 Web Remote playbacks/isRun",
                )
                fields[f"{base}.fader_value"] = FieldValue(
                    fader_value,
                    Availability.AVAILABLE if fader_value is not None else Availability.UNKNOWN,
                    fader_value is not None,
                    "grandMA2 Web Remote playback fader",
                )
                fields[f"{base}.current_cue"] = FieldValue(
                    item.get("current_cue"),
                    Availability.AVAILABLE if item.get("current_cue") is not None else Availability.UNKNOWN,
                    item.get("current_cue") is not None,
                    "grandMA2 Web Remote current cue",
                )
                fields[f"{base}.assignment"] = FieldValue(
                    item.get("object_reference"),
                    Availability.AVAILABLE if item.get("object_reference") else Availability.UNKNOWN,
                    bool(item.get("object_reference")),
                    "grandMA2 Web Remote object reference",
                )

        for base in self._previous_playback_keys - current_keys:
            fields[f"{base}.is_active"] = FieldValue(
                False,
                Availability.AVAILABLE,
                True,
                "Executor disappeared from the current bounded playback set.",
            )
        self._previous_playback_keys = current_keys
        return ObserverSample(
            source="playback",
            fields=fields,
            source_note="Typed read-only Web Remote playback channel.",
        )

    async def read_message_history(self) -> ObserverSample:
        if not _env_flag("OMA_OBSERVER_ENABLE_MESSAGE_HISTORY", False):
            return _history_unavailable_sample(
                source="messages",
                field="history.message_center",
                reason=(
                    "Continuous List Messages polling is disabled because grandMA2 3.9.63.6 "
                    "does not expose a verified bounded/tail interface and the live response may "
                    "grow without limit. Set OMA_OBSERVER_ENABLE_MESSAGE_HISTORY=1 only for a "
                    "controlled diagnostic run."
                ),
            )
        return await self._read_history(
            source="messages",
            command=list_messages(),
            field="history.message_center",
            note=("Message Center output; not asserted to be the GUI Command Line Feedback or a physical-key stream."),
        )

    async def read_oops_history(self) -> ObserverSample:
        return await self._read_history(
            source="oops_history",
            command=list_oops(),
            field="history.oops",
            note="grandMA2 Oops/Undo history, not GUI Command Line Feedback.",
        )

    async def read_update_history(self) -> ObserverSample:
        return await self._read_history(
            source="update_history",
            command=list_update(),
            field="history.update",
            note="grandMA2 Update history, not GUI Command Line Feedback.",
        )

    async def _read_history(
        self,
        *,
        source: str,
        command: str,
        field: str,
        note: str,
    ) -> ObserverSample:
        disabled_reason = self._history_disabled.get(source)
        if disabled_reason is not None:
            return _history_unavailable_sample(
                source=source,
                field=field,
                reason=disabled_reason,
                status=Availability.DEGRADED,
            )
        client = await self._client_provider()
        max_response_bytes = _bounded_int_env(
            "OMA_OBSERVER_HISTORY_MAX_BYTES",
            65_536,
            16_384,
            131_072,
        )
        try:
            raw = await client.send_command_with_response(
                command,
                timeout=1.2,
                delay=0.05,
                subsequent_timeout=0.05,
                max_response_bytes=max_response_bytes,
            )
        except TelnetResponseLimitError as exc:
            disabled_reason = (
                f"{source} exceeded the bounded observer response limit "
                f"({exc.received_bytes} > {exc.limit_bytes} bytes). Continuous polling for "
                "this unbounded source is circuit-broken until Observer restart."
            )
            self._history_disabled[source] = disabled_reason
            return _history_unavailable_sample(
                source=source,
                field=field,
                reason=disabled_reason,
                status=Availability.DEGRADED,
            )
        lines = _bounded_feedback_lines(raw)
        return ObserverSample(
            source,
            {
                field: FieldValue(
                    lines,
                    Availability.AVAILABLE if lines else Availability.UNAVAILABLE,
                    False,
                    note,
                )
            },
            source_note=note,
        )

    async def read_capability_status(self) -> ObserverSample:
        return ObserverSample(
            "observer_capabilities",
            {
                "history.command_line_feedback_gui": FieldValue(
                    None,
                    Availability.UNAVAILABLE,
                    False,
                    "No verified external read interface for the exact grandMA2 3.9.63.6 GUI Command Line Feedback buffer is installed.",
                ),
                "history.message_center_polling": FieldValue(
                    {
                        "enabled": _env_flag("OMA_OBSERVER_ENABLE_MESSAGE_HISTORY", False),
                        "circuit_broken": "messages" in self._history_disabled,
                    },
                    Availability.AVAILABLE,
                    True,
                    "Unbounded Message Center polling is fail-closed by default.",
                ),
                "history.physical_keypresses": FieldValue(
                    None,
                    Availability.UNAVAILABLE,
                    False,
                    "State/history deltas do not prove every physical keypress on a light console.",
                ),
                "fixture.full_patch_poll": FieldValue(
                    None,
                    Availability.UNAVAILABLE,
                    True,
                    "Continuous full-patch polling is intentionally disabled; static data is rebuilt only after show/patch invalidation.",
                ),
                "fixture.bounded_output_watchlist": FieldValue(
                    self._fixture_watch_ids,
                    (Availability.AVAILABLE if self._fixture_watch_ids else Availability.UNAVAILABLE),
                    True,
                    "Up to 16 explicit Fixture IDs; static type data is cached and calculated DMX is polled as deltas.",
                ),
                "programmer.exact_values": FieldValue(
                    None,
                    Availability.UNKNOWN,
                    False,
                    "No fabricated programmer values; enable only a separately verified bounded reader.",
                ),
            },
        )


def _bounded_feedback_lines(raw: str, *, max_lines: int = 80) -> list[str]:
    if not isinstance(raw, str):
        return []
    lines: list[str] = []
    for line in raw.splitlines():
        clean = " ".join(line.strip().split())
        if not clean:
            continue
        if len(clean) > 1024:
            clean = clean[:1024] + "…"
        lines.append(clean)
    return lines[-max_lines:]


def _history_unavailable_sample(
    *,
    source: str,
    field: str,
    reason: str,
    status: Availability = Availability.UNAVAILABLE,
) -> ObserverSample:
    return ObserverSample(
        source,
        {
            field: FieldValue(
                None,
                status,
                False,
                reason,
            )
        },
        source_note=reason,
    )


def _env_flag(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().casefold() in {"1", "true", "yes", "on"}


def _parse_fixture_watch_ids(raw: str) -> list[int]:
    result: list[int] = []
    seen: set[int] = set()
    for token in re.split(r"[\s,;+]+", raw.strip()):
        if not token:
            continue
        try:
            fixture_id = int(token)
        except (TypeError, ValueError):
            continue
        if fixture_id <= 0 or fixture_id in seen:
            continue
        seen.add(fixture_id)
        result.append(fixture_id)
        if len(result) >= 16:
            break
    return result


def _field_token(value: str) -> str:
    clean = re.sub(r"[^A-Za-z0-9]+", "_", value.strip()).strip("_").lower()
    return clean[:64] or "unknown"


def _bounded_int_env(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


def _bounded_float_env(
    name: str,
    default: float,
    minimum: float,
    maximum: float,
) -> float:
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


__all__ = ["ObserverReaders"]
