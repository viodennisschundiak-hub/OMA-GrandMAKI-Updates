"""Pure parsers for grandMA2 Web Remote playback readback.

The Telnet ``List Executor`` output describes assignments.  The Web Remote
playback payload additionally carries the runtime ``isRun`` flag, current cue,
progress and fader data used by the onPC user interface.  This module contains
no network I/O; it only normalizes those payloads into stable bridge records.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from typing import Any

from src.prompt_parser import parse_list_output


def _text(value: Any) -> str | None:
    """Extract MA Web Remote ``{t: ...}`` display text."""
    if isinstance(value, dict):
        value = value.get("t")
    if value is None:
        return None
    rendered = str(value).strip()
    return rendered or None


def _walk_playback_items(value: Any) -> Iterator[dict[str, Any]]:
    """Yield playback item dictionaries from the nested itemGroups shape."""
    if isinstance(value, dict):
        if "iExec" in value and "executorBlocks" in value:
            yield value
            return
        for child in value.values():
            yield from _walk_playback_items(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk_playback_items(child)


def extract_numeric_object_id(*values: Any) -> int | None:
    """Return the first unambiguous positive integer in MA display strings."""
    for value in values:
        rendered = _text(value)
        if not rendered:
            continue
        match = re.search(r"(?:^|\b)(\d+)(?:\b|$)", rendered)
        if match:
            number = int(match.group(1))
            if number > 0:
                return number
    return None


def normalize_playback_response(
    payload: dict[str, Any],
    *,
    requested_page: int | None = None,
) -> list[dict[str, Any]]:
    """Normalize one grandMA2 ``responseType=playbacks`` payload."""
    if payload.get("responseType") != "playbacks":
        return []

    page_value = payload.get("iPage", requested_page)
    try:
        page = int(page_value)
    except (TypeError, ValueError):
        page = requested_page

    normalized: list[dict[str, Any]] = []
    for item in _walk_playback_items(payload.get("itemGroups", [])):
        try:
            executor = int(item.get("iExec")) + 1
        except (TypeError, ValueError):
            continue

        blocks = item.get("executorBlocks") or []
        first_block = blocks[0] if blocks and isinstance(blocks[0], dict) else {}
        first_button = _text(first_block.get("button1"))
        empty = (first_button or "").casefold() == "empty"

        cue_items = ((item.get("cues") or {}).get("items") or [])
        current_cue_item: dict[str, Any] = {}
        if cue_items:
            current_index = 1 if len(cue_items) >= 3 else 0
            candidate = cue_items[current_index]
            if isinstance(candidate, dict):
                current_cue_item = candidate

        fader = first_block.get("fader") if isinstance(first_block, dict) else None
        if not isinstance(fader, dict):
            fader = {}

        object_type = _text(item.get("oType"))
        object_reference = _text(item.get("oI"))
        object_id = extract_numeric_object_id(object_reference, item.get("i"))
        normalized.append({
            "page": page,
            "executor": executor,
            "page_qualified": f"{page}.{executor}" if page is not None else None,
            "is_active": bool(item.get("isRun")),
            "is_selected": str(item.get("bC", "")).upper() == "#00FF00",
            "empty": empty,
            "label": _text(item.get("tt")) or "",
            "object_type": object_type,
            "object_reference": object_reference,
            "object_id": object_id,
            "current_cue": _text(current_cue_item),
            "current_cue_progress": (current_cue_item.get("pgs") or {}).get("v")
            if isinstance(current_cue_item.get("pgs"), dict)
            else None,
            "fader_value": fader.get("v"),
            "fader_value_text": fader.get("vT"),
            "width": len(blocks) or 1,
            "web_remote_response_subtype": payload.get("responseSubType"),
        })
    return normalized


def parse_page_ids(raw: str) -> list[int]:
    """Parse existing executor page IDs from ``List Page`` output."""
    result: set[int] = set()
    for entry in parse_list_output(raw).entries:
        if (entry.object_type or "").casefold() != "page" or not entry.object_id:
            continue
        try:
            page = int(float(entry.object_id))
        except ValueError:
            continue
        if page > 0:
            result.add(page)
    return sorted(result)


def parse_effect_pool(raw: str) -> list[dict[str, Any]]:
    """Parse Effect pool IDs and labels from ``List Effect`` output."""
    effects: list[dict[str, Any]] = []
    for entry in parse_list_output(raw).entries:
        if not (entry.object_type or "").casefold().startswith("effect"):
            continue
        try:
            effect_id = int(float(entry.object_id or ""))
        except ValueError:
            continue
        if effect_id <= 0:
            continue
        effects.append({
            "effect_id": effect_id,
            "name": entry.name or "",
            "raw_line": entry.raw_line or "",
        })
    return sorted(effects, key=lambda item: item["effect_id"])
