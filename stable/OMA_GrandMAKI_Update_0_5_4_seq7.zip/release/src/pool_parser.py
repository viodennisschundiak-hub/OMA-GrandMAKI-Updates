"""Robust parsers for grandMA2 ``List <Pool>`` tabular output.

MA2 3.9 abbreviates some row class names (notably ``Sequence`` -> ``Sequ``)
and prefixes rows with a row index plus the real pool object number.  Keeping
this parser independent from the MCP server makes degraded-read detection
unit-testable without a live console or MCP runtime.
"""

from __future__ import annotations

import re

POOL_ROW_ALIASES: dict[str, tuple[str, ...]] = {
    "sequence": ("Sequence", "Sequ"),
    "group": ("Group",),
    "macro": ("Macro",),
    "world": ("World",),
    "filter": ("Filter",),
    "effect": ("Effect",),
    "timecode": ("Timecode",),
    "timer": ("Timer",),
    "view": ("View",),
    "layout": ("Layout",),
    "page": ("Page",),
    "fixture": ("Fixture", "Fix"),
    "executor": ("Executor", "Exec"),
}
ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def strip_ansi(raw: str) -> str:
    return ANSI_ESCAPE_RE.sub("", raw or "")


def pool_aliases(keyword: str) -> tuple[str, ...]:
    key = keyword.strip().lower()
    return POOL_ROW_ALIASES.get(key, (keyword,))


def parse_pool_ids(raw: str, keyword: str) -> list[int]:
    """Extract object IDs from rows such as ``Sequ  1 1  Name ...``."""
    aliases = "|".join(re.escape(a) for a in pool_aliases(keyword))
    pattern = re.compile(
        rf"^\s*(?:{aliases})\s+\d+\s+(\d+)\b",
        re.IGNORECASE | re.MULTILINE,
    )
    clean = strip_ansi(raw)
    return sorted({int(m.group(1)) for m in pattern.finditer(clean)})


def pool_parse_health(raw: str, keyword: str, ids: list[int] | None = None) -> dict:
    """Return conservative parser/read health for one pool response.

    An empty response, console error, or recognizable object rows that yielded
    no IDs is DEGRADE.  A console-declared empty pool is healthy.  This prevents
    a transport/parser failure from being silently stored as ``[]``.
    """
    clean = strip_ansi(raw)
    upper = clean.upper()
    parsed = parse_pool_ids(clean, keyword) if ids is None else ids
    aliases = "|".join(re.escape(a) for a in pool_aliases(keyword))
    row_hint = re.compile(rf"^\s*(?:{aliases})\b", re.IGNORECASE | re.MULTILINE)
    row_hints = len(row_hint.findall(clean))
    generic_object_rows = len(re.findall(
        r"^\s*[A-Za-z][A-Za-z0-9_]*\s+\d+\s+\d+\b",
        clean,
        re.MULTILINE,
    ))

    if not clean.strip():
        return {"status": "degraded", "count": 0, "reason": "empty_response"}
    if "ERROR #" in upper or "INSUFFICIENT USER RIGHTS" in upper:
        return {"status": "degraded", "count": len(parsed), "reason": "console_error"}
    if parsed:
        return {"status": "ok", "count": len(parsed), "reason": None}
    if "NO OBJECTS FOUND" in upper:
        return {"status": "ok", "count": 0, "reason": None}
    if row_hints or generic_object_rows:
        return {
            "status": "degraded",
            "count": 0,
            "reason": "parser_mismatch",
            "row_hints": row_hints,
            "generic_object_rows": generic_object_rows,
        }
    # Heading/prompt-only response is a valid representation of an empty pool.
    return {"status": "ok", "count": 0, "reason": None}


def parse_pool_entries(raw: str) -> list[tuple[int, str]]:
    """Parse generic pool rows into ``(object_id, display_name)`` pairs.

    Supports both live MA2 class-prefixed rows and compact numeric test/export
    rows.  The name column ends at the next 2+ whitespace column boundary.
    """
    clean = strip_ansi(raw)
    class_row = re.compile(r"^\s*\S+\s+\d+\s+(\d+)\s+(.+)$")
    compact_row = re.compile(r"^\s*(\d+)\s+(.+)$")
    entries: list[tuple[int, str]] = []

    for line in clean.splitlines():
        if not line.strip() or line.lstrip().startswith("["):
            continue
        upper = line.upper()
        if "EXECUTING :" in upper or "NO OBJECTS FOUND" in upper:
            continue

        match = class_row.match(line)
        if match:
            obj_id = int(match.group(1))
            remainder = match.group(2).strip()
        else:
            match = compact_row.match(line)
            if not match:
                continue
            obj_id = int(match.group(1))
            remainder = match.group(2).strip()

        name = re.split(r"\s{2,}", remainder, maxsplit=1)[0]
        name = name.strip('"').strip("'").strip()
        if name and name.lower() not in {"name", "no."}:
            entries.append((obj_id, name))

    return entries


__all__ = [
    "POOL_ROW_ALIASES",
    "parse_pool_entries",
    "parse_pool_ids",
    "pool_parse_health",
    "strip_ansi",
]
