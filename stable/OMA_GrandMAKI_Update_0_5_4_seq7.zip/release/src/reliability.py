"""Failure isolation and health accounting for OMA bridge operations.

This module deliberately contains no grandMA2 command knowledge and performs no
network I/O.  It supervises awaitables in child tasks so cancellation of one MCP
request cannot unwind the server task that owns the request transport.
"""

from __future__ import annotations

import asyncio
import contextlib
import contextvars
import os
import time
import uuid
from collections import Counter
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, TypeVar

T = TypeVar("T")


class OperationLane(StrEnum):
    """Logically isolated work classes.

    Telnet I/O remains serialized by ``TelnetTransactionGate``.  These lanes
    prevent heavy analysis jobs from exhausting the worker capacity needed by
    fast state, writes and the watchdog.
    """

    FAST_LIVE_READ = "FAST_LIVE_READ"
    HEAVY_ANALYSIS = "HEAVY_ANALYSIS"
    WRITE = "WRITE"
    WATCHDOG = "WATCHDOG"


current_operation_lane: contextvars.ContextVar[OperationLane | None] = contextvars.ContextVar(
    "oma_operation_lane", default=None
)


@dataclass(frozen=True)
class CancellationOutcome:
    settled: bool
    task_state: str


class OperationTimeoutError(TimeoutError):
    """Raised after only the supervised child operation has timed out."""

    def __init__(
        self,
        *,
        operation: str,
        lane: OperationLane,
        timeout_seconds: float,
        cancellation: CancellationOutcome,
    ) -> None:
        super().__init__(f"{operation} timed out after {timeout_seconds:.1f} seconds")
        self.operation = operation
        self.lane = lane
        self.timeout_seconds = timeout_seconds
        self.cancellation = cancellation


class OperationCancelledError(RuntimeError):
    """A request cancellation contained at the supervised-operation boundary."""

    def __init__(
        self,
        *,
        operation: str,
        lane: OperationLane,
        cancellation: CancellationOutcome,
    ) -> None:
        super().__init__(f"{operation} was cancelled")
        self.operation = operation
        self.lane = lane
        self.cancellation = cancellation


@dataclass
class _ActiveOperation:
    operation_id: str
    name: str
    lane: OperationLane
    started_monotonic: float


_HEAVY_NAME_FRAGMENTS = (
    "active_playbacks",
    "architect_",
    "browse_patch",
    "build_show",
    "discover_object",
    "fixture_output",
    "fixture_types",
    "hydrate_",
    "inventory",
    "plan_fixture_swap",
    "preset_library",
    "running_effects",
    "scan_",
)


class OperationSupervisor:
    """Run bridge operations in bounded, independently cancellable child tasks."""

    def __init__(
        self,
        *,
        fast_read_limit: int | None = None,
        heavy_limit: int | None = None,
        write_limit: int | None = None,
        watchdog_limit: int | None = None,
        cancel_grace_seconds: float | None = None,
    ) -> None:
        limits = {
            OperationLane.FAST_LIVE_READ: fast_read_limit or _bounded_int_env("OMA_FAST_READ_WORKERS", 4, 1, 32),
            OperationLane.HEAVY_ANALYSIS: heavy_limit or _bounded_int_env("OMA_HEAVY_READ_WORKERS", 1, 1, 4),
            OperationLane.WRITE: write_limit or _bounded_int_env("OMA_WRITE_WORKERS", 1, 1, 4),
            OperationLane.WATCHDOG: watchdog_limit or _bounded_int_env("OMA_WATCHDOG_WORKERS", 1, 1, 2),
        }
        self._limits = limits
        self._semaphores = {lane: asyncio.Semaphore(limit) for lane, limit in limits.items()}
        self._cancel_grace_seconds = (
            cancel_grace_seconds
            if cancel_grace_seconds is not None
            else _bounded_float_env("OMA_CANCEL_GRACE_SECONDS", 1.0, 0.05, 10.0)
        )
        self._active: dict[str, _ActiveOperation] = {}
        self._waiting: Counter[OperationLane] = Counter()
        self._started: Counter[OperationLane] = Counter()
        self._completed: Counter[OperationLane] = Counter()
        self._failed: Counter[OperationLane] = Counter()
        self._timed_out: Counter[OperationLane] = Counter()
        self._cancelled: Counter[OperationLane] = Counter()
        self._orphans: set[asyncio.Task[Any]] = set()
        self._last_success_monotonic: float | None = None
        self._last_successful_read_monotonic: float | None = None
        self._last_failure: dict[str, Any] | None = None

    @staticmethod
    def classify(name: str, risk_tier: str) -> OperationLane:
        clean = name.casefold()
        if clean.startswith(("watchdog_", "bridge_health")):
            return OperationLane.WATCHDOG
        if risk_tier != "SAFE_READ":
            return OperationLane.WRITE
        if any(fragment in clean for fragment in _HEAVY_NAME_FRAGMENTS):
            return OperationLane.HEAVY_ANALYSIS
        return OperationLane.FAST_LIVE_READ

    async def run(
        self,
        *,
        name: str,
        risk_tier: str,
        operation_factory: Callable[[], Awaitable[T]],
        timeout_seconds: float,
        lane: OperationLane | None = None,
    ) -> T:
        selected_lane = lane or self.classify(name, risk_tier)
        operation_id = uuid.uuid4().hex
        timeout_seconds = max(0.05, float(timeout_seconds))
        self._waiting[selected_lane] += 1

        async def lane_worker() -> T:
            acquired = False
            token: contextvars.Token[OperationLane | None] | None = None
            try:
                await self._semaphores[selected_lane].acquire()
                acquired = True
                self._waiting[selected_lane] -= 1
                self._started[selected_lane] += 1
                token = current_operation_lane.set(selected_lane)
                self._active[operation_id] = _ActiveOperation(
                    operation_id=operation_id,
                    name=name,
                    lane=selected_lane,
                    started_monotonic=time.monotonic(),
                )
                result = await operation_factory()
                self._completed[selected_lane] += 1
                now = time.monotonic()
                self._last_success_monotonic = now
                if risk_tier == "SAFE_READ":
                    self._last_successful_read_monotonic = now
                return result
            except asyncio.CancelledError:
                raise
            except BaseException as exc:
                self._failed[selected_lane] += 1
                self._last_failure = {
                    "operation": name,
                    "lane": selected_lane.value,
                    "error_class": type(exc).__name__,
                    "at_monotonic": time.monotonic(),
                }
                raise
            finally:
                self._active.pop(operation_id, None)
                if token is not None:
                    current_operation_lane.reset(token)
                if acquired:
                    self._semaphores[selected_lane].release()
                else:
                    self._waiting[selected_lane] -= 1

        task = asyncio.create_task(
            lane_worker(),
            name=f"oma:{selected_lane.value}:{name}:{operation_id[:8]}",
        )
        try:
            done, _ = await asyncio.wait({task}, timeout=timeout_seconds)
            if not done:
                self._timed_out[selected_lane] += 1
                cancellation = await self._cancel_child(task, "operation timeout")
                raise OperationTimeoutError(
                    operation=name,
                    lane=selected_lane,
                    timeout_seconds=timeout_seconds,
                    cancellation=cancellation,
                )
            return await task
        except asyncio.CancelledError:
            # Contain request cancellation here.  Returning a structured
            # CANCELLED result is the caller's responsibility; the MCP server
            # task and its transport never receive CancelledError from this job.
            self._cancelled[selected_lane] += 1
            cancellation = await self._cancel_child(task, "request cancelled")
            raise OperationCancelledError(
                operation=name,
                lane=selected_lane,
                cancellation=cancellation,
            ) from None

    async def _cancel_child(
        self,
        task: asyncio.Task[Any],
        reason: str,
    ) -> CancellationOutcome:
        if task.done():
            _consume_task_result(task)
            return CancellationOutcome(settled=True, task_state="already_done")

        task.cancel(reason)
        try:
            done, _ = await asyncio.wait({task}, timeout=self._cancel_grace_seconds)
        except asyncio.CancelledError:
            # A second caller-side cancel is also contained.  The child remains
            # tracked and cannot become an un-retrieved task exception.
            done = set()

        if done:
            _consume_task_result(task)
            return CancellationOutcome(settled=True, task_state="cancelled")

        self._orphans.add(task)
        task.add_done_callback(self._orphan_done)
        return CancellationOutcome(settled=False, task_state="cleanup_pending")

    def _orphan_done(self, task: asyncio.Task[Any]) -> None:
        self._orphans.discard(task)
        _consume_task_result(task)

    def snapshot(self) -> dict[str, Any]:
        now = time.monotonic()

        def age(value: float | None) -> float | None:
            return None if value is None else round(max(0.0, now - value), 3)

        active = [
            {
                "operation": item.name,
                "lane": item.lane.value,
                "age_seconds": round(now - item.started_monotonic, 3),
            }
            for item in self._active.values()
        ]
        return {
            "lanes": {
                lane.value: {
                    "limit": self._limits[lane],
                    "active": sum(1 for item in self._active.values() if item.lane == lane),
                    "waiting": max(0, self._waiting[lane]),
                    "started": self._started[lane],
                    "completed": self._completed[lane],
                    "failed": self._failed[lane],
                    "timed_out": self._timed_out[lane],
                    "cancelled": self._cancelled[lane],
                }
                for lane in OperationLane
            },
            "active_operations": sorted(active, key=lambda item: item["age_seconds"], reverse=True),
            "cleanup_pending": len(self._orphans),
            "seconds_since_any_success": age(self._last_success_monotonic),
            "seconds_since_successful_read": age(self._last_successful_read_monotonic),
            "last_failure": self._last_failure,
        }


class BridgeWatchdog:
    """Low-cost event-loop heartbeat with a side-effect-free health probe."""

    def __init__(self, *, interval_seconds: float | None = None) -> None:
        self._interval = (
            interval_seconds
            if interval_seconds is not None
            else _bounded_float_env("OMA_WATCHDOG_INTERVAL_SECONDS", 2.0, 0.25, 60.0)
        )
        self._task: asyncio.Task[None] | None = None
        self._probe: Callable[[], dict[str, Any]] | None = None
        self._started_monotonic: float | None = None
        self._last_heartbeat_monotonic: float | None = None
        self._max_event_loop_lag_seconds = 0.0
        self._probe_state: dict[str, Any] = {}
        self._probe_error: str | None = None

    def set_probe(self, probe: Callable[[], dict[str, Any]]) -> None:
        self._probe = probe

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._started_monotonic = time.monotonic()
            self._task = asyncio.create_task(self._run(), name="oma:WATCHDOG:heartbeat")

    async def stop(self) -> None:
        if self._task is None:
            return
        task = self._task
        self._task = None
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

    async def _run(self) -> None:
        expected = time.monotonic() + self._interval
        while True:
            try:
                await asyncio.sleep(self._interval)
                now = time.monotonic()
                lag = max(0.0, now - expected)
                self._max_event_loop_lag_seconds = max(self._max_event_loop_lag_seconds, lag)
                self._last_heartbeat_monotonic = now
                expected = now + self._interval
                if self._probe is not None:
                    try:
                        self._probe_state = self._probe()
                        self._probe_error = None
                    except Exception as exc:  # watchdog must be immortal
                        self._probe_error = f"{type(exc).__name__}: {exc}"
            except asyncio.CancelledError:
                break
            except Exception as exc:  # pragma: no cover - final containment
                self._probe_error = f"{type(exc).__name__}: {exc}"

    def snapshot(self) -> dict[str, Any]:
        now = time.monotonic()
        return {
            "running": self._task is not None and not self._task.done(),
            "interval_seconds": self._interval,
            "uptime_seconds": None if self._started_monotonic is None else round(now - self._started_monotonic, 3),
            "seconds_since_heartbeat": None
            if self._last_heartbeat_monotonic is None
            else round(now - self._last_heartbeat_monotonic, 3),
            "max_event_loop_lag_seconds": round(self._max_event_loop_lag_seconds, 3),
            "probe": self._probe_state,
            "probe_error": self._probe_error,
        }


def _consume_task_result(task: asyncio.Task[Any]) -> None:
    with contextlib.suppress(asyncio.CancelledError, Exception):
        task.result()


def _bounded_int_env(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


def _bounded_float_env(
    name: str,
    default: float,
    minimum: float,
    maximum: float,
) -> float:
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


_GLOBAL_SUPERVISOR: OperationSupervisor | None = None
_GLOBAL_WATCHDOG: BridgeWatchdog | None = None


def get_operation_supervisor() -> OperationSupervisor:
    global _GLOBAL_SUPERVISOR
    if _GLOBAL_SUPERVISOR is None:
        _GLOBAL_SUPERVISOR = OperationSupervisor()
    return _GLOBAL_SUPERVISOR


def get_bridge_watchdog() -> BridgeWatchdog:
    global _GLOBAL_WATCHDOG
    if _GLOBAL_WATCHDOG is None:
        _GLOBAL_WATCHDOG = BridgeWatchdog()
    return _GLOBAL_WATCHDOG


__all__ = [
    "BridgeWatchdog",
    "CancellationOutcome",
    "OperationCancelledError",
    "OperationLane",
    "OperationSupervisor",
    "OperationTimeoutError",
    "current_operation_lane",
    "get_bridge_watchdog",
    "get_operation_supervisor",
]
