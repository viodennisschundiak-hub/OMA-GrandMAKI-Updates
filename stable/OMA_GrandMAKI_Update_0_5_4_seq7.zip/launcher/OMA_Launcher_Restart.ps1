#requires -Version 5.1
param([Parameter(Mandatory=$true)][int]$OldLauncherProcessId)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$launcherRoot = $PSScriptRoot
$bootstrap = Join-Path $launcherRoot 'OMA_Launcher_Bootstrap.ps1'
$logRoot = Join-Path $env:LOCALAPPDATA 'OMA_GrandMAKI_BOT\startup_logs'
New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
$log = Join-Path $logRoot ("OMA_Launcher_UpdateRestart_" + (Get-Date -Format 'yyyyMMdd_HHmmss_fff') + '.log')

function Write-RestartLog([string]$Message) {
    Add-Content -LiteralPath $log -Value ('[{0}] {1}' -f (Get-Date -Format 'o'), $Message) -Encoding UTF8
}

try {
    Write-RestartLog "Warte auf alten Launcher PID=$OldLauncherProcessId."
    $deadline = (Get-Date).AddSeconds(25)
    while ($null -ne (Get-Process -Id $OldLauncherProcessId -ErrorAction SilentlyContinue)) {
        if ((Get-Date) -ge $deadline) { throw 'Alter Launcher wurde nicht innerhalb von 25 Sekunden beendet.' }
        Start-Sleep -Milliseconds 200
    }
    if (-not (Test-Path -LiteralPath $bootstrap -PathType Leaf)) { throw 'Neuer Launcher-Bootstrap fehlt.' }
    $powerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powerShellExe -PathType Leaf)) {
        $powerShellExe = (Get-Command powershell.exe -ErrorAction Stop).Source
    }
    $arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "' + $bootstrap + '"'
    Write-RestartLog "Starte signierten Launcher aus $launcherRoot."
    Start-Process -FilePath $powerShellExe -ArgumentList $arguments -WorkingDirectory $launcherRoot -WindowStyle Hidden | Out-Null
    exit 0
} catch {
    Write-RestartLog ('FEHLER: ' + $_.Exception.Message)
    try {
        Add-Type -AssemblyName PresentationFramework
        [Windows.MessageBox]::Show(('Launcher-Neustart fehlgeschlagen. Bitte Desktop-Verknüpfung erneut öffnen.\n\nProtokoll: ' + $log), 'OMA GrandMAKI-BOT', 'OK', 'Error') | Out-Null
    } catch {}
    exit 1
}
