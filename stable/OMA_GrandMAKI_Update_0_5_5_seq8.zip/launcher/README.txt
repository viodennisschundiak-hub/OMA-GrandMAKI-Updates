OMA GRANDMAKI-BOT LAUNCHER 1.2.7
Stand: 27.08.2026

BEDIENUNG
1. grandMA2 onPC und gewünschte Show starten; Telnet Login = Enabled.
2. Observer, Programming oder Full Admin wählen.
3. Nur onPC oder Mit Lichtpult wählen.
   - Nur onPC erzwingt 127.0.0.1:30000 und ignoriert alte Pult-Adressen.
   - Mit Lichtpult verwendet die unter Einstellungen gespeicherte Pult-IP.
4. OMA STARTEN drücken.
5. Für jede Änderung und jedes Update zuerst OMA STOPPEN.

PHASE-5-UPDATER
- Der Updatekanal wird beim Öffnen im Hintergrund geprüft.
- UPDATES PRÜFEN lädt ein signiertes Suite-Paket über HTTPS.
- SHA-256 und Ed25519 müssen stimmen.
- Bridge wird im inaktiven A/B-Slot getestet.
- Launcher wird parallel unter einer neuen Versionsnummer installiert.
- Bei Fehlern wird nicht umgeschaltet bzw. automatisch zurückgerollt.
- Nach Erfolg startet der neue Launcher selbstständig.
- Der Launcher bindet sich beim Start ausschließlich an das eindeutig passende
  verifizierte A/B-Bridge-Release; alte manuelle Bridge-Pfade werden nicht
  weiterverwendet.
- Private Signierschlüssel sind niemals Bestandteil des Clients.
- Ein wiederverwendeter Launcher benötigt einen gültigen signierten
  Herkunftsnachweis; fehlende oder falsche Nachweise werden sicher abgewiesen.

HARTE SESSION-REGEL
- Bei laufender OMA- oder tunnel-client-Session sind alle Änderungen gesperrt.
- Der Browser auf Port 8091 ist ausschließlich ein GET-only-Kontrollfenster.
- Observer: OMA_MODE=observer, GMA_SCOPE=tier:0, Observer-Worker startet automatisch
- Programming: OMA_MODE=normal, GMA_SCOPE=tier:4
- Full Admin: OMA_MODE=full_admin, GMA_SCOPE=tier:5
- GMA_AUTH_BYPASS wird immer entfernt.
- Programming und Full Admin binden die Schreibfreigabe automatisch an Build,
  Modus, Scope und die per SAFE_READ gelesene Show-/Benutzer-/Versionsidentität.
- Tests, Diagnose und Updater setzen oder verändern niemals den aktiven Write-Gate.
- Freie Rohbefehle, beliebige Lua-Skripte und Plugin-Ausführung bleiben auch in
  Full Admin separat deaktiviert; alle typisierten tier:5-Werkzeuge sind verfügbar.
- Nach Show-Wechsel oder unbekanntem Schreibabschluss bleibt der Write-Gate
  gesperrt, bis OMA gestoppt und neu gestartet wurde.

STARTWEG
Der Desktop-Link startet den festen Bootstrap aus
%LOCALAPPDATA%\OMA_GrandMAKI_BOT\launcher\1.2.7.
Startfehler werden sichtbar gemeldet und unter
%LOCALAPPDATA%\OMA_GrandMAKI_BOT\startup_logs protokolliert.

DIAGNOSE
DIAGNOSE ZIP erzeugt eine geheimnisfreie Datei unter
Desktop\OMA AI assistent\Uploads.
Ein fehlgeschlagener Probe enthält dort zusätzlich nur die bereinigte,
gekürzte Fehlermeldung und niemals Zugangsdaten.
