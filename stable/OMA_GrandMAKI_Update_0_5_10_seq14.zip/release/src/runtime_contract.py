"""Machine-verifiable OMA release and MCP surface contract.

``OMA_RUNTIME_CONTRACT.json`` is the single runtime source of truth.  The
launcher, bridge preflight and tests independently compare their local version
and the client-visible FastMCP tool surface with this document.  The contract
contains no credentials, host names or show data.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Iterable, Mapping
from copy import deepcopy
from pathlib import Path
from typing import Any

RUNTIME_CONTRACT_PATH = Path(__file__).resolve().parent.parent / "OMA_RUNTIME_CONTRACT.json"
RUNTIME_CONTRACT_FILE_SHA256 = "65c8cb03329e957881c529af37e354c725ba413877f88e0bd213fb1d3baf4111"
_SHA256_PATTERN = re.compile(r"[0-9a-f]{64}")
_VERSION_PATTERN = re.compile(r"[0-9]+\.[0-9]+\.[0-9]+")


class RuntimeContractError(RuntimeError):
    """Raised when release metadata or the MCP surface violates its contract."""


def _require_mapping(value: object, *, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise RuntimeContractError(f"{name} must be a JSON object.")
    return value


def _require_string(mapping: Mapping[str, Any], key: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value:
        raise RuntimeContractError(f"{key} must be a non-empty string.")
    return value


def _load_contract(path: Path = RUNTIME_CONTRACT_PATH) -> dict[str, Any]:
    try:
        raw = path.read_bytes()
        actual_sha256 = hashlib.sha256(raw).hexdigest()
        if actual_sha256 != RUNTIME_CONTRACT_FILE_SHA256:
            raise RuntimeContractError("Runtime contract does not match its source-bound SHA-256.")
        payload = json.loads(raw.decode("utf-8-sig"))
    except RuntimeContractError:
        raise
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeContractError(f"Cannot load runtime contract: {path}") from exc

    root = _require_mapping(payload, name="runtime contract")
    if root.get("contract_id") != "oma-runtime-contract/v1":
        raise RuntimeContractError("Unsupported runtime contract id.")
    if root.get("schema_version") != 1:
        raise RuntimeContractError("Unsupported runtime contract schema version.")

    release = _require_mapping(root.get("release"), name="release")
    for key in (
        "suite_version",
        "bridge_version",
        "launcher_version",
        "basement_version",
    ):
        if not _VERSION_PATTERN.fullmatch(_require_string(release, key)):
            raise RuntimeContractError(f"{key} must use semantic X.Y.Z format.")
    sequence = release.get("update_sequence")
    if not isinstance(sequence, int) or isinstance(sequence, bool) or sequence < 1:
        raise RuntimeContractError("update_sequence must be a positive integer.")

    mcp = _require_mapping(root.get("mcp"), name="mcp")
    if not _VERSION_PATTERN.fullmatch(_require_string(mcp, "sdk_version")):
        raise RuntimeContractError("sdk_version must use semantic X.Y.Z format.")
    count = mcp.get("tool_count")
    if not isinstance(count, int) or isinstance(count, bool) or count < 1:
        raise RuntimeContractError("tool_count must be a positive integer.")
    for key in ("tool_names_sha256", "client_schema_sha256"):
        if not _SHA256_PATTERN.fullmatch(_require_string(mcp, key)):
            raise RuntimeContractError(f"{key} must be a lowercase SHA-256 digest.")
    if mcp.get("canonicalization") != "sorted-client-tool-json-v1":
        raise RuntimeContractError("Unsupported MCP canonicalization contract.")
    return dict(root)


_CONTRACT = _load_contract()
_RELEASE = _require_mapping(_CONTRACT["release"], name="release")
_MCP = _require_mapping(_CONTRACT["mcp"], name="mcp")

SUITE_VERSION = str(_RELEASE["suite_version"])
BRIDGE_VERSION = str(_RELEASE["bridge_version"])
LAUNCHER_VERSION = str(_RELEASE["launcher_version"])
BASEMENT_VERSION = str(_RELEASE["basement_version"])
UPDATE_SEQUENCE = int(_RELEASE["update_sequence"])
MCP_SDK_VERSION = str(_MCP["sdk_version"])
MCP_TOOL_COUNT = int(_MCP["tool_count"])
MCP_TOOL_NAMES_SHA256 = str(_MCP["tool_names_sha256"])
MCP_CLIENT_SCHEMA_SHA256 = str(_MCP["client_schema_sha256"])


def contract_document() -> dict[str, Any]:
    """Return an isolated copy of the secret-free contract document."""
    return deepcopy(_CONTRACT)


def contract_sha256() -> str:
    """Hash the canonical complete contract document."""
    canonical = json.dumps(
        _CONTRACT,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def public_runtime_contract() -> dict[str, Any]:
    """Return compact release identity without local paths or sensitive data."""
    return {
        "contract_id": _CONTRACT["contract_id"],
        "contract_sha256": contract_sha256(),
        "schema_version": _CONTRACT["schema_version"],
        "release": deepcopy(_RELEASE),
        "mcp": deepcopy(_MCP),
    }


def _json_value(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json", by_alias=True, exclude_none=True)
    return value


def _client_tool_payload(tool: object) -> dict[str, Any]:
    """Normalize a FastMCP internal or protocol tool to its client JSON form."""
    if isinstance(tool, Mapping):
        dumped = dict(tool)
    elif hasattr(tool, "parameters") and hasattr(tool, "name"):
        # FastMCP's internal Tool model also contains the Python callable and
        # generated output model.  Serializing that complete Pydantic object is
        # neither JSON-safe nor part of the MCP protocol surface.
        dumped = {}
    elif hasattr(tool, "model_dump"):
        dumped = tool.model_dump(mode="json", by_alias=True, exclude_none=True)
    else:
        dumped = {}

    if "inputSchema" in dumped:
        allowed = (
            "name",
            "title",
            "description",
            "inputSchema",
            "outputSchema",
            "annotations",
            "icons",
            "_meta",
        )
        payload = {key: dumped[key] for key in allowed if dumped.get(key) is not None}
    else:
        name = getattr(tool, "name", dumped.get("name", ""))
        parameters = getattr(tool, "parameters", dumped.get("parameters"))
        if not isinstance(name, str) or not name:
            raise RuntimeContractError("Every MCP tool must have a non-empty name.")
        if not isinstance(parameters, Mapping):
            raise RuntimeContractError(f"MCP tool {name!r} has no input schema.")
        payload = {"name": name}
        optional_fields = (
            ("title", "title"),
            ("description", "description"),
            ("output_schema", "outputSchema"),
            ("annotations", "annotations"),
            ("icons", "icons"),
            ("meta", "_meta"),
        )
        for source, target in optional_fields:
            value = getattr(tool, source, dumped.get(source))
            if value is not None:
                payload[target] = _json_value(value)
        payload["inputSchema"] = dict(parameters)

    name = payload.get("name")
    if not isinstance(name, str) or not name:
        raise RuntimeContractError("Every MCP tool must have a non-empty name.")
    if not isinstance(payload.get("inputSchema"), Mapping):
        raise RuntimeContractError(f"MCP tool {name!r} has no input schema.")
    return payload


def calculate_tool_registry(tools: Iterable[object]) -> dict[str, Any]:
    """Calculate count and both stable hashes for a client-visible tool set."""
    payloads = [_client_tool_payload(tool) for tool in tools]
    payloads.sort(key=lambda item: item["name"])
    names = [str(item["name"]) for item in payloads]
    if len(names) != len(set(names)):
        raise RuntimeContractError("MCP tool names must be unique.")
    canonical = json.dumps(
        payloads,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return {
        "tool_count": len(payloads),
        "tool_names_sha256": hashlib.sha256("\n".join(names).encode("utf-8")).hexdigest(),
        "client_schema_sha256": hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
        "canonicalization": "sorted-client-tool-json-v1",
    }


def verify_tool_registry(tools: Iterable[object]) -> dict[str, Any]:
    """Compare a live tool set with the immutable MCP contract."""
    actual = calculate_tool_registry(tools)
    expected = {
        key: _MCP[key]
        for key in (
            "tool_count",
            "tool_names_sha256",
            "client_schema_sha256",
            "canonicalization",
        )
    }
    checks = {key: actual[key] == expected[key] for key in expected}
    return {
        "ok": all(checks.values()),
        "checks": checks,
        "expected": expected,
        "actual": actual,
    }


def assert_tool_registry(tools: Iterable[object]) -> dict[str, Any]:
    """Return verification or fail closed before serving an altered surface."""
    result = verify_tool_registry(tools)
    if not result["ok"]:
        failed = ", ".join(key for key, value in result["checks"].items() if not value)
        raise RuntimeContractError(f"MCP runtime contract mismatch: {failed}.")
    return result


__all__ = [
    "BASEMENT_VERSION",
    "BRIDGE_VERSION",
    "LAUNCHER_VERSION",
    "MCP_CLIENT_SCHEMA_SHA256",
    "MCP_SDK_VERSION",
    "MCP_TOOL_COUNT",
    "MCP_TOOL_NAMES_SHA256",
    "RUNTIME_CONTRACT_PATH",
    "RUNTIME_CONTRACT_FILE_SHA256",
    "RuntimeContractError",
    "SUITE_VERSION",
    "UPDATE_SEQUENCE",
    "assert_tool_registry",
    "calculate_tool_registry",
    "contract_document",
    "contract_sha256",
    "public_runtime_contract",
    "verify_tool_registry",
]
