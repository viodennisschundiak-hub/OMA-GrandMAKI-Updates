"""Validation for filenames and selectors embedded in grandMA2 commands."""

from __future__ import annotations

import re


class FileContractError(ValueError):
    """Raised when an import/export value could escape its intended command."""


_FILENAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._ -]{0,63}$")
_UNSAFE_COMMAND_TEXT = re.compile(r"[\x00-\x1f\x7f\"';/\\]")
_WINDOWS_RESERVED = re.compile(r"^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", re.I)
_XML_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def validate_ma2_filename(value: str) -> str:
    """Return a path-free MA2 filename or raise ``FileContractError``."""
    filename = str(value).strip()
    if not _FILENAME.fullmatch(filename):
        raise FileContractError(
            "Filename must be 1-64 characters, start with a letter or digit, "
            "and contain only letters, digits, spaces, dot, dash, or underscore."
        )
    if filename in {".", ".."} or ".." in filename or filename.endswith(".") or _WINDOWS_RESERVED.match(filename):
        raise FileContractError("Filename is unsafe on the grandMA2 Windows host.")
    return filename


def validate_ma2_command_text(value: str, *, field: str, maximum_length: int = 128) -> str:
    """Reject command separators, quoting, paths, and control characters."""
    text = str(value).strip()
    if not text or len(text) > maximum_length or _UNSAFE_COMMAND_TEXT.search(text):
        raise FileContractError(f"{field} contains unsafe command characters.")
    return text


def validate_xml_text(value: object, *, field: str, maximum_length: int = 128) -> str:
    """Bound text embedded through an escaping XML library."""
    text = str(value).strip()
    if not text or len(text) > maximum_length or _XML_CONTROL.search(text):
        raise FileContractError(f"{field} is invalid for the generated XML file.")
    return text


__all__ = [
    "FileContractError",
    "validate_ma2_command_text",
    "validate_ma2_filename",
    "validate_xml_text",
]
