"""Fail-closed launcher preflight for the exact OMA runtime source.

This module is intentionally local-only.  It proves that the Python selected by
the Windows launcher imports ``src.server`` from the configured bridge root and
that build, launcher mode, and scope match before tunnel-client is allowed to
start.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
from pathlib import Path


def _same_path(left: Path, right: Path) -> bool:
    """Compare resolved paths with Windows-compatible case folding."""
    return os.path.normcase(str(left.resolve())) == os.path.normcase(str(right.resolve()))


def verify_runtime_source(
    *,
    expected_root: str,
    expected_build: str,
    expected_mode: str,
    expected_scope: str,
    expected_launcher_version: str,
) -> dict[str, object]:
    """Import the server and verify its complete launcher identity."""
    from src import __version__ as bridge_version
    from src import server
    from src.runtime_contract import (
        BRIDGE_VERSION,
        LAUNCHER_VERSION,
        MCP_SDK_VERSION,
        RUNTIME_CONTRACT_PATH,
        public_runtime_contract,
        verify_tool_registry,
    )

    root = Path(expected_root).resolve()
    imported_server = Path(server.__file__).resolve()
    imported_root = imported_server.parent.parent
    contract_path = RUNTIME_CONTRACT_PATH.resolve()
    actual_mode = os.getenv("OMA_MODE", "").strip()
    actual_scope = os.getenv("GMA_SCOPE", "").strip()
    actual_build = server._BRIDGE_BUILD_SHA256
    installed_expected = server._EXPECTED_BUILD_SHA256
    mode_contract = server._MODE_CONTRACT
    network_contract = server._NETWORK_CONTRACT
    storage_contract = server.public_storage_snapshot()
    registry = getattr(getattr(server.mcp, "_tool_manager", None), "_tools", {})
    tool_contract = verify_tool_registry(registry.values())
    try:
        actual_mcp_sdk_version = importlib.metadata.version("mcp")
    except importlib.metadata.PackageNotFoundError:
        actual_mcp_sdk_version = "missing"
    checks = {
        "root": _same_path(imported_root, root),
        "server_file_within_root": imported_server.is_relative_to(root),
        "contract_file": _same_path(contract_path, root / "OMA_RUNTIME_CONTRACT.json"),
        "build": actual_build == expected_build.strip().lower(),
        "installed_expected_build": installed_expected == actual_build,
        "bridge_version": bridge_version == BRIDGE_VERSION,
        "launcher_version": expected_launcher_version == LAUNCHER_VERSION,
        "mcp_sdk_version": actual_mcp_sdk_version == MCP_SDK_VERSION,
        "mcp_tool_count": tool_contract["checks"]["tool_count"],
        "mcp_tool_names": tool_contract["checks"]["tool_names_sha256"],
        "mcp_client_schema": tool_contract["checks"]["client_schema_sha256"],
        "mcp_canonicalization": tool_contract["checks"]["canonicalization"],
        "mode": actual_mode == expected_mode,
        "scope": actual_scope == expected_scope,
        "contract_mode": mode_contract.oma_mode == expected_mode,
        "contract_scope": mode_contract.scope_token == expected_scope,
        "contract_environment_intact": mode_contract.environment_matches(),
        "network_contract_environment_intact": network_contract.environment_matches(),
        "network_target_bound": network_contract.allows_console(
            server._GMA_HOST,
            server._GMA_PORT,
        ),
        "external_ai_disabled": not network_contract.external_ai_enabled,
        "broadcast_discovery_disabled": not network_contract.broadcast_discovery_enabled,
        "auxiliary_network_loopback_only": network_contract.auxiliary_loopback_only,
        "companion_port_bound": network_contract.companion_port == 8000,
        "osc_port_bound": network_contract.osc_port == 7000,
        "storage_contract_environment_intact": bool(storage_contract["environment_intact"]),
        "storage_source_tree_isolated": bool(storage_contract["source_tree_isolated"]),
        "observer_autostart": mode_contract.observer_autostart,
        "auth_bypass_disabled": os.getenv("GMA_AUTH_BYPASS", "0") != "1",
    }
    return {
        "ok": all(checks.values()),
        "checks": checks,
        "actual": {
            "root": str(imported_root),
            "server_file": str(imported_server),
            "build": actual_build,
            "installed_expected_build": installed_expected,
            "bridge_version": bridge_version,
            "launcher_version": expected_launcher_version,
            "mcp_sdk_version": actual_mcp_sdk_version,
            "runtime_contract": public_runtime_contract(),
            "mcp_registry": tool_contract["actual"],
            "mode": actual_mode,
            "scope": actual_scope,
            "mode_contract": mode_contract.public_snapshot(),
            "network_contract": network_contract.public_snapshot(),
            "storage_contract": storage_contract,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected-root", required=True)
    parser.add_argument("--expected-build", required=True)
    parser.add_argument("--expected-mode", required=True)
    parser.add_argument("--expected-scope", required=True)
    parser.add_argument("--expected-launcher-version", required=True)
    args = parser.parse_args()
    result = verify_runtime_source(
        expected_root=args.expected_root,
        expected_build=args.expected_build,
        expected_mode=args.expected_mode,
        expected_scope=args.expected_scope,
        expected_launcher_version=args.expected_launcher_version,
    )
    print(json.dumps(result, sort_keys=True))
    return 0 if result["ok"] else 4


if __name__ == "__main__":
    raise SystemExit(main())
