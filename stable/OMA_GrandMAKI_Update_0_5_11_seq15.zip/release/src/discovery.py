"""Offline compatibility helpers for legacy grandMA2 discovery data.

Runtime broadcast and interface enumeration are intentionally disabled. The
pure packet parser remains available for reviewed offline captures.

Public API:
    parse_broadcast_packet(packet, source_addr) -> ConsoleCandidate | None
    list_local_networks() -> list[str]
    discover_grandma2_broadcast(network, timeout_seconds) -> list[ConsoleCandidate]
"""

from __future__ import annotations

from typing import TypedDict


class ConsoleCandidate(TypedDict):
    """A discovered grandMA2 console."""

    host: str
    port: int
    name: str | None
    session_name: str | None
    version: str | None
    response_ms: float
    source: str  # "broadcast" | "mdns" | "manual"


def parse_broadcast_packet(packet: bytes, source_addr: tuple[str, int]) -> ConsoleCandidate | None:
    """Parse a GMA2 announce packet — returns None if unrecognised.

    Wire format (documented in MA-Net manual; verify with a real capture):

        b"GMA2-ANNOUNCE\\x01" + fields_joined_by_\\x02 + b"\\x00"

    Each field is ``key=value``; known keys are session, name, ip, port, version.
    """
    if not packet.startswith(b"GMA2-ANNOUNCE"):
        return None
    body = packet.removeprefix(b"GMA2-ANNOUNCE").strip(b"\x00\x01")
    fields: dict[str, str] = {}
    for raw in body.split(b"\x02"):
        if b"=" not in raw:
            continue
        k, _, v = raw.partition(b"=")
        try:
            fields[k.decode("ascii").strip()] = v.decode("utf-8", "replace").strip()
        except Exception:  # noqa: BLE001
            continue
    host = fields.get("ip") or source_addr[0]
    try:
        port = int(fields.get("port", "30000"))
    except ValueError:
        port = 30000
    return ConsoleCandidate(
        host=host,
        port=port,
        name=fields.get("name"),
        session_name=fields.get("session"),
        version=fields.get("version"),
        response_ms=0.0,
        source="broadcast",
    )


def list_local_networks() -> list[str]:
    """Return no interfaces because runtime network discovery is disabled."""
    return []


async def discover_grandma2_broadcast(
    network: str | None = None,
    timeout_seconds: int = 5,
) -> list[ConsoleCandidate]:
    """Return no candidates without opening a socket or enumerating networks."""
    del network, timeout_seconds
    return []


__all__ = [
    "parse_broadcast_packet",
    "list_local_networks",
    "discover_grandma2_broadcast",
    "ConsoleCandidate",
]
