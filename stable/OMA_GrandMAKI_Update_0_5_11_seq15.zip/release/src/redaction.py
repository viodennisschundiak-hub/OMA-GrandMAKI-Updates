"""Central bounded redaction for logs, telemetry, observer data and traces."""

from __future__ import annotations

import inspect
import json
import re
from collections.abc import Callable, Mapping
from typing import Any

REDACTION_CONTRACT_VERSION = 1
REDACTED = "[REDACTED]"

_SECRET_KEY = re.compile(
    r"(?:^|[_\-.])(?:api[_\-.]?key|authorization|bearer|cookie|credential|dpapi|"
    r"ma[_\-.]?password|password|passwd|private[_\-.]?key|pwd|runtime[_\-.]?key|"
    r"secret|token|tunnel[_\-.]?id)(?:$|[_\-.])",
    re.IGNORECASE,
)
_VALUE_PATTERNS = (
    re.compile(r"\bsk-[A-Za-z0-9_-]{8,}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    re.compile(r"\btunnel_[A-Za-z0-9_-]{8,}\b", re.IGNORECASE),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{8,}\b", re.IGNORECASE),
    re.compile(r"\bBasic\s+[A-Za-z0-9+/=]{8,}\b", re.IGNORECASE),
    re.compile(r"AQAAANCMnd8BFdERjHoAwE/Cl\S{16,}", re.IGNORECASE),
)
_ASSIGNMENT = re.compile(
    r"(?i)(\b(?:CONTROL_PLANE_API_KEY|CONTROL_PLANE_TUNNEL_ID|GITHUB_TOKEN|"
    r"GITHUB_MODELS_TOKEN|GMA_PASSWORD|MA_PASSWORD|PASSWORD|RUNTIME_KEY|"
    r"TUNNEL_ID|AUTHORIZATION)\b[\"']?\s*[=:]\s*)(?:\"[^\"]*\"|'[^']*'|[^\s,;}]*)"
)
_URL_USERINFO = re.compile(r"(?i)(https?://[^\s:/@]+:)[^\s/@]+(@)")


def is_sensitive_key(key: object) -> bool:
    normalized = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", str(key)).casefold()
    return bool(_SECRET_KEY.search(normalized))


def redact_text(text: object, *, maximum_length: int = 4096) -> str:
    output_limit = max(0, int(maximum_length))
    # Redact before truncating so a credential crossing the preview boundary
    # cannot leak as an unmatched prefix.
    safe = str(text)
    safe = _ASSIGNMENT.sub(r"\1[REDACTED]", safe)
    safe = _URL_USERINFO.sub(r"\1[REDACTED]\2", safe)
    for pattern in _VALUE_PATTERNS:
        safe = pattern.sub(REDACTED, safe)
    return safe[:output_limit]


def redact_value(value: Any, *, _depth: int = 0) -> Any:
    if _depth > 8:
        return "[TRUNCATED_DEPTH]"
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for index, (key, item) in enumerate(value.items()):
            if index >= 200:
                result["_truncated"] = True
                break
            clean_key = str(key)[:256]
            result[clean_key] = REDACTED if is_sensitive_key(clean_key) else redact_value(item, _depth=_depth + 1)
        return result
    if isinstance(value, (list, tuple, set, frozenset)):
        items = list(value)
        result = [redact_value(item, _depth=_depth + 1) for item in items[:200]]
        if len(items) > 200:
            result.append("[TRUNCATED_ITEMS]")
        return result
    if isinstance(value, str):
        return redact_text(value)
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return redact_text(value)


def contains_sensitive_key(value: Any, *, _depth: int = 0) -> bool:
    if _depth > 8:
        return False
    if isinstance(value, Mapping):
        return any(
            is_sensitive_key(key) or contains_sensitive_key(item, _depth=_depth + 1) for key, item in value.items()
        )
    if isinstance(value, (list, tuple, set, frozenset)):
        return any(contains_sensitive_key(item, _depth=_depth + 1) for item in value)
    return False


def bind_and_redact_arguments(
    func: Callable[..., Any],
    args: tuple[Any, ...],
    kwargs: Mapping[str, Any],
) -> tuple[dict[str, Any], bool]:
    """Bind positional/keyword arguments so secret parameter names cannot hide."""
    try:
        bound = inspect.signature(func).bind_partial(*args, **kwargs)
        arguments = dict(bound.arguments)
    except (TypeError, ValueError):
        arguments = {"args": list(args), "kwargs": dict(kwargs)}
    sensitive = contains_sensitive_key(arguments)
    return redact_value(arguments), sensitive


def redacted_json(value: Any, *, maximum_length: int = 4096) -> str:
    encoded = json.dumps(
        redact_value(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return encoded[: max(0, int(maximum_length))]


def redact_serialized_json(text: object, *, maximum_length: int = 4096) -> str:
    try:
        decoded = json.loads(str(text))
    except (TypeError, ValueError, json.JSONDecodeError):
        return redact_text(text, maximum_length=maximum_length)
    return redacted_json(decoded, maximum_length=maximum_length)


def redacted_output_preview(
    result: object,
    *,
    sensitive_invocation: bool,
    maximum_length: int = 500,
) -> str:
    if sensitive_invocation:
        return "[REDACTED_SENSITIVE_INVOCATION]"
    return redact_text(result, maximum_length=maximum_length)


__all__ = [
    "REDACTED",
    "REDACTION_CONTRACT_VERSION",
    "bind_and_redact_arguments",
    "contains_sensitive_key",
    "is_sensitive_key",
    "redact_text",
    "redact_value",
    "redact_serialized_json",
    "redacted_json",
    "redacted_output_preview",
]
