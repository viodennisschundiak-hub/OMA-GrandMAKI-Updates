"""Fixed, link-safe access to grandMA2's local Windows data directory."""

from __future__ import annotations

import os
import re
from pathlib import Path

CONSOLE_FILE_CONTRACT_VERSION = 1
CONSOLE_DATA_ROOT_TEXT = r"C:\ProgramData\MA Lighting Technologies\grandma\gma2_V_3.9.60"
_SAFE_COMPONENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


class ConsoleFileContractError(RuntimeError):
    """Raised when a console-side file target is unavailable or redirected."""


def _is_link_or_junction(path: Path) -> bool:
    if path.is_symlink():
        return True
    is_junction = getattr(path, "is_junction", None)
    return bool(is_junction and is_junction())


def console_data_directory(*parts: str, create: bool = False) -> Path:
    """Return one fixed grandMA2 directory after containment/link checks."""
    if os.name != "nt":
        raise ConsoleFileContractError("grandMA2 data-file operations require the verified Windows runtime.")
    if any(not _SAFE_COMPONENT.fullmatch(str(part)) for part in parts):
        raise ConsoleFileContractError("Console data subdirectory is invalid.")

    root = Path(CONSOLE_DATA_ROOT_TEXT)
    if not root.is_dir() or _is_link_or_junction(root):
        raise ConsoleFileContractError("The fixed grandMA2 3.9.60 data directory is missing or redirected.")
    resolved_root = root.resolve(strict=True)
    target = resolved_root.joinpath(*parts)
    resolved_target = target.resolve(strict=False)
    if resolved_target != resolved_root and not resolved_target.is_relative_to(resolved_root):
        raise ConsoleFileContractError("Console data path escapes the fixed root.")

    current = resolved_root
    for part in parts:
        current /= part
        if current.exists() and _is_link_or_junction(current):
            raise ConsoleFileContractError("Console data path contains a link or junction.")
    if create:
        target.mkdir(parents=True, exist_ok=True)
    if not target.is_dir():
        raise ConsoleFileContractError("Required grandMA2 data directory is missing.")
    resolved_after_create = target.resolve(strict=True)
    if resolved_after_create != resolved_root and not resolved_after_create.is_relative_to(resolved_root):
        raise ConsoleFileContractError("Console data path was redirected during creation.")
    current = resolved_root
    for part in parts:
        current /= part
        if _is_link_or_junction(current):
            raise ConsoleFileContractError("Console data path contains a link or junction.")
    return target


__all__ = [
    "CONSOLE_DATA_ROOT_TEXT",
    "CONSOLE_FILE_CONTRACT_VERSION",
    "ConsoleFileContractError",
    "console_data_directory",
]
