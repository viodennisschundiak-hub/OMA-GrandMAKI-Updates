"""Immutable launcher mode and authorization contracts for one OMA process.

The Windows launcher selects exactly one of three profiles.  Environment
variables are transport for that startup choice, not a mutable authorization
database.  This module validates the complete tuple once and freezes the
result so later environment changes can neither elevate nor reduce the running
process.  Every profile keeps the read-only observer active; only the two
writable profiles permit launcher-bound write attestation.
"""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Mapping
from dataclasses import dataclass

from src.commands.constants import OAUTH_TIER_SCOPES

MODE_CONTRACT_VERSION = 1


class ModeContractError(RuntimeError):
    """Raised when startup variables do not match an approved OMA profile."""


@dataclass(frozen=True, slots=True)
class ModeContract:
    """Complete immutable capability contract for one bridge process."""

    profile: str
    oma_mode: str
    scope_token: str
    tier: int
    auto_attest_writes: bool
    observer_autostart: bool
    granted_scopes: frozenset[str]

    @property
    def writable(self) -> bool:
        return self.auto_attest_writes

    @property
    def contract_id(self) -> str:
        return f"oma-mode-contract/v{MODE_CONTRACT_VERSION}/{self.profile}"

    @property
    def sha256(self) -> str:
        canonical = json.dumps(
            {
                "auto_attest_writes": self.auto_attest_writes,
                "contract_id": self.contract_id,
                "observer_autostart": self.observer_autostart,
                "oma_mode": self.oma_mode,
                "scope_token": self.scope_token,
                "tier": self.tier,
            },
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def public_snapshot(self) -> dict[str, object]:
        """Return a deterministic, secret-free diagnostic representation."""
        return {
            "contract_id": self.contract_id,
            "contract_sha256": self.sha256,
            "profile": self.profile,
            "oma_mode": self.oma_mode,
            "scope_token": self.scope_token,
            "tier": self.tier,
            "writable": self.writable,
            "auto_attest_writes": self.auto_attest_writes,
            "observer_autostart": self.observer_autostart,
            "granted_scope_count": len(self.granted_scopes),
        }

    def environment_matches(self, environ: Mapping[str, str] | None = None) -> bool:
        """Report startup-variable drift without changing this contract."""
        try:
            candidate = build_mode_contract(environ)
        except ModeContractError:
            return False
        return candidate == self


_PROFILE_SPECS: dict[tuple[str, str, bool, bool], tuple[str, int]] = {
    ("observer", "tier:0", False, True): ("observer", 0),
    ("normal", "tier:4", True, True): ("programming", 4),
    ("full_admin", "tier:5", True, True): ("full_admin", 5),
}


def _cumulative_scopes(tier: int) -> frozenset[str]:
    return frozenset(
        str(scope)
        for level in range(tier + 1)
        for scope in OAUTH_TIER_SCOPES[level]
    )


def _binary_value(raw: str, *, name: str) -> bool:
    if raw not in {"0", "1"}:
        raise ModeContractError(f"{name} must be exactly '0' or '1'.")
    return raw == "1"


def build_mode_contract(environ: Mapping[str, str] | None = None) -> ModeContract:
    """Validate startup variables and construct one approved contract."""
    source = os.environ if environ is None else environ
    oma_mode = source.get("OMA_MODE", "observer").strip().casefold()
    scope_token = source.get("GMA_SCOPE", "tier:0").strip().casefold()
    auto_attest = _binary_value(
        source.get("OMA_AUTO_ATTEST_WRITES", "0").strip(),
        name="OMA_AUTO_ATTEST_WRITES",
    )
    observer_autostart = _binary_value(
        source.get("OMA_OBSERVER_AUTOSTART", "1").strip(),
        name="OMA_OBSERVER_AUTOSTART",
    )
    key = (oma_mode, scope_token, auto_attest, observer_autostart)
    profile_spec = _PROFILE_SPECS.get(key)
    if profile_spec is None:
        raise ModeContractError(
            "Unsupported OMA mode contract. Approved tuples are "
            "observer/tier:0/write:0/observer:1, "
            "normal/tier:4/write:1/observer:1 and "
            "full_admin/tier:5/write:1/observer:1."
        )
    profile, tier = profile_spec
    return ModeContract(
        profile=profile,
        oma_mode=oma_mode,
        scope_token=scope_token,
        tier=tier,
        auto_attest_writes=auto_attest,
        observer_autostart=observer_autostart,
        granted_scopes=_cumulative_scopes(tier),
    )


_ACTIVE_MODE_CONTRACT: ModeContract | None = None


def initialize_mode_contract(environ: Mapping[str, str] | None = None) -> ModeContract:
    """Initialize once; reject attempts to replace the active process contract."""
    global _ACTIVE_MODE_CONTRACT
    candidate = build_mode_contract(environ)
    if _ACTIVE_MODE_CONTRACT is None:
        _ACTIVE_MODE_CONTRACT = candidate
    elif candidate != _ACTIVE_MODE_CONTRACT:
        raise ModeContractError(
            "The OMA process mode contract is already initialized and cannot be changed."
        )
    return _ACTIVE_MODE_CONTRACT


def get_active_mode_contract() -> ModeContract:
    """Return the initialized contract, using the safe observer default if needed."""
    if _ACTIVE_MODE_CONTRACT is None:
        return initialize_mode_contract()
    return _ACTIVE_MODE_CONTRACT


__all__ = [
    "MODE_CONTRACT_VERSION",
    "ModeContract",
    "ModeContractError",
    "build_mode_contract",
    "get_active_mode_contract",
    "initialize_mode_contract",
]
