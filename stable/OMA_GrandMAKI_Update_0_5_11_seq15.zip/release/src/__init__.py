"""
grandMA2 MCP Server
"""

from src.runtime_contract import BRIDGE_VERSION

__version__ = BRIDGE_VERSION
