"""Persistent, serialized grandMA2 Web Remote readback runtime.

The console accepts at most three Web Remote users. Reconnecting for every
observer poll or fader verification exhausts that limit and loses continuity.
This module owns one read-only session per active console identity, serializes
all requests, applies a very short cache and reconnects once after read errors.
It exposes no command or user-input operation.
"""

from __future__ import annotations

import asyncio
import contextlib
import copy
import time
from collections.abc import Awaitable, Callable
from typing import Any

from src.telnet_client import GMA2WebRemoteClient, WebRemoteError

ClientFactory = Callable[..., GMA2WebRemoteClient]
ClientIdentity = tuple[str, str, str, int, float]


class WebRemoteRuntime:
    """Own and reuse one bounded read-only Web Remote session."""

    def __init__(
        self,
        *,
        client_factory: ClientFactory = GMA2WebRemoteClient,
        cache_ttl_seconds: float = 0.20,
        idle_seconds: float = 45.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._client_factory = client_factory
        self._cache_ttl_seconds = max(0.0, min(float(cache_ttl_seconds), 2.0))
        self._idle_seconds = max(1.0, min(float(idle_seconds), 600.0))
        self._clock = clock
        self._lock = asyncio.Lock()
        self._client: GMA2WebRemoteClient | None = None
        self._identity: ClientIdentity | None = None
        self._last_used = 0.0
        self._generation = 0
        self._cache: dict[tuple[Any, ...], tuple[float, Any]] = {}

    @staticmethod
    def _identity_for(
        *,
        host: str,
        user: str,
        password: str,
        port: int,
        timeout: float,
    ) -> ClientIdentity:
        return host, user, password, int(port), float(timeout)

    async def _drop_locked(self) -> None:
        client = self._client
        self._client = None
        self._identity = None
        self._cache.clear()
        if client is not None:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await asyncio.shield(client.close())

    async def _client_locked(self, identity: ClientIdentity) -> GMA2WebRemoteClient:
        now = self._clock()
        if self._client is not None and (
            self._identity != identity or now - self._last_used > self._idle_seconds
        ):
            await self._drop_locked()
        if self._client is None:
            host, user, password, port, timeout = identity
            client = self._client_factory(
                host=host,
                user=user,
                password=password,
                port=port,
                timeout=timeout,
            )
            await client.connect_and_login()
            self._client = client
            self._identity = identity
            self._generation += 1
        self._last_used = now
        return self._client

    async def _read(
        self,
        *,
        identity: ClientIdentity,
        cache_key: tuple[Any, ...],
        operation: Callable[[GMA2WebRemoteClient], Awaitable[Any]],
        force_refresh: bool,
    ) -> Any:
        async with self._lock:
            # Identity is part of the security boundary.  It must be checked
            # before consulting the cache, otherwise an equally-shaped request
            # for another console/user could receive data from the old session.
            now = self._clock()
            if self._client is not None and (
                self._identity != identity or now - self._last_used > self._idle_seconds
            ):
                await self._drop_locked()
            if force_refresh:
                # A forced read is normally a post-write verification.  Drop
                # every overlapping short-lived view so a following page read
                # cannot briefly return the pre-write value.
                self._cache.clear()
            cached = self._cache.get(cache_key)
            if not force_refresh and cached is not None and now - cached[0] <= self._cache_ttl_seconds:
                return copy.deepcopy(cached[1])

            last_error: WebRemoteError | None = None
            for attempt in range(2):
                try:
                    client = await self._client_locked(identity)
                    result = await operation(client)
                    self._last_used = self._clock()
                    self._cache[cache_key] = (self._last_used, copy.deepcopy(result))
                    return result
                except asyncio.CancelledError:
                    await self._drop_locked()
                    raise
                except WebRemoteError as exc:
                    last_error = exc
                    await self._drop_locked()
                    if attempt:
                        raise
            assert last_error is not None
            raise last_error

    async def read_pages(
        self,
        *,
        host: str,
        user: str,
        password: str,
        port: int,
        timeout: float,
        pages: list[int],
        force_refresh: bool = False,
    ) -> list[tuple[int, dict[str, Any]]]:
        clean_pages = tuple(sorted({int(page) for page in pages}))
        identity = self._identity_for(host=host, user=user, password=password, port=port, timeout=timeout)
        return await self._read(
            identity=identity,
            cache_key=("pages", clean_pages),
            operation=lambda client: client.read_pages_in_session(list(clean_pages)),
            force_refresh=force_refresh,
        )

    async def read_executor(
        self,
        *,
        host: str,
        user: str,
        password: str,
        port: int,
        timeout: float,
        page: int,
        executor: int,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        identity = self._identity_for(host=host, user=user, password=password, port=port, timeout=timeout)
        return await self._read(
            identity=identity,
            cache_key=("executor", int(page), int(executor)),
            operation=lambda client: client.read_executor_in_session(int(page), int(executor)),
            force_refresh=force_refresh,
        )

    async def read_physical_fader_slot(
        self,
        *,
        host: str,
        user: str,
        password: str,
        port: int,
        timeout: float,
        page: int,
        physical_fader_number: int,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        identity = self._identity_for(host=host, user=user, password=password, port=port, timeout=timeout)
        return await self._read(
            identity=identity,
            cache_key=("physical_fader", int(page), int(physical_fader_number)),
            operation=lambda client: client.read_physical_fader_slot_in_session(
                int(page), int(physical_fader_number)
            ),
            force_refresh=force_refresh,
        )

    async def close(self) -> None:
        """Close the owned session without affecting other console clients."""
        async with self._lock:
            await self._drop_locked()

    def status(self) -> dict[str, Any]:
        """Return secret-free local lifecycle information."""
        return {
            "connected": self._client is not None,
            "generation": self._generation,
            "cache_entries": len(self._cache),
        }


_DEFAULT_WEB_REMOTE_RUNTIME = WebRemoteRuntime()


def get_web_remote_runtime() -> WebRemoteRuntime:
    """Return the process-owned read-only Web Remote runtime."""
    return _DEFAULT_WEB_REMOTE_RUNTIME


__all__ = ["WebRemoteRuntime", "get_web_remote_runtime"]
