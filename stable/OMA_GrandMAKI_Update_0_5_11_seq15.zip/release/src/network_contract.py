"""Immutable local-network contract for the OMA bridge process."""

from __future__ import annotations

import hashlib
import ipaddress
import json
import os
from collections.abc import Mapping
from dataclasses import dataclass

NETWORK_CONTRACT_VERSION = 1


class NetworkContractError(RuntimeError):
    """Raised when network identity is invalid or changed after startup."""


def _normalize_host(host: str) -> str:
    normalized = host.strip().casefold()
    if not normalized or len(normalized) > 253:
        raise NetworkContractError("Configured console host is invalid.")
    if any(character in normalized for character in ("/", "\\", "@", "\x00", "\r", "\n")):
        raise NetworkContractError("Configured console host contains unsafe characters.")
    normalized = normalized.strip("[]")
    if normalized == "localhost":
        return "127.0.0.1"
    try:
        address = ipaddress.ip_address(normalized)
    except ValueError as exc:
        raise NetworkContractError("Configured console host must be a literal IP address.") from exc
    if address.version == 6 and not address.is_loopback:
        raise NetworkContractError("Only IPv4 or IPv6 loopback console targets are supported.")
    if address.is_unspecified or address.is_multicast:
        raise NetworkContractError("Configured console address is not unicast.")
    return address.compressed


def normalize_loopback_host(host: str) -> str:
    """Return an exact numeric loopback address and reject every other host."""
    try:
        normalized = _normalize_host(host)
        address = ipaddress.ip_address(normalized)
    except (NetworkContractError, ValueError) as exc:
        raise NetworkContractError("Auxiliary target must be an exact loopback address.") from exc
    if address not in {ipaddress.ip_address("127.0.0.1"), ipaddress.ip_address("::1")}:
        raise NetworkContractError("Auxiliary target must be 127.0.0.1 or ::1.")
    return address.compressed


def is_loopback_host(host: str) -> bool:
    try:
        normalize_loopback_host(host)
    except NetworkContractError:
        return False
    return True


@dataclass(frozen=True, slots=True)
class NetworkContract:
    console_host: str
    console_port: int
    external_ai_enabled: bool = False
    broadcast_discovery_enabled: bool = False
    auxiliary_loopback_only: bool = True
    companion_port: int = 8000
    osc_port: int = 7000

    @property
    def contract_id(self) -> str:
        return f"oma-network-contract/v{NETWORK_CONTRACT_VERSION}/offline"

    @property
    def sha256(self) -> str:
        canonical = json.dumps(
            {
                "auxiliary_loopback_only": self.auxiliary_loopback_only,
                "broadcast_discovery_enabled": self.broadcast_discovery_enabled,
                "console_host": self.console_host,
                "console_port": self.console_port,
                "companion_port": self.companion_port,
                "contract_id": self.contract_id,
                "external_ai_enabled": self.external_ai_enabled,
                "osc_port": self.osc_port,
            },
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def allows_console(self, host: str, port: int) -> bool:
        try:
            return _normalize_host(host) == self.console_host and int(port) == self.console_port
        except (NetworkContractError, TypeError, ValueError):
            return False

    def allows_auxiliary(self, host: str) -> bool:
        return is_loopback_host(host)

    def allows_companion(self, host: str, port: int) -> bool:
        try:
            return self.allows_auxiliary(host) and int(port) == self.companion_port
        except (TypeError, ValueError):
            return False

    def allows_osc(self, host: str, port: int) -> bool:
        try:
            return self.allows_auxiliary(host) and int(port) == self.osc_port
        except (TypeError, ValueError):
            return False

    def environment_matches(self, environ: Mapping[str, str] | None = None) -> bool:
        try:
            return build_network_contract(environ) == self
        except NetworkContractError:
            return False

    def public_snapshot(self) -> dict[str, object]:
        return {
            "contract_id": self.contract_id,
            "contract_sha256": self.sha256,
            "console_host": self.console_host,
            "console_port": self.console_port,
            "companion_port": self.companion_port,
            "external_ai_enabled": self.external_ai_enabled,
            "osc_port": self.osc_port,
            "broadcast_discovery_enabled": self.broadcast_discovery_enabled,
            "auxiliary_loopback_only": self.auxiliary_loopback_only,
        }


def build_network_contract(environ: Mapping[str, str] | None = None) -> NetworkContract:
    source = os.environ if environ is None else environ
    host = _normalize_host(source.get("GMA_HOST", "127.0.0.1"))
    raw_port = source.get("GMA_PORT", "30000").strip()
    try:
        port = int(raw_port)
    except ValueError as exc:
        raise NetworkContractError("GMA_PORT must be an integer.") from exc
    if not 1 <= port <= 65535:
        raise NetworkContractError("GMA_PORT is outside the valid port range.")
    return NetworkContract(console_host=host, console_port=port)


_ACTIVE_NETWORK_CONTRACT: NetworkContract | None = None


def initialize_network_contract(
    environ: Mapping[str, str] | None = None,
) -> NetworkContract:
    global _ACTIVE_NETWORK_CONTRACT
    candidate = build_network_contract(environ)
    if _ACTIVE_NETWORK_CONTRACT is None:
        _ACTIVE_NETWORK_CONTRACT = candidate
    elif candidate != _ACTIVE_NETWORK_CONTRACT:
        raise NetworkContractError("The OMA network contract is initialized and cannot be changed.")
    return _ACTIVE_NETWORK_CONTRACT


def get_active_network_contract() -> NetworkContract:
    if _ACTIVE_NETWORK_CONTRACT is None:
        return initialize_network_contract()
    return _ACTIVE_NETWORK_CONTRACT


__all__ = [
    "NETWORK_CONTRACT_VERSION",
    "NetworkContract",
    "NetworkContractError",
    "build_network_contract",
    "get_active_network_contract",
    "initialize_network_contract",
    "is_loopback_host",
    "normalize_loopback_host",
]
