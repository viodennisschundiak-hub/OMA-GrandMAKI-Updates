"""
telemetry.py — Per-tool invocation recorder for OpenSpace-style observability.

Records every MCP tool call to the ``tool_invocations`` table in agent_memory.db.
Writes are synchronous but fast (local SQLite); they add <1 ms per call and run
inside the existing async task so no extra thread or event-loop plumbing is needed.

Controlled via the ``GMA_TELEMETRY`` env var:
    GMA_TELEMETRY=1  (default) — recording enabled
    GMA_TELEMETRY=0            — recording disabled (CI / unit tests)

Risk-tier inference heuristic (applied once at decoration time, not per call):
    1. ``confirm_destructive`` in function signature → DESTRUCTIVE
    2. Explicit SAFE_WRITE name override                     → SAFE_WRITE
    3. Explicit SAFE_READ name or prefix                     → SAFE_READ
    4. Anything else                                         → SAFE_WRITE
"""

from __future__ import annotations

import inspect
import math
import sqlite3
import threading
import time
from collections.abc import Callable
from pathlib import Path

from src.redaction import redact_serialized_json, redact_text
from src.runtime_paths import (
    ensure_private_directory,
    harden_private_file,
    runtime_database_path,
)

# Reuse the same DB as LongTermMemory so all memory tables live together.
_DEFAULT_DB = runtime_database_path()

_SAFE_READ_PREFIXES: tuple[str, ...] = (
    "analyze_",
    "browse_",
    "hydrate_",
    "list_",
    "discover_",
    "get_",
    "search_",
    "info_",
    "suggest_",
    "assert_",
    "recall_",
    "check_",  # T6 helper `check_plugin_available` lands in Path B; staged here.
    "snapshot_",
    "validate_",
)

_SAFE_READ_NAMES: frozenset[str] = frozenset(
    {
        "start_observer",
        "stop_observer",
        "refresh_observer_static_cache",
        "resolve_physical_fader_slot",
        "verify_selection_membership",
        "query_object_list",
        "scan_page_executor_layout",
        "compare_cue_values",
        "diff_cues",
        "incident_snapshot",
        "trace_attribute_lineage",
        "inspect_local_ma2_lua_api",
        "inspect_readonly_lua_runtime_schema",
        "inspect_sessions",
        "recluster_tools",
        "reconfigure_connection",
    }
)

_SAFE_WRITE_NAMES: frozenset[str] = frozenset(
    {
        # This diagnostic intentionally uses ClearSelection/IfOutput on the
        # dedicated bridge user and restores it afterwards.  A reversible
        # mutation is still a write and must never pass the observer gate.
        "get_running_effects",
    }
)


def infer_risk_tier(func: Callable) -> str:
    """Return the most likely risk tier for a tool function.

    Called once at decoration time — not on every invocation.
    """
    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError):
        return "SAFE_WRITE"
    if "confirm_destructive" in sig.parameters:
        return "DESTRUCTIVE"
    name = func.__name__
    if name in _SAFE_WRITE_NAMES:
        return "SAFE_WRITE"
    if name in _SAFE_READ_NAMES:
        return "SAFE_READ"
    if any(name.startswith(p) for p in _SAFE_READ_PREFIXES):
        return "SAFE_READ"
    return "SAFE_WRITE"


def infer_result_error_class(result: object) -> str | None:
    """Classify JSON error payloads that did not raise a Python exception.

    MCP tools commonly return structured ``blocked``/``error`` responses for
    policy denials, console failures, and degraded reads.  Treating those as
    successes made the telemetry error rate disagree with the user-visible
    result.  Non-JSON strings and ordinary result objects remain successful.
    """
    if not isinstance(result, str) or not result.strip():
        return None
    try:
        import json

        payload = json.loads(result)
    except (TypeError, ValueError):
        return None
    if not isinstance(payload, dict):
        return None
    status = str(payload.get("status") or "").strip().upper()
    has_error = bool(payload.get("error"))
    blocked = payload.get("blocked") is True
    if not has_error and not blocked and status not in {
        "ERROR",
        "FAILED",
        "TIMEOUT",
        "CANCELLED",
        "DEGRADED",
        "RESPONSE_LIMIT",
    }:
        return None
    if status:
        token = "".join(part.title() for part in status.split("_"))
        return f"{token}Error" if not token.endswith("Error") else token
    return "BlockedResult" if blocked else "ToolResultError"


class ToolTelemetry:
    """
    Thread-safe, per-tool invocation recorder backed by agent_memory.db.

    Exposes:
      - ``record_sync``  — called from ``_handle_errors`` wrapper
      - ``metrics``      — aggregated latency + error stats for one tool
      - ``recent``       — raw rows for the last N invocations of a tool
    """

    def __init__(self, db_path: Path = _DEFAULT_DB) -> None:
        if db_path == _DEFAULT_DB:
            ensure_private_directory(db_path.parent)
        else:
            db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
        if db_path == _DEFAULT_DB:
            harden_private_file(db_path)
        self._lock = threading.Lock()
        self._init_schema()

    # ------------------------------------------------------------------ #
    # Schema                                                               #
    # ------------------------------------------------------------------ #

    def _init_schema(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS tool_invocations (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                ts             REAL    NOT NULL,
                tool_name      TEXT    NOT NULL,
                inputs_json    TEXT,
                output_preview TEXT,
                error_class    TEXT,
                latency_ms     REAL,
                risk_tier      TEXT,
                operator       TEXT,
                session_id     TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_ti_tool ON tool_invocations(tool_name);
            CREATE INDEX IF NOT EXISTS idx_ti_ts   ON tool_invocations(ts);
            CREATE INDEX IF NOT EXISTS idx_ti_err  ON tool_invocations(error_class)
                WHERE error_class IS NOT NULL;
        """)
        self._conn.commit()

    # ------------------------------------------------------------------ #
    # Write                                                                #
    # ------------------------------------------------------------------ #

    def record_sync(
        self,
        *,
        tool_name: str,
        inputs_json: str,
        output_preview: str,
        error_class: str | None,
        latency_ms: float,
        risk_tier: str,
        operator: str,
        session_id: str = "",
    ) -> None:
        """Insert one invocation row.  Silently suppresses any write error."""
        try:
            with self._lock:
                self._conn.execute(
                    "INSERT INTO tool_invocations "
                    "(ts,tool_name,inputs_json,output_preview,error_class,"
                    "latency_ms,risk_tier,operator,session_id) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    (
                        time.time(),
                        tool_name,
                        redact_serialized_json(inputs_json, maximum_length=4096),
                        redact_text(output_preview, maximum_length=500),
                        error_class,
                        latency_ms,
                        risk_tier,
                        operator,
                        session_id,
                    ),
                )
                self._conn.commit()
        except Exception:  # noqa: BLE001
            pass  # telemetry must never break a tool call

    # ------------------------------------------------------------------ #
    # Read                                                                 #
    # ------------------------------------------------------------------ #

    def metrics(self, tool_name: str, days: int = 7) -> dict:
        """Return latency + error-rate stats for one tool over the last N days."""
        since = time.time() - days * 86_400
        rows = self._conn.execute(
            "SELECT latency_ms, error_class FROM tool_invocations WHERE tool_name=? AND ts>?",
            (tool_name, since),
        ).fetchall()
        if not rows:
            return {"tool": tool_name, "calls": 0, "days": days}
        latencies = sorted(r[0] for r in rows if r[0] is not None)
        errors = [r[1] for r in rows if r[1] is not None]
        n = len(rows)

        def percentile(values: list[float], quantile: float) -> float | None:
            if not values:
                return None
            # Nearest-rank percentile: monotonic for small samples and never
            # produces the previous p95 < p50 inversion for two calls.
            index = max(0, min(len(values) - 1, math.ceil(quantile * len(values)) - 1))
            return values[index]

        return {
            "tool": tool_name,
            "calls": n,
            "days": days,
            "error_count": len(errors),
            "error_rate": round(len(errors) / n, 3),
            "error_classes": list(set(errors)),
            "p50_ms": percentile(latencies, 0.50),
            "p95_ms": percentile(latencies, 0.95),
            "min_ms": latencies[0] if latencies else None,
            "max_ms": latencies[-1] if latencies else None,
        }

    def recent(self, tool_name: str, limit: int = 20) -> list[dict]:
        """Return the last N invocation rows for a tool."""
        rows = self._conn.execute(
            "SELECT ts,tool_name,output_preview,error_class,latency_ms,"
            "risk_tier,operator,session_id "
            "FROM tool_invocations WHERE tool_name=? "
            "ORDER BY ts DESC LIMIT ?",
            (tool_name, limit),
        ).fetchall()
        cols = [
            "ts",
            "tool_name",
            "output_preview",
            "error_class",
            "latency_ms",
            "risk_tier",
            "operator",
            "session_id",
        ]
        return [dict(zip(cols, r, strict=False)) for r in rows]

    def top_failing_tools(self, days: int = 7, min_failures: int = 3) -> list[dict]:
        """Return tools with >= min_failures errors in the last N days."""
        since = time.time() - days * 86_400
        rows = self._conn.execute(
            "SELECT tool_name, error_class, COUNT(*) as cnt "
            "FROM tool_invocations "
            "WHERE error_class IS NOT NULL AND ts > ? "
            "GROUP BY tool_name, error_class "
            "ORDER BY cnt DESC",
            (since,),
        ).fetchall()
        # Aggregate by tool_name
        by_tool: dict[str, dict] = {}
        for tool_name, error_class, cnt in rows:
            if tool_name not in by_tool:
                by_tool[tool_name] = {"tool_name": tool_name, "total": 0, "errors": {}}
            by_tool[tool_name]["total"] += cnt
            by_tool[tool_name]["errors"][error_class] = cnt
        return [v for v in by_tool.values() if v["total"] >= min_failures]

    # ------------------------------------------------------------------ #
    # Lifecycle                                                            #
    # ------------------------------------------------------------------ #

    def close(self) -> None:
        self._conn.close()
