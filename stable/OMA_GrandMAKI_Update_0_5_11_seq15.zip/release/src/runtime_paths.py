"""Private, source-tree-independent storage paths for one OMA process."""

from __future__ import annotations

import hashlib
import os
from collections.abc import Mapping
from pathlib import Path

STORAGE_CONTRACT_VERSION = 1
_SOURCE_ROOT = Path(__file__).resolve().parent.parent


class RuntimePathError(RuntimeError):
    """Raised when a runtime path could escape the private data root."""


def _is_link_or_junction(path: Path) -> bool:
    if path.is_symlink():
        return True
    is_junction = getattr(path, "is_junction", None)
    return bool(is_junction and is_junction())


def _candidate_data_root(environ: Mapping[str, str]) -> tuple[Path, str]:
    override = environ.get("OMA_DATA_ROOT", "").strip()
    if override:
        candidate = Path(override).expanduser()
        source = "OMA_DATA_ROOT"
        if not candidate.is_absolute():
            raise RuntimePathError("OMA_DATA_ROOT must be an absolute path.")
        return candidate, source

    local_app_data = environ.get("LOCALAPPDATA", "").strip()
    if local_app_data:
        return Path(local_app_data) / "OMA_GrandMAKI_BOT" / "runtime_data", "LOCALAPPDATA"

    xdg_state_home = environ.get("XDG_STATE_HOME", "").strip()
    if xdg_state_home:
        candidate = Path(xdg_state_home).expanduser()
        if not candidate.is_absolute():
            raise RuntimePathError("XDG_STATE_HOME must be an absolute path.")
        return candidate / "oma-grandmaki-bot", "XDG_STATE_HOME"

    return Path.home() / ".local" / "state" / "oma-grandmaki-bot", "user_state"


def resolve_data_root(environ: Mapping[str, str] | None = None) -> tuple[Path, str]:
    """Resolve and validate the process data root without creating it."""
    source = os.environ if environ is None else environ
    candidate, origin = _candidate_data_root(source)
    absolute = candidate.absolute()
    if candidate.exists() and _is_link_or_junction(candidate):
        raise RuntimePathError("OMA data root must not be a symbolic link or junction.")
    resolved = candidate.resolve(strict=False)
    source_root = _SOURCE_ROOT.resolve()
    if resolved == source_root or resolved.is_relative_to(source_root):
        raise RuntimePathError("OMA runtime data must not be stored inside the source tree.")
    if not resolved.is_absolute() or resolved == Path(resolved.anchor):
        raise RuntimePathError("OMA data root is not a safe dedicated directory.")
    if candidate.exists() and absolute != resolved:
        raise RuntimePathError("OMA data root contains a redirected path component.")
    return resolved, origin


_DATA_ROOT, _DATA_ROOT_SOURCE = resolve_data_root()


def data_root() -> Path:
    """Return the immutable data root selected at module import."""
    return _DATA_ROOT


def _assert_within_data_root(path: Path) -> Path:
    resolved = path.resolve(strict=False)
    if resolved != _DATA_ROOT and not resolved.is_relative_to(_DATA_ROOT):
        raise RuntimePathError("Runtime path escapes the private OMA data root.")
    return resolved


def ensure_private_directory(path: Path) -> Path:
    """Create a data-root directory and apply owner-only POSIX permissions."""
    target = _assert_within_data_root(path)
    current = target
    while current != _DATA_ROOT.parent:
        if current.exists() and _is_link_or_junction(current):
            raise RuntimePathError("Runtime directory contains a link or junction.")
        if current == _DATA_ROOT:
            break
        current = current.parent
    target.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name != "nt":
        os.chmod(target, 0o700)
    return target


def harden_private_file(path: Path) -> Path:
    """Validate a runtime file and apply owner-only POSIX permissions."""
    target = _assert_within_data_root(path)
    if target.exists() and _is_link_or_junction(target):
        raise RuntimePathError("Runtime file must not be a link or junction.")
    if target.exists() and os.name != "nt":
        os.chmod(target, 0o600)
    return target


def runtime_database_path() -> Path:
    return _DATA_ROOT / "state" / "oma_runtime.db"


def workflow_database_path() -> Path:
    return _DATA_ROOT / "state" / "workflow_memory.db"


def observer_event_path() -> Path:
    return _DATA_ROOT / "observer" / "oma_events.jsonl"


def trace_directory() -> Path:
    return _DATA_ROOT / "traces"


def export_directory() -> Path:
    return _DATA_ROOT / "exports"


def environment_matches(environ: Mapping[str, str] | None = None) -> bool:
    try:
        candidate, _ = resolve_data_root(environ)
    except RuntimePathError:
        return False
    return candidate == _DATA_ROOT


def public_storage_snapshot() -> dict[str, object]:
    """Return secret-free storage diagnostics without disclosing the user path."""
    return {
        "contract_id": f"oma-storage-contract/v{STORAGE_CONTRACT_VERSION}",
        "data_root_source": _DATA_ROOT_SOURCE,
        "data_root_fingerprint": hashlib.sha256(str(_DATA_ROOT).encode("utf-8")).hexdigest(),
        "source_tree_isolated": not _DATA_ROOT.is_relative_to(_SOURCE_ROOT.resolve()),
        "environment_intact": environment_matches(),
        "runtime_database_exists": runtime_database_path().is_file(),
        "observer_log_exists": observer_event_path().is_file(),
    }


__all__ = [
    "RuntimePathError",
    "STORAGE_CONTRACT_VERSION",
    "data_root",
    "ensure_private_directory",
    "environment_matches",
    "export_directory",
    "harden_private_file",
    "observer_event_path",
    "public_storage_snapshot",
    "resolve_data_root",
    "runtime_database_path",
    "trace_directory",
    "workflow_database_path",
]
