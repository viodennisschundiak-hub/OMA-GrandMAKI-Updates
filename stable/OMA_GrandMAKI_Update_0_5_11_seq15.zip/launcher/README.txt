OMA GRANDMAKI-BOT LAUNCHER 1.2.12
Stand: 27.08.2026

BEDIENUNG
1. grandMA2 onPC und gewünschte Show starten; Telnet Login = Enabled.
2. Observer, Programming oder Full Admin wählen.
3. Nur onPC oder Mit Lichtpult wählen.
   - Nur onPC erzwingt 127.0.0.1:30000 und ignoriert alte Pult-Adressen.
   - Mit Lichtpult verwendet die unter Einstellungen gespeicherte Pult-IP.
4. OMA STARTEN drücken.
5. Für jede Änderung und jedes Update zuerst OMA STOPPEN.

LOKALE ZUGANGSDATEN
- Runtime-Key, Tunnel-ID und grandMA2-Telnet-Passwort werden ausschließlich
  mit Windows DPAPI im CurrentUser-Kontext gespeichert.
- Der grandMA2-Telnet-Benutzer ist fest auf AI_BRIDGE gebunden und kann im
  Launcher nicht auf administrator oder einen anderen Benutzer geändert werden.
- Eine vorhandene DPAPI-v1-Datei übernimmt Runtime-Key und Tunnel-ID erst nach
  lokaler Eingabe des grandMA2-Passworts in das v2-Schema; bei Abbruch bleibt
  die alte Datei unverändert.
- Die Bridge-.env ist für die vom Launcher gestartete Sitzung nicht mehr die
  Quelle der grandMA2-Zugangsdaten. Geheimnisse niemals in Chat oder Log kopieren.

PHASE-5-UPDATER
- Der Updatekanal wird beim Öffnen im Hintergrund geprüft.
- UPDATES PRÜFEN lädt ein signiertes Suite-Paket über HTTPS.
- SHA-256 und Ed25519 müssen stimmen.
- Bridge wird im inaktiven A/B-Slot getestet.
- Launcher wird parallel unter einer neuen Versionsnummer installiert.
- Bei Fehlern wird nicht umgeschaltet bzw. automatisch zurückgerollt.
- Nach Erfolg startet der neue Launcher selbstständig.
- Der Launcher bindet sich beim Start ausschließlich an das eindeutig passende
  verifizierte A/B-Bridge-Release; alte manuelle Bridge-Pfade werden nicht
  weiterverwendet.
- Private Signierschlüssel sind niemals Bestandteil des Clients.
- Kanal- und Paket-URLs müssen HTTPS verwenden und exakt zum provisionierten
  öffentlichen OMA-Update-Repository gehören; gespeicherte Fremd-URLs werden
  verworfen. Danach gelten weiterhin Ed25519 und SHA-256.
- Ein wiederverwendeter Launcher benötigt einen gültigen signierten
  Herkunftsnachweis; fehlende oder falsche Nachweise werden sicher abgewiesen.

HARTE SESSION-REGEL
- Bei laufender OMA- oder tunnel-client-Session sind alle Änderungen gesperrt.
- Der Browser auf Port 8091 ist ausschließlich ein GET-only-Kontrollfenster.
- Observer: OMA_MODE=observer, GMA_SCOPE=tier:0, keine Writes
- Programming: OMA_MODE=normal, GMA_SCOPE=tier:4, vollständige Tiers 0 bis 4
- Full Admin: OMA_MODE=full_admin, GMA_SCOPE=tier:5, vollständige Tiers 0 bis 5
- Der read-only Observer-Worker startet in allen drei Modi automatisch, damit
  dieselbe Echtzeitdatenbasis auch während Programming und Full Admin besteht.
- Modus, Scope, Write-Attestation und Observer-Autostart werden beim
  Prozessstart als ein Vertrag validiert und danach eingefroren. Spätere
  Änderungen an Prozessvariablen können Rechte weder erweitern noch verkleinern.
- GMA_AUTH_BYPASS wird immer entfernt.
- Programming und Full Admin binden die Schreibfreigabe automatisch an Build,
  Modus, Scope und die per SAFE_READ gelesene Show-/Benutzer-/Versionsidentität.
- Tests, Diagnose und Updater setzen oder verändern niemals den aktiven Write-Gate.
- Full Admin ist nach bestandenem Start-Preflight unmittelbar schreibfähig. Es
  gibt keinen zweiten versteckten "Write-Modus": typisierte Befehle wie Fader
  auf 0 %, Executor Off/On und alle freigegebenen tier:5-Funktionen werden
  ausgeführt und anschließend live zurückgelesen.
- SAFE_READ, SAFE_WRITE und DESTRUCTIVE sind Risikoklassen einzelner Werkzeuge,
  keine zusätzlichen Betriebsmodi. Nur DESTRUCTIVE verlangt die dokumentierte
  Bestätigung des konkreten Aufrufs.
- Freie Rohbefehle, beliebige Lua-Skripte und Plugin-Ausführung bleiben auch in
  Full Admin separat deaktiviert; alle typisierten tier:5-Werkzeuge sind verfügbar.
- Nach Show-Wechsel oder unbekanntem Schreibabschluss bleibt der Write-Gate
  gesperrt, bis OMA gestoppt und neu gestartet wurde.

PRIVATE LAUFZEITDATEN UND GEHEIMNISSCHUTZ
- SQLite, Telemetrie, Observer-Ereignisse und Agent-Traces liegen ausschließlich
  unter %LOCALAPPDATA%\OMA_GrandMAKI_BOT\runtime_data, niemals im Quellslot.
- Der Speicherpfad wird beim Prozessstart eingefroren; relative Pfade,
  Quellbaum-Pfade, Symlinks und Junctions werden abgewiesen.
- Toolargumente werden nach Parameternamen gebunden und zentral redigiert.
  Passwörter, Tokens, DPAPI-Werte und Authorization-Daten gelangen weder in
  Telemetrie, Observer-JSONL, Traces noch Fehlermeldungen.
- Die zusätzliche Oberfläche bindet fest an 127.0.0.1, prüft den Host-Header,
  setzt restriktive Browser-Header und besitzt ausschließlich GET-Endpunkte.
  Sie kann den authentifizierten MCP-Schreibworkflow nicht begrenzen.

FESTER NETZWERKVERTRAG
- Nur onPC bindet exakt 127.0.0.1:30000.
- Mit Lichtpult akzeptiert ausschließlich eine literale IPv4-Adresse in einem
  direkt verbundenen lokalen Subnetz. Hostnamen, DNS-Ziele und geroutete Ziele
  erhalten niemals das grandMA2-Passwort.
- Der laufende Prozess kann Ziel, Port, Benutzer oder Passwort nicht umstellen
  und schreibt keine Zugangsdaten in eine .env-Datei. Zielwechsel erfolgen nur
  bei gestoppter OMA über einen vollständig neuen Launcher-Preflight.
- Broadcast/mDNS und externe AI-/Embedding-Provider sind im Runtime-Prozess aus.
- Optionale Companion- und OSC-Ausgaben sind auf Loopback und die festen Ports
  8000 bzw. 7000 begrenzt; Companion-Antwortkörper werden nicht weitergereicht.

RUNTIME- UND MCP-VERTRAG
- OMA_RUNTIME_CONTRACT.json ist die maschinenlesbare Versionsquelle für
  OMA 0.5.10, Bridge 1.2.12, Launcher 1.2.12, Basement 0.5.0 und Sequenz 14.
- Der Launcher prüft vor dem Tunnelstart Bridge- und Launcher-Version, die
  installierte MCP-SDK-Version sowie Anzahl, Namen und vollständige
  clientseitige Ein-/Ausgabeschemas aller 251 MCP-Tools.
- Abweichungen bei nur einem Toolnamen, Parameter, Rückgabeschema oder einer
  Version stoppen den Start fail-closed, bevor eine OMA-Session aktiv wird.
- Diagnoseflächen zeigen ausschließlich Versionen, Zähler und SHA-256-Werte;
  Toolbeschreibungen, Showdaten und Zugangsdaten werden nicht protokolliert.

ECHTZEIT-READBACK
- Server, Observer und Einzelabfragen teilen genau eine serialisierte,
  ausschließlich lesende grandMA2-WebRemote-Sitzung. Es gibt dort keine
  Befehls- oder userInput-Funktion.
- Ein Konsolen-, Benutzer-, Passwort-, Port- oder Timeout-Wechsel trennt die
  alte Sitzung und verwirft ihren Kurzzeit-Cache vor dem nächsten Lesezugriff.
- Der Cache gilt höchstens 0,2 Sekunden. Gezielter Readback nach einem
  Fader-Write umgeht und leert ihn.
- Ein Fader-Write wird nur mit write_verified=true gemeldet, wenn Seite,
  Executor und Prozentwert im gezielten WebRemote-Readback übereinstimmen.
  Ein bereits gesendeter, aber nicht nachweisbarer Write wird ausdrücklich als
  write_verified=false zurückgegeben und niemals als Erfolg ausgegeben.
- Bei belegten WebRemote-Slots wartet der Observer standardmäßig 60 Sekunden
  und versucht es begrenzt erneut; ein kompletter Neustart ist nicht nötig.
- Voraussetzung: Setup > Console > Global Settings > Remotes = Login Enabled.

STARTWEG
Der Desktop-Link startet den festen Bootstrap aus
%LOCALAPPDATA%\OMA_GrandMAKI_BOT\launcher\1.2.12.
Startfehler werden sichtbar gemeldet und unter
%LOCALAPPDATA%\OMA_GrandMAKI_BOT\startup_logs protokolliert.

DIAGNOSE
DIAGNOSE ZIP erzeugt eine geheimnisfreie Datei unter
Desktop\OMA AI assistent\Uploads.
Ein fehlgeschlagener Probe enthält dort zusätzlich nur die bereinigte,
gekürzte Fehlermeldung und niemals Zugangsdaten.
